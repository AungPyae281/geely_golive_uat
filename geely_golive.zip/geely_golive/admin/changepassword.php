<?php include '../header.php'; ?>
<?php
	$uid = "";
	if(isset($_POST['uid'])){
		if(!empty($_POST['uid'])){
			$uid = $_POST['uid'];
		}
	}
?>
<div class="content-wrapper">
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<h1>
					Change Password
				</h1>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="card card-outline card-primary"> 
				<form role="form" id="frmChange">
					<div class="card-body">
						<div class="row">
							<div class="col-md-3"></div>
							<div class="col-md-6">
								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">User Name:</label>
									<div class="col-md-6">
										<input class="form-control" id="txtUserName" name="txtUserName" type="text" <?=($uid=='')?'':"disabled";?>>
									</div>
									<div class="col-md-2"></div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">Current Password:</label>
									<div class="col-md-6">
										<input type="password" id="txtCurrentPassword"  name="password" class="form-control" <?=($uid=='')?'':"disabled";?>>
									</div>
									<div class="col-md-2"></div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">New Password:</label>
									<div class="col-md-6">
										<input type="password" id="txtNewPassword"  name="txtNewPassword" class="form-control">
									</div>
									<div class="col-md-2"></div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 col-form-label" style="text-align: right;">Confirm Password:</label>
									<div class="col-md-6">
										<input type="password" id="txtConfirmPassword"  name="txtConfirmPassword" class="form-control">
									</div>
									<div class="col-md-2"></div>
								</div>
								<div class="form-group row">
									<label class="col-md-4 col-form-label"></label>
									<div class="col-md-6">
										<?php if($uid==""){ ?>
										<button class="btn btn-info col-md-5" type="button" onclick="clearForm()">Clear</button>
										<?php } ?>
										<button id="btnSubmit" class="btn btn-success col-md-5" type="button" value="Create" style="float: right;" onclick="validateAndChange()">Change</button>
									</div>
									<div class="col-md-2"></div>
								</div>
							</div>
							<div class="col-md-3"></div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>	 
	function clearForm(){
		$("#frmChange")[0].reset();
	}	

	function validateAndChange(){
		var username = $("#txtUserName").val();
		var currentpassword = $("#txtCurrentPassword").val();
		var confirmpassword = $("#txtConfirmPassword").val();
		var newpassword = $("#txtNewPassword").val();

		if(username.trim()=="" || currentpassword.trim()=="" || confirmpassword.trim()=="" || newpassword.trim()=="" ){
			bootbox.alert("Please fill the boxes.");
		}else if(newpassword.trim() != confirmpassword.trim()){
			bootbox.alert("Passwords are unmatch! Please enter again.");
		}else{
			$.ajax({
				type: "POST",
				url: APP_URL + "api/admin/changepassword/create.php",
				data: JSON.stringify({ username: username, currentpassword: currentpassword, newpassword: newpassword }),
				success: function(data){	
					if(data=="updated"){
						$("#txtUserName").val("");
						$("#txtCurrentPassword").val("");
						$("#txtConfirmPassword").val("");
						$("#txtNewPassword").val("");
						bootbox.alert("Successfully Changed.");
					}else if(data=="not exist"){
						bootbox.alert("Wrong username or password.");
					}else if(data=="wrong"){
						bootbox.alert("Please choose a different password.");
					}
				}
			});
		}
	} 
</script>