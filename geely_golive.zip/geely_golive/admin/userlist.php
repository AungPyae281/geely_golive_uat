<?php include '../header.php'; ?>	
<div class="content-wrapper">
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<h1>User Account</h1>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="card card-outline card-primary">
				<div class="card-body">
					<button type="button" class="btn btn-success btn-md" onclick='addNewAccount()'>Create User Account</button>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">User Account List</h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-striped table-bordered" id="myTable">
						<thead>                  
							<tr>
								<th style="width: 10px">#</th> 
								<th>Dashboard</th>
								<th>Staff Name</th>
								<th>User Name</th>
								<th style="width: 17%;">Password</th>	
								<th>Role Name</th>	
								<th style="width: 6%;">Edit</th>
								<th style="width: 6%;">Delete</th>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
			</div>

			<center>
				<div id="myModalChangePassword" class="modal fade modal-primary"> 
					<div class="modal-dialog" style="max-width: 100% !important;">
						<div class="modal-content" style="width: 515px; top: 29px;">
							<div class="modal-header" style="padding-top: 7px; padding-bottom: 7px;">
								<h3 class="modal-title" style="font-size: 17px; font-weight: bold;" id="">Change Password</h3>
								<button type="button" class="close" data-dismiss="modal">×</button>
							</div>
							<div class="modal-body">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Username: </label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtUsername" disabled>
												<input type="hidden" id="txtOldPassword">
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">New Password: </label>
											<div class="col-md-7">
												<input type="password" id="txtNewPassword" class="form-control" minlength="4" maxlength="16" autocomplete="new-password">
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<div class="col-md-7"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-block btn-primary" id="btnChangePassword" onclick="validateAndSave(this);">Change</button>
											</div>
											<div class="col-md-1"></div>
										</div>
									</div>
								</div> 
							</div>
						</div>
					</div>
				</div>
			</center>
		</div> 
	</section>
</div>
<?php include '../footer.php'; ?>
<script>	
	var OBJ = "";
	$(function() {
		getAll();
	});

	function getAll(){
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/user/get_users.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) { 
		    	var dashb = "";
		    	if(v.dashboard=="hr"){
		    		dashb = "HR";
		    	}else{
		    		var arrD = v.dashboard.split("_");
		    		for (var x = 0; x < arrD.length; x++) {
		    			dashb += ((dashb!="")?" ":"") + arrD[x].charAt(0).toUpperCase() + arrD[x].slice(1);
		    		}
		    	}
				var profilepicture = (v.profilepicture)?APP_URL + "api/user/" + v.profilepicture:APP_URL + "img/dummy_user.png";
				$("#myTable").find("tbody")
				.append($('<tr data-id="' + v.id + '">')
					.append("<td style='width: 10px'>" + (i + 1) + "</td>") 
					.append("<td>" + dashb + "</td>")	
					.append("<td>" + v.staff_name + "</td>")
					.append("<td>" + v.username + "</td>")
					.append("<td><i class='fa fa-eye-slash' style='font-weight:normal; cursor: pointer;' onclick='showPassword(\"" + v.password + "\", this)' title='Show Password'></i> &nbsp;<span class='password'>********</span> <i class='fas fa-user-lock' style='float: right; font-size: 20px; color: #007bff; cursor: pointer;' title='Change Password' onclick='changePassword(\"" + v.password + "\", this)'></i></td>")
					.append("<td>" + v.userrole + "</td>")
					.append("<td>" + ((v.userrole=="KEY")?"":"<button type='button' class='btn btn-block btn-success btn-sm fas fa-edit' onclick='changeUserRole(\"" + v.id + "\")' style='padding: 0px 13px;font-size: 20px; min-width: 37px'></button>") + "</td>")
					.append("<td>" + ((v.userrole=="KEY")?"":"<button type='button' class='btn btn-block btn-danger btn-sm' onclick='del(" + v.id + ", this)' style='padding: 0px 13px;font-size: 20px; min-width: 35px'><i class='fa fa-solid fa-trash'></i></button>") + "</td>")	
				);
			});
		});
	}

	function showPassword(password, obj){
		if($(obj).hasClass("fa-eye-slash")){
			$(obj).parent().find(".password").text(password);
			$(obj).removeClass("fa-eye-slash");
			$(obj).addClass("fa-eye");
			$(obj).attr("title", "Hide Password");
		}else{
			$(obj).parent().find(".password").text("********");
			$(obj).removeClass("fa-eye");
			$(obj).addClass("fa-eye-slash");
			$(obj).attr("title", "Show Password");
		}
	}

	function changePassword(password, obj){
		OBJ = obj;
		$("#txtUsername").val($(obj).parent().parent().find("td").eq(3).text());
		$("#txtOldPassword").val(password);
		$("#myModalChangePassword").modal("show");
	}

	function validateAndSave(){
		var old_password = $("#txtOldPassword").val();
		var password = $("#txtNewPassword").val();

		if(password.trim().length<5){
			bootbox.alert("Password should be at least 5.");
		}else if(old_password.trim()==password.trim()){
			bootbox.alert("Please choose different password.");
		}else{
			$.ajax({
				type: "POST",
				url: APP_URL + "api/admin/changepassword/create.php",
				data: JSON.stringify({ id: $(OBJ).parent().parent().attr("data-id"), password: password }),
				success: function(data){	
					if(data.message=="updated"){
						$("#txtUsername").val("");
						$("#txtOldPassword").val("");
						$("#txtNewPassword").val("");
						OBJ = "";
						getAll();
						bootbox.alert("Successfully Changed.");
						$("#myModalChangePassword").modal("hide");
					}else{
						bootbox.alert("Error on server side.");
					}
				}
			});
		}
	}

	function changeUserRole(id){	
		window.location.href = APP_URL + "admin/createaccount.php?act=edit&id=" + id;
	}

	function addNewAccount(){
		window.location.href = APP_URL + "admin/createaccount.php";
	}

	function del(id, obj){
		bootbox.confirm({
			message: "<h4>Are you sure that you want to delete?</h4>",
			buttons: {
				confirm: {
					label: '<span class="glyphicon glyphicon-ok"></span> Yes',
					className: 'btn-danger'
				},
				cancel: {
					label: '<span class="glyphicon glyphicon-remove"></span> No',
					className: 'btn-primary'
				}
			},
			callback: function (result) {
				if(result){
					$.ajax({
						type: "POST",
						url: APP_URL + "api/user/delete.php",
						data: JSON.stringify({ id: id }),
						success: function(data){
							if(data=="deleted"){
								$(obj).parent().parent().remove();
								rearrangeSorting();
							}else{
								bootbox.alert("Error on server side.");
							}
						}
					});
				}
			}
		});
	}  

	function rearrangeSorting(){
		$("#myTable tbody tr").each(function(){
			$(this).find("td").eq(0).text($(this).index() + 1);
		});
	}
</script>	
