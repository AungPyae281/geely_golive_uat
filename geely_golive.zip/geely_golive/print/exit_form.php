<!DOCTYPE html>
<?php include '../config/_globle.php'; ?>
<html>
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" type="image/x-icon" href="<?=$app_url;?>img/logo_sm.png" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Geely</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="stylesheet" href="../plugins/bootstrap/bootstrap.min.css">
	<link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" href="../plugins/icheck-bootstrap/icheck-bootstrap.min.css">	
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
	<style type="text/css">
	@media print and (color)
	{
		table { page-break-inside:auto }
		tr    { page-break-inside:avoid; page-break-after:auto }
		thead { display:table-header-group;}
		tfoot { display:table-footer-group }
	}
	@page {
        size: auto;
        margin: 0;
    }
    html, body {
        width: 183mm !important;
        height: 127mm !important;
        margin-left: 25px;
        margin-top: 5px;;
    }    
	body{
		width: 100%;
        height: 100%;
		font-size: 12px;
		font-family: 'Century Gothic';
		font-weight: normal; 
	}
	.page-header {
	    border-bottom: 1px solid #eee0 !important;
	} 
	.colon{
		float: right;
	}
</style>
</head>
<?php
$id = "";
if(isset($_GET['id'])){
	if(!empty($_GET['id'])){
		$id = $_GET['id'];
	}
}
?>
<body>
	<div class="wrapper">
		<section>
			<div class="col-xs-12" style="padding-left:1px; padding-bottom:15px;padding-right: 30px;border: 1px solid #000;">
				<div class="col-xs-2">
					<img src="<?=$app_url;?>img/exist_form.png" style="width:150px;height:auto;">
				</div>
				<div class="col-xs-8"></div>
				<div class="col-xs-2">
					<img src="<?=$app_url;?>img/login.png" style="width:120px;height:auto;">
				</div>
				<div class="col-xs-12">
					<center>
						<h2 class="page-header" style="margin:0px;"> 
							<div style="margin-top:6px; font-size:22px; font-weight: bold;">Vehicle Delivery & Exit Form</div>
						</h2>
					</center>
				</div>			
				<div class="col-xs-12">
					<div class="col-xs-4">
						<div class="row">
							<div class="col-xs-5" style="padding-left:0;padding-right:0;">Car No. <span class="colon">:</span></div>
							<div class="col-xs-7" style="padding-left:3px; padding-right:0;"><p style="border-bottom: 1px solid #000; height: 14px;" id="txtCarNo"></p></div>
						</div>
						<div class="row">
							<div class="col-xs-5" style="padding-left:0;padding-right:0;">Invoice No. <span class="colon">:</span></div>
							<div class="col-xs-7" style="padding-left:3px; padding-right:0;"><p style="border-bottom: 1px solid #000; height: 14px;" id="txtInvoiceNo"></p></div>
						</div>
					</div>
					<div class="col-xs-4"></div>
					<div class="col-xs-4">
						<div class="row">
							<div class="col-xs-5" style="padding-right:0;"><span class="colon">Date :</span></div>
							<div class="col-xs-7" style="padding-left:3px; padding-right:0;"><p style="border-bottom: 1px solid #000; height: 14px;" id="txtDate"></p></div>
						</div>
						<div class="row">
							<div class="col-xs-5" style="padding-right:0;"><span class="colon">Time :</span></div>
							<div class="col-xs-7" style="padding-left:3px; padding-right:0;"><p style="border-bottom: 1px solid #000; height: 14px;" id="txtTime"></p></div>
						</div>
					</div>
				</div>
			</div>			
			<div class="col-xs-12" style="padding-left:1px; padding-bottom:15px;padding-right: 30px;border-color: #000;border-style: solid;border-width: 0 1px 1px 1px;">
				<div class="col-xs-12">					
					<div class="row" style="padding-left: 15px;">
						<div class="col-xs-1" style="padding-left:0;padding-right:0; font-weight: bold;">Remark :</div>
						<div class="col-xs-11" style="padding-left:0; padding-right:0;"><p id="txtRemark"></p></div>
					</div>
				</div>
			</div>
			<div class="col-xs-12" style="padding-left:1px; padding-bottom:15px;padding-right: 30px;border-color: #000;border-style: solid;border-width: 0 1px 1px 1px;">
				<div class="col-xs-4">
					<center>
						<h2 class="page-header" style="margin:0px;padding-bottom: 20px;"> 
							<div style="margin-top:6px; font-size:13px; font-weight: bold;">Cashier</div>
						</h2>
						<div class="row">
							<div class="col-xs-3" style="padding-left:0;padding-right:0;text-align: right;">Name :</div>
							<div class="col-xs-8" style="padding-left:3px;"><p style="border-bottom: 1px solid #000; height: 14px; text-align: left;" id="txtCashierName"></p></div>
						</div>
						<div class="row">
							<div class="col-xs-3" style="padding-left:0;padding-right:0;text-align: right;">Sign :</div>
							<div class="col-xs-8" style="text-align: center;">
								<img id="imgCashierSig" src="<?=$app_url;?>img/transparent.png" style="height:90px; cursor:pointer;">
							</div>
						</div>
					</center>	
				</div>
				<div class="col-xs-4">
					<center>
						<h2 class="page-header" style="margin:0px;padding-bottom: 20px;"> 
							<div style="margin-top:6px; font-size:13px; font-weight: bold;">Customer</div>
						</h2>
						<div class="row">
							<div class="col-xs-3" style="padding-left:0;padding-right:0;text-align: right;">Name :</div>
							<div class="col-xs-8" style="padding-left:3px;"><p style="border-bottom: 1px solid #000; height: 14px; text-align: left;" id="txtCustomerName"></p></div>
						</div>
						<div class="row">
							<div class="col-xs-3" style="padding-left:0;padding-right:0;text-align: right;">Sign :</div>
							<div class="col-xs-8" style="text-align: center;">
								<img id="imgCustomerSig" src="<?=$app_url;?>img/transparent.png" style="height:90px; cursor:pointer;">
							</div>
						</div>
					</center>	
				</div>
				<div class="col-xs-4">
					<center>
						<h2 class="page-header" style="margin:0px;padding-bottom: 20px;"> 
							<div style="margin-top:6px; font-size:13px; font-weight: bold;">Service Manager</div>
						</h2>
						<div class="row">
							<div class="col-xs-3" style="padding-left:0;padding-right:0;text-align: right;">Name :</div>
							<div class="col-xs-8" style="padding-left:3px;"><p style="border-bottom: 1px solid #000; height: 14px; text-align: left;" id="txtManagerName"></p></div>
						</div>
						<div class="row">
							<div class="col-xs-3" style="padding-left:0;padding-right:0;text-align: right;">Sign :</div>
							<div class="col-xs-8" style="text-align: center;">
								<img id="imgManagerSig" src="<?=$app_url;?>img/transparent.png" style="height:90px; cursor:pointer;">
							</div>
						</div>
					</center>	
				</div>
			</div>
		</section>
	</div>
	<div style="page-break-before: always;"></div>
</body>
<script src="../plugins/jquery/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</html>	

<script type="text/javascript">
	var APP_URL = '<?=$app_url;?>';
	var id = "<?=$id;?>";
	$(function(){ 
		if(id){
			getOnePrint();
		}
	});

	function getOnePrint(){
		$.ajax({
			url: APP_URL + "api/service/service/get_one_print_exit_form.php",
			type: "POST",
			data: JSON.stringify({ id: id })
		}).done(function(data) {	
			$("#txtCarNo").text(data.plate_no);
			$("#txtInvoiceNo").text(data.registration_no);
			$("#txtDate").text(data.car_return_date);
			$("#txtTime").text(data.car_return_time);
			$("#txtCustomerName").text(data.contact_person);

			// if(data.cust_sig && ImageExist(data.cust_sig)) $("#imgCustomerSignature").attr('src', data.cust_sig + "?d=" + Math.random()); 
			window.print();
		});
	}

	function ImageExist(url){
		var img = new Image();
		img.src = url;
		return img.height != 0;
	}
</script>
