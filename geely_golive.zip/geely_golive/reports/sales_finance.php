<?php include '../header.php'; ?>
<style>
	select {
		padding-top: 1px !important;
	}
	.autocomplete-items {
		position: absolute;
		border: 1px solid #d4d4d4;
		border-bottom: none;
		border-top: none;
		z-index: 99;
		/*position the autocomplete items to be the same width as the container:*/
		top: 89%;
		left: 8px;
		right: 8px;
		max-height: 300px;
		overflow-y: auto;
	}
	.autocomplete-items-oc {
		position: absolute;
		border: 1px solid #d4d4d4;
		border-bottom: none;
		border-top: none;
		z-index: 99;
		/*position the autocomplete items to be the same width as the container:*/
		top: 100%;
		left: 0px;
		right: 0px;
		max-height: 300px;
		overflow-y: auto;
	}
	.autocomplete-items div, .autocomplete-items-oc div {
		padding: 10px;
		cursor: pointer;
		background-color: #fff;
		border-bottom: 1px solid #d4d4d4;
	}
	.autocomplete-items div:hover, .autocomplete-items-oc div:hover {
		/*when hovering an item:*/
		background-color: #e9e9e9;
	}
	.autocomplete-active {
		/*when navigating through the items using the arrow keys:*/
		background-color: DodgerBlue !important;
		color: #ffffff;
	} 
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Sales - Report</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Search</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date (From):</label>
											<div class="col-md-1 icheck-success d-inline">
												<input id="chkDateFrom" type="checkbox" style="margin: 8px 0px" checked>
												<label for="chkDateFrom"></label>
											</div>
											<div class="col-md-7">  
												<div class="input-group input-append date" id="datePicker1" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker1" value="1982-06-15" readonly>
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date (To):</label>
											<div class="col-md-1"></div>
											<div class="col-md-7">  
												<div class="input-group input-append date" id="datePicker2" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker2" value="1982-06-15" readonly>
												</div>
											</div>
										</div> 
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">OC No.:</label>
											<div class="col-md-8">
												<div class="input-group input-group">
													<input type="text" id="txtOCNo" class="form-control">
												</div>
											</div>
										</div>
									</div>		
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Customer Name:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtCustomerName">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Customer Phone:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtCustomerPhone">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Broker Name:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtBrokerName">
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Sales Center:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboSalesCenter"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Payment Type:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboPaymentType">
													<option value="">All</option>
													<option value="Cash">Cash</option>
													<option value="HP">HP</option>
													<option value="InHouse">InHouse</option>
												</select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Payment:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboPayment">
													<option value="">All</option>
													<option value="Full">Full</option>
													<option value="Remain">Remain</option>
												</select>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-primary btn-block" onclick="search()">Search</button>
											</div>
											<div class="col-md-4">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
											</div>
										</div>
									</div> 	
								</div>	
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">Sales List <span id="total_records" style="font-weight:bold;"> </span></h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
						<button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
					</div>
				</div>
				<div class="card-body p-0">
					<table class="table table-responsive table-striped table-bordered" id="myTable">
						<thead>                  
							<tr>
								<th style="width: 3%; text-align: center; vertical-align: middle;">#</th>
								<th style="text-align: center; vertical-align: middle;">Date</th>
								<th style="text-align: center; vertical-align: middle;">OC No.</th>
								<th style="text-align: center; vertical-align: middle;">Sales Center</th>
								<th style="text-align: center; vertical-align: middle;">Customer Name</th>
								<th style="text-align: center; vertical-align: middle;">Customer Phone</th>
								<th style="text-align: center; vertical-align: middle;">Broker Name</th>
								<th style="text-align: center; vertical-align: middle;">Vin No.</th>
								<th style="text-align: center; vertical-align: middle;">Payment Type</th>
								<th style="text-align: center; vertical-align: middle;">Deposit</th>
								<th style="text-align: center; vertical-align: middle;">RRP</th>
								<th style="text-align: center; vertical-align: middle;">Payment</th>
								<th style="text-align: center; vertical-align: middle;">Deposit Refund</th>
								<th></th>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
			</div>

			<center>
				<div class="modal fade modal-primary" id="myModalPaymentHistory"> 
					<div class="modal-dialog" style="max-width: 100% !important;">
						<div class="modal-content" style="width: 80%; top: 29px;">
							<div class="modal-header" style="padding: 12px;">
								<h4 class="modal-title" style="font-size: 18px !important;">Payment History (<span id="txtOCNOPH" style="font-weight:bold;"> </span>)</h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body" style="padding-left: 0px; padding-right: 0px;">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group row">
											<div class="col-md-2" style="padding-left: 25px;">
												<button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcelPH">Export Data</button> 
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="card-body p-0">
								<table class="table table-responsive table-striped table-bordered" id="myTablePayment" style="margin-top: -20px;">
									<thead>                  
										<tr>
                                            <th style="width: 3%">#</th>
                                            <th>Date</th>
                                            <th>G/L Code</th>
                                            <th>Account</th>
                                            <th>Paid By</th>
                                            <th>Amount</th>
                                            <th>Description</th>
                                            <th>Receipt</th>
                                            <th>Entry Date/Time</th>
                                        </tr>
									</thead>
									<tbody></tbody>
								</table>
							</div>
						</div>
					</div>
				</div>

				<div class="modal fade modal-primary" id="myModal">
					<div class="modal-dialog">
						<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>						
						<div class="modal-body">
							<center><img id="sf_img_large"/></center>
						</div>
				    </div><!-- /.modal-dialog -->
				</div>
			</center>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>

<script>
	var d = new Date();
	var mm = (d.getMonth("MM") + 1);
	var dd = d.getDate();
  	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker1').attr("data-date", customDate);
	$("#txtDatePicker1").val(customDate);
	$('#datePicker2').attr("data-date",customDate);
	$("#txtDatePicker2").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");	
		$('#datePicker1').datepicker();
		$('#datePicker2').datepicker(); 
		getAllSalesCenter();
		autocompleteOC(document.getElementById("txtOCNo"));
		autocompleteCustomer(document.getElementById("txtCustomerName"));
		autocompleteBroker(document.getElementById("txtBrokerName"));
	});	

	$(".exportToExcel").click(function(){
		exportExcel("#myTable");
	});

	$(".exportToExcelPH").click(function(){
		exportExcel("#myTablePayment");
	});  


	$("#txtCustomerName").on("input", function(){
		$("#txtCustomerPhone").val("");
	});

	$("#chkDateFrom").change(function() {
		if ($('#chkDateFrom').prop('checked')){
			$("#txtDatePicker1").prop("disabled", false);
			$("#txtDatePicker1").css("cursor", "pointer");

			$("#txtDatePicker2").prop("disabled", false);
			$("#txtDatePicker2").css("cursor", "pointer");
		}else{
			$("#txtDatePicker1").prop("disabled", true);
			$("#txtDatePicker1").val(customDate);
			$("#datePicker1").datepicker("setDate", customDate);

			$("#txtDatePicker2").prop("disabled", true);
			$("#txtDatePicker2").val(customDate);
			$("#datePicker2").datepicker("setDate", customDate);
		}
	});

	function getAllSalesCenter(){
		$("#cboSalesCenter").find("option").remove();
		$("#cboSalesCenter").append("<option value=''>All</option>");
		$.ajax({
			url: APP_URL + "api/sales_center/get_all_rows.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				$("#cboSalesCenter").append("<option value='" + v.name + "'>" + v.name + "</option>");
			});
		});
	}
 
	function autocompleteOC(inp) {
		var currentFocus;
		inp.addEventListener("input", function(e) {
			var a, i, val = this.value;
			var obj = this;
			closeAllLists();
			if (!val) { return false;}
			currentFocus = -1;
			$.ajax({
				url: APP_URL + "api/sales/sales/autocomplete_oc.php",
				type: "POST",
				data: JSON.stringify({ oc_no: this.value })
			}).done(function( data ) {
				bindData(a, i, obj, data, val);
			});
		});

		inp.addEventListener("keydown", function(e) {
			var x = document.getElementById(this.id + "autocomplete-list");
			if (x) x = x.getElementsByTagName("div");
			if (e.keyCode == 40) {
				currentFocus++;
				addActive(x);
			} else if (e.keyCode == 38) { 
				currentFocus--;
				addActive(x);
			} else if (e.keyCode == 13) {
				e.preventDefault();
				if (currentFocus > -1) {
					if (x) x[currentFocus].click();
				}
			}
		});

		function addActive(x) {
			if (!x) return false;
			removeActive(x);
			if (currentFocus >= x.length) currentFocus = 0;
			if (currentFocus < 0) currentFocus = (x.length - 1);
			x[currentFocus].classList.add("autocomplete-active");
		}

		function removeActive(x) {
			for (var i = 0; i < x.length; i++) {
				x[i].classList.remove("autocomplete-active");
			}
		}

		function closeAllLists(elmnt) {
			var x = document.getElementsByClassName("autocomplete-items-oc");
			for (var i = 0; i < x.length; i++) {
				if (elmnt != x[i] && elmnt != inp) {
					x[i].parentNode.removeChild(x[i]);
				}
			}
		}
		
		function bindData(a, i, obj, arr, val){
			a = document.createElement("DIV");
			a.setAttribute("id", obj.id + "autocomplete-list");
			a.setAttribute("class", "autocomplete-items-oc");
			obj.parentNode.appendChild(a);
			for (i = 0; i < arr.length; i++) {
				var strRegExp = new RegExp(val, "gi" ); //i makes it case insensitive	
				var oc_no = arr[i]['oc_no'];
				b = document.createElement("DIV");
				b.innerHTML = oc_no.replace(strRegExp, '<b>' + val + '</b>');
				b.innerHTML += "<input type='hidden' value='" + oc_no.replace(/\'/g, '&apos;') + "'>";
				b.addEventListener("click", function(e) {
					inp.value = this.getElementsByTagName("input")[0].value;
					closeAllLists();
				});
				a.appendChild(b);
			}
		}

		document.addEventListener("click", function (e) {
			closeAllLists(e.target);
		});
	}

	function autocompleteCustomer(inp) {
		var currentFocus;
		inp.addEventListener("input", function(e) {
			var a, i, val = this.value;
			var obj = this;
			closeAllLists();
			if (!val) { return false;}
			currentFocus = -1;
			$.ajax({
				url: APP_URL + "api/sales/customer/autocomplete.php",
				type: "POST",
				data: JSON.stringify({ name: this.value })
			}).done(function( data ) {
				bindData(a, i, obj, data, val);
			});
		});

		inp.addEventListener("keydown", function(e) {
			var x = document.getElementById(this.id + "autocomplete-list");
			if (x) x = x.getElementsByTagName("div");
			if (e.keyCode == 40) {
				currentFocus++;
				addActive(x);
			} else if (e.keyCode == 38) { 
				currentFocus--;
				addActive(x);
			} else if (e.keyCode == 13) {
				e.preventDefault();
				if (currentFocus > -1) {
					if (x) x[currentFocus].click();
				}
			}
		});

		function addActive(x) {
			if (!x) return false;
			removeActive(x);
			if (currentFocus >= x.length) currentFocus = 0;
			if (currentFocus < 0) currentFocus = (x.length - 1);
			x[currentFocus].classList.add("autocomplete-active");
		}

		function removeActive(x) {
			for (var i = 0; i < x.length; i++) {
				x[i].classList.remove("autocomplete-active");
			}
		}

		function closeAllLists(elmnt) {
			var x = document.getElementsByClassName("autocomplete-items");
			for (var i = 0; i < x.length; i++) {
				if (elmnt != x[i] && elmnt != inp) {
					x[i].parentNode.removeChild(x[i]);
				}
			}
		}
		
		function bindData(a, i, obj, arr, val){
			a = document.createElement("DIV");
			a.setAttribute("id", obj.id + "autocomplete-list");
			a.setAttribute("class", "autocomplete-items");
			obj.parentNode.appendChild(a);
			for (i = 0; i < arr.length; i++) {
				var strRegExp = new RegExp(val, "gi" ); //i makes it case insensitive	
				var name = arr[i]['name'];
				var mobile_no = arr[i]['mobile_no'];
				b = document.createElement("DIV");
				b.innerHTML = name.replace(strRegExp, '<b>' + val + '</b>');
				b.innerHTML += "<input type='hidden' value='" + name.replace(/\'/g, '&apos;') + "'>";
				b.innerHTML += "<input type='hidden' value='" + mobile_no + "'>";
				b.addEventListener("click", function(e) {
					inp.value = this.getElementsByTagName("input")[0].value;
					$("#txtCustomerPhone").val(this.getElementsByTagName("input")[1].value);
					closeAllLists();
				});
				a.appendChild(b);
			}
		}

		document.addEventListener("click", function (e) {
			closeAllLists(e.target);
		});
	}

	function autocompleteBroker(inp) {
		var currentFocus;
		inp.addEventListener("input", function(e) {
			var a, i, val = this.value;
			var obj = this;
			closeAllLists();
			if (!val) { return false;}
			currentFocus = -1;
			$.ajax({
				url: APP_URL + "api/sales/broker/autocomplete.php",
				type: "POST",
				data: JSON.stringify({ name: this.value })
			}).done(function( data ) {
				bindData(a, i, obj, data, val);
			});
		});

		inp.addEventListener("keydown", function(e) {
			var x = document.getElementById(this.id + "autocomplete-list");
			if (x) x = x.getElementsByTagName("div");
			if (e.keyCode == 40) {
				currentFocus++;
				addActive(x);
			} else if (e.keyCode == 38) { 
				currentFocus--;
				addActive(x);
			} else if (e.keyCode == 13) {
				e.preventDefault();
				if (currentFocus > -1) {
					if (x) x[currentFocus].click();
				}
			}
		});

		function addActive(x) {
			if (!x) return false;
			removeActive(x);
			if (currentFocus >= x.length) currentFocus = 0;
			if (currentFocus < 0) currentFocus = (x.length - 1);
			x[currentFocus].classList.add("autocomplete-active");
		}

		function removeActive(x) {
			for (var i = 0; i < x.length; i++) {
				x[i].classList.remove("autocomplete-active");
			}
		}

		function closeAllLists(elmnt) {
			var x = document.getElementsByClassName("autocomplete-items");
			for (var i = 0; i < x.length; i++) {
				if (elmnt != x[i] && elmnt != inp) {
					x[i].parentNode.removeChild(x[i]);
				}
			}
		}
		
		function bindData(a, i, obj, arr, val){
			a = document.createElement("DIV");
			a.setAttribute("id", obj.id + "autocomplete-list");
			a.setAttribute("class", "autocomplete-items");
			obj.parentNode.appendChild(a);
			for (i = 0; i < arr.length; i++) {
				var strRegExp = new RegExp(val, "gi" ); //i makes it case insensitive	
				var name = arr[i]['name'];
				b = document.createElement("DIV");
				b.innerHTML = name.replace(strRegExp, '<b>' + val + '</b>');
				b.innerHTML += "<input type='hidden' value='" + name.replace(/\'/g, '&apos;') + "'>";
				b.addEventListener("click", function(e) {
					inp.value = this.getElementsByTagName("input")[0].value;
					closeAllLists();
				});
				a.appendChild(b);
			}
		}

		document.addEventListener("click", function (e) {
			closeAllLists(e.target);
		});
	}

	function search(){
		$("#loading").css("display","block");
		var df = ($("#chkDateFrom").prop("checked"))?$("#txtDatePicker1").val():"";
		var dt = ($("#chkDateFrom").prop("checked"))?$("#txtDatePicker2").val():"";
		var oc_no = $("#txtOCNo").val();
		var customer_name = $("#txtCustomerName").val();
		var customer_phone = $("#txtCustomerPhone").val();
		var broker_name = $("#txtBrokerName").val();
		var sales_center = $("#cboSalesCenter").val();
		var payment_type = $("#cboPaymentType").val();
		var payment = $("#cboPayment").val();

		$("#myTable").find("tbody").find("tr").remove(); 
		$.ajax({
			type: "POST",
			url: APP_URL + "api/sales/sales/search.php",
			data: JSON.stringify({ df: df, dt: dt, oc_no: oc_no, customer_name: customer_name, customer_phone: customer_phone, broker_name: broker_name, sales_center: sales_center, payment_type: payment_type, payment: payment })
		}).done(function(data) {	
			$("#loading").css("display","none");
			if(data.records.length>1){
				$("#total_records").text(" - " + data.records.length + " records found.");
			}else{
				$("#total_records").text(" - " + data.records.length + " record found.");
			}
			$.each(data.records, function(i, v) {
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.date + "</td>")
					.append("<td><span style='text-decoration: underline; color: blue; cursor: pointer;' onclick='goToDetail(\"" + v.oc_no + "\");' title='Detail'>" + v.oc_no + "</span></td>")
					.append("<td>" + v.sales_center + "</td>")
					.append("<td>" + v.customer_name + "</td>")
					.append("<td>" + v.customer_phone + "</td>")
					.append("<td>" + v.broker_name + "</td>")
					.append("<td>" + v.vin_no + "</td>")
					.append("<td>" + v.payment_type + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + v.deposit + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + v.rrp + "</td>")
					.append("<td style='text-align: right;'><span style='text-decoration: underline; color: green; cursor: pointer;' onclick='goToPaymentHistory(\"" + v.oc_no + "\");' title='Payment History'>" + v.payment + "</span></td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + v.deposit_refund + "</td>")
					.append("<td style='padding-right: 6px !important;'>" + ((v.action_dp_refund)?"<button type='button' class='btn btn-danger'  style='padding: 4px 10px; font-size: 13px !important;' title='Deposit Refund' onclick='goToDepositRefund(this);'>Refund</button>":"") + "</td>")

				);
			});
       });
	}

	function goToPaymentHistory(oc_no, obj){
		$("#myModalPaymentHistory").modal('show');
		$("#txtOCNOPH").text(oc_no);
		getAllPayment(oc_no);
	}

	function getAllPayment(oc_no){
        $("#myTablePayment").find("tbody").find("tr").remove();
        $.ajax({
            type: "POST",
            url: APP_URL + "api/sales/payment/get_all_rows.php",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {
            $.each(data.detailInfo, function(i, v) {
                var img = "";
                if(v.receipt){
                    img = "<center><img src='" + APP_URL + "api/sales/payment/upload/" + oc_no + "/" + v.receipt + "' onclick='showImage(this)' style='width:auto; height:50px'/></center>";
                }
                // Payment
                $("#myTablePayment").find("tbody")
                .append($('<tr>')
                    .append("<td>" + (i + 1) + "</td>")
                    .append("<td>" + v.date + "</td>")
                    .append("<td>" + v.gl_code + "</td>")
                    .append("<td>" + v.gl_code_bank_or_cash + "</td>")
                    .append("<td>" + v.paid_by + "</td>")
                    .append("<td style='text-align:right;'>" + v.amount + "</td>")
                    .append("<td>" + v.description + "</td>")
                    .append("<td>" + img + "</td>")
                    .append("<td>" + v.entry_date_time + "</td>")
                );
                // Payment
            });
       });
    }

    function showImage(obj){
	    $("#sf_img_large").removeClass("rotate_90");
	    var aspectRatio = $(obj).width()/$(obj).height();
		$("#sf_img_large").attr("src", $(obj).attr("src"));
		$(".modal-body img").each(function() { 
			//var aspectRatio = $(this).width()/$(this).height();
			console.log(aspectRatio);
			if(aspectRatio>1){
				$(this).addClass("rotate_90");
				$(this).css("width","100%");
				$(this).css("height","auto");
			}else{
				$(this).css("width","100%");
				$(this).css("height","auto");
			}
	    });
		// $(".modal-title").text($(obj).closest("tr").find("td").eq(2).text());
		$("#myModal").modal('show');
	    $("#myModal").modal('show');
   }

	function goToDetail(oc_no){
		document.location = APP_URL + "sales/sales_detail.php?act=detail&oc_no=" + oc_no;
	}

	function goToDepositRefund(obj){
		document.location = APP_URL + "finance/deposit_refund.php?act=entry&oc_no=" + $(obj).parent().parent().find("td").eq(2).text();
	}
</script>
