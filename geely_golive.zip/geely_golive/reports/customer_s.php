<?php include '../header.php'; ?>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-md-6">
                    <h1>Customer - Report</h1>
                </div>
                <div class="col-md-6"></div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Search</h3>
                        </div>
                        <div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
                            <i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
                        </div>
                        <form role="form">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Sales Center: </label>
                                            <div class="col-md-8">
                                                <select class="form-control" id="cboSalesCenter"></select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Customer Name:</label>
                                            <div class="col-md-8">
                                                <input type="text" id="txtCustomerName" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Staff Name:</label>
                                            <div class="col-md-8">
                                                <input type="text" id="txtStaffName" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-4"></div>
                                            <div class="col-md-4">
                                                <button type="button" class="btn btn-primary btn-block" onclick="search()">Search</button>
                                            </div>
                                            <div class="col-md-4">
                                                <button type="button" id="btnExport" value=" Export Table data into Excel " datafrom="myTable" class="btn btn-success btn-block exportToExcel">Export Data</button> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="card card-outline card-primary">
                <div class="card-header">
                    <h3 class="card-title">Customer List <span id="total_records" style="font-weight:bold;"> </span></h3>
                    <div class="card-tools">
                        <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                        <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <table class="table table-responsive table-striped table-bordered" id="myTable">
                        <thead>                  
                            <tr>
                                <th style="width: 3%; text-align: center; vertical-align: middle;">#</th>
                                <th style="text-align: center; vertical-align: middle;">Registration No.</th>
                                <th style="text-align: center; vertical-align: middle;">Sales Center</th>
                                <th style="text-align: center; vertical-align: middle;">Staff Name</th>
                                <th style="text-align: center; vertical-align: middle;">Customer Name</th>
                                <th style="text-align: center; vertical-align: middle;">Customer Phone</th>
                                <th style="text-align: center; vertical-align: middle;">NRC No.</th>
                                <th style="text-align: center; vertical-align: middle;">Township</th>
                                <th style="text-align: center; vertical-align: middle;">Sales Status</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>
<?php include '../footer.php'; ?>
<script>
    $(function(){
        $("body").addClass("sidebar-collapse"); 
        getAllSalesCenter();
    }); 

    $(".exportToExcel").click(function(){
        exportExcel("#myTable");
    }); 

    function getAllSalesCenter(){
        $("#cboSalesCenter").find("option").remove();
        $("#cboSalesCenter").append("<option value=''>All</option>");
        $.ajax({
            url: APP_URL + "api/sales_center/get_all_rows.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboSalesCenter").append("<option value='" + v.name + "'>" + v.name + "</option>");
            });
        });
    }


    function search(){
        $("#loading").css("display","block");
        var sales_center = $("#cboSalesCenter").val();
        var name = $("#txtCustomerName").val();
        var staff_name = $("#txtStaffName").val();

        $("#myTable").find("tbody").find("tr").remove(); 
        $.ajax({
            type: "POST",
            url: APP_URL + "api/sales/customer/search.php",
            data: JSON.stringify({ sales_center: sales_center, name: name, staff_name: staff_name })
        }).done(function(data) {    
            $("#loading").css("display","none");
            if(data.records.length>1){
                $("#total_records").text(" - " + data.records.length + " records found.");
            }else{
                $("#total_records").text(" - " + data.records.length + " record found.");
            }
            $.each(data.records, function(i, v) {
                $("#myTable").find("tbody")
                .append($('<tr>')
                    .append("<td>" + (i + 1) + "</td>")
                    .append("<td><span style='text-decoration: underline; color: blue; cursor: pointer;' onclick='goToDetail(\"" + v.id + "\");' title='Detail'>" + v.registration_no + "</span></td>")
                    .append("<td>" + v.sales_center + "</td>")
                    .append("<td>" + v.staff_name + "</td>")
                    .append("<td>" + v.name + "</td>")
                    .append("<td>" + v.mobile_no + "</td>")
                    .append("<td>" + v.nrc_no + "</td>")
                    .append("<td>" + v.township + "</td>")
                    .append("<td>" + v.sales_status + "</td>")
                );
            });
       });
    }

    function goToDetail(id){
        document.location = APP_URL + "sales/customer.php?act=detail&rid=" + id;
    }
</script>
