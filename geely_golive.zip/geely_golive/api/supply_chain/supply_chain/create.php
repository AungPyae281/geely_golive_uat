<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/car_stock.php';
	include_once '../../objects/car_stock_transfer.php'; 

	session_start();
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();

	$car_stock = new CarStock($db);
	$car_stock_transfer = new CarStockTransfer($db); 
	$data = json_decode(file_get_contents("php://input"));

	$ft_status = $data->to_from;
	if($data->to_from=='InhouseRP' || $data->to_from=='InhouseBW'){
		$ft_status ='Inhouse';
	}

	$car_stock_transfer->from = $data->from;
	$car_stock_transfer->to = $ft_status;
	$car_stock_transfer->transfer_date = "";
	$car_stock_transfer->transfer_time = "";
	$car_stock_transfer->arrival_date = $data->arrival_date;
	$car_stock_transfer->arrival_time = "";
	$car_stock_transfer->departure_mileage = 0;
	$car_stock_transfer->departure_fuel_level = 0;
	$car_stock_transfer->arrival_mileage = 0;
	$car_stock_transfer->arrival_fuel_level = 0;
	$car_stock_transfer->transfer_reason = "";
	$car_stock_transfer->driver_id = 0;
	$car_stock_transfer->entry_by = $_SESSION['user'];
	$car_stock_transfer->entry_date_time = date("Y-m-d H:i:s");

	foreach ($data->re_list as $cslist) {
		$car_stock->id = $cslist->car_stock_id;
		$car_stock->stock_status = $ft_status;
		$car_stock_transfer->car_stock_id = $cslist->car_stock_id;
		$car_stock_transfer->t_name = $cslist->t_name;
		$car_stock_transfer->t_phone = $cslist->t_phone;
		if($cslist->t_name){
			$car_stock_transfer->transporter = "Company";
		}else{
			$car_stock_transfer->transporter = "";
		}
		if($car_stock->updateSupplyChainReceive()){
			$car_stock_transfer->create();
		}else{
			$arr = array(
				"message" => "errorUpdate"
			);
			echo json_encode($arr);
			die();
		}	
	}
	$arr = array(
		"message" => "created"
	);
	echo json_encode($arr);
?>