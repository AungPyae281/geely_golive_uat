<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/car_list.php';

	$database = new Database();
	$db = $database->getConnection();

	$car_list = new CarList($db);
	$data = json_decode(file_get_contents("php://input"));

	$car_list->brand = $data->brand;
	$car_list->model = $data->model;
	$car_list->model_year = $data->model_year;
	$car_list->grade_id = $data->grade_id;
	$car_list->grade = $data->grade;
	$car_list->engine_power = $data->engine_power;
	$car_list->interior_color = $data->interior_color;
	$car_list->exterior_color = $data->exterior_color;

	if($data->id){
		$car_list->id = $data->id;
		
		if($car_list->isExist()){
			$arr = array(
				"message" => "duplicate"
			);
		}else{
			if($car_list->update()){
				$arr = array(
					"message" => "updated"
				);
			}else{
				$arr = array(
					"message" => "errorUpdate"
				);
			}
		}
	}else{
		if($car_list->isExist()){
			$arr = array(
				"message" => "duplicate"
			);
		}else{
			if($car_list->create()){
				$arr = array(
					"message" => "created"
				);
			}else{
				$arr = array(
					"message" => "errorCreate"
				);
			}
		}
	}
	echo json_encode($arr);
?>