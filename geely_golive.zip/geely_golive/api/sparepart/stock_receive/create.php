<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart_stock_receive.php';
    include_once '../../objects/sparepart_stock_balance.php';

    session_start();
    date_default_timezone_set('Asia/Rangoon');

    $database = new Database();
    $db = $database->getConnection();
     
    $sparepart_stock_receive = new SparepartStockReceive($db);
    $sparepart_stock_balance = new SparepartStockBalance($db);
    $data = json_decode(file_get_contents("php://input"));
    
    if($_SESSION['user']!=""){
        
        $sparepart_stock_receive->transfer_no = $data->transfer_no;
        $sparepart_stock_receive->date = $data->date;
        $sparepart_stock_receive->store_name = $data->store_name; 
        $sparepart_stock_receive->receive_by = $data->receive_by;

        $sparepart_stock_receive->entry_by = $_SESSION['user'];
        $sparepart_stock_receive->entry_date_time = date("Y-m-d H:i:s");

        $sparepart_stock_balance->store_name = $data->store_name;  

        foreach ($data->stock_details as $detail) { 

            $sparepart_stock_receive->sparepart_code = $detail->sparepart_code;
            $sparepart_stock_receive->sparepart_name = $detail->sparepart_name;
            $sparepart_stock_receive->quantity = $detail->quantity;

            $sparepart_stock_balance->sparepart_code = $detail->sparepart_code;
            $sparepart_stock_balance->sparepart_name = $detail->sparepart_name;
            $sparepart_stock_balance->reason = "Receive";
            $sparepart_stock_balance->quantity = $detail->quantity;

            if($sparepart_stock_receive->create()){
                if($sparepart_stock_balance->isExist()){
                    if(!$sparepart_stock_balance->updateFromStockReceive()){
                        $msg_arr = array(
                            "message" => "errorStockBalanceUpdate"
                        );
                        echo json_encode($msg_arr);
                        die();
                    }
                }else{
                    if(!$sparepart_stock_balance->createFromStockReceive()){
                        $msg_arr = array(
                            "message" => "errorStockBalanceCreate"
                        );
                        echo json_encode($msg_arr);
                        die();
                    }
                }
            }else{
                $msg_arr = array(
                    "message" => "errorStockReceiveCreate"
                );
                echo json_encode($msg_arr);
                die();
            }
        }
        $msg_arr = array(
            "message" => "created"
        );
    }else{
        $msg_arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($msg_arr);
?>