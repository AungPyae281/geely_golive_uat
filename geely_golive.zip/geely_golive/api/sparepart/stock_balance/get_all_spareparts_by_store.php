<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart_stock_balance.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $sparepart_stock_balance = new SparepartStockBalance($db);   

    $sparepart_stock_balance->store_name = $_GET["store_name"]; 

    $stmt = $sparepart_stock_balance->getAllSparepartsByStore();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["data"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                $group_name,
                $sub_group_name,
                $sparepart_code,
                $sparepart_name,
                $category,
                number_format((int)$bal_qty)
            );
            array_push($arr["data"], $detail);
        }
    }
    echo json_encode($arr);
?>