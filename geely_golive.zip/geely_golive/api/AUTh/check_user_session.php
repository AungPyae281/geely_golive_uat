<?php
    session_start();
    date_default_timezone_set('Asia/Rangoon');
    
    if(!isset($_SESSION['user'])){
		header("location:http://103.101.16.250:9090/geely_golive/login.html");
    }else{
        $now = time(); // checking the time now when home page starts
        if($now > $_SESSION['expire'])
        {
            session_destroy();
            header("location:http://103.101.16.250:9090/geely_golive/login.html");
        }
    }
?>