<?php
	// required headers
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	
	// include database and object files
	include_once '../config/database.php';
	include_once '../objects/route.php';
	 
	// instantiate database
	$database = new Database();
	$db = $database->getConnection();
	 
	// initialize object
	$route = new Route($db);
	
	$stmt = $route->getAllDashboard();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$d = array(
				"dashboard" => $dashboard
			);
			array_push($arr["records"], $d);
		}
	}
	echo json_encode($arr);
?>