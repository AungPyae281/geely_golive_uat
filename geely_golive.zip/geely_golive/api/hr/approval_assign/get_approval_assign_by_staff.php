<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/approval_assign.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $approval_assign = new ApprovalAssign($db);
    $data = json_decode(file_get_contents("php://input"));

    $approval_assign->staff_id = $data->staff_id;

    $stmt = $approval_assign->getApprovalAssignByStaff();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $detail = array(
                "id" => $id,
                "staff_id" => $staff_id,
                "staff_name" => $staff_name,
                "approval_staff_id" => $approval_staff_id,
                "approval_staff_name" => $approval_staff_name,
                "process" => $process,
                "order_no" => $order_no,
                "condition" => $condition,
                "permission_edit" => (int)$permission_edit
            );
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>