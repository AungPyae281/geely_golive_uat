<?php
    // required headers
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: POST");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/staff.php';
    include_once '../../objects/user.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $staff = new Staff($db);
    $user = new User($db);
    $data = json_decode($_POST['objArr']);

    if($_SESSION["user"]!=""){
        $targetPathSig = "";

        $img = $_FILES['fileSig'];

        if(!empty($_FILES['fileSig']))
        {
            $ext = pathinfo($_FILES['fileSig']['name'], PATHINFO_EXTENSION);
            if($ext){
                $newnamesig = date("Y.m.d.H.i.s") .  "." . $ext;
                $targetPathSig = './signature/' . $newnamesig;
                move_uploaded_file($_FILES['fileSig']['tmp_name'],$targetPathSig);
                $staff->signature = $newnamesig;
            }
        }

        $targetPathID = "";

        $img1 = $_FILES['fileID'];

        if(!empty($_FILES['fileID']))
        {
            $ext1 = pathinfo($_FILES['fileID']['name'], PATHINFO_EXTENSION);
            if($ext1){
                $newnameid = date("Y.m.d.H.i.s") .  "." . $ext1;
                $targetPathID = './id_card/' . $newnameid;
                move_uploaded_file($_FILES['fileID']['tmp_name'],$targetPathID);
                $staff->id_card = $newnameid;
            }
        }

        $staff->card_no = $data[0]->card_no;
        $staff->name = $data[0]->name;
        $staff->join_date = $data[0]->join_date;
        $staff->department = $data[0]->department;
        $staff->position = $data[0]->position;
        $staff->dob = $data[0]->dob;
        $staff->nrc_no = $data[0]->nrc_no;
        $staff->gender = $data[0]->gender;
        $staff->marital_status = $data[0]->marital_status;
        $staff->phone = $data[0]->phone;
        $staff->email = $data[0]->email;
        $staff->contact_address = $data[0]->contact_address;
        $staff->permanent_address = $data[0]->permanent_address;
        $staff->reporting_to_id = $data[0]->reporting_to_id;

        $staff->wt_monday = $data[0]->wt_monday;
        $staff->wt_tuesday = $data[0]->wt_tuesday;
        $staff->wt_wednesday = $data[0]->wt_wednesday;
        $staff->wt_thursday = $data[0]->wt_thursday;
        $staff->wt_friday = $data[0]->wt_friday;
        $staff->wt_saturday = $data[0]->wt_saturday;
        $staff->wt_sunday = $data[0]->wt_sunday;

        $staff->entry_by = $_SESSION['user'];
        $staff->entry_date_time = date("Y-m-d H:i");

        if(!$data[0]->id){
            if($staff->checkCardNo()){
                $msg_arr = array(
                    "message" => "duplicate"
                );
            }else{
                if($staff->create()){
                    $msg_arr = array(
                        "message" => "created"
                    );
                }else{
                    $msg_arr = array(
                        "message" => "errorCreate"
                    );
                }
            }
        }else{
            $staff->id = $data[0]->id;
            if($staff->update()){

                $user->staff_id = $data[0]->id;
                $user->staff_name = $data[0]->name;

                if(!$user->updateStaff()){
                    $msg_arr = array(
                        "message" => "errorUpdateUser"
                    );
                    echo json_encode($msg_arr);
                    die();
                }
                $msg_arr = array(
                    "message" => "updated"
                );
            }else{
                $msg_arr = array(
                    "message" => "errorUpdate"
                );
            }
        }
    }else{
        $msg_arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($msg_arr);
?>