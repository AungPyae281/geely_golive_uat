<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/bank_account.php';

    date_default_timezone_set('Asia/Rangoon');

    $database = new Database();
    $db = $database->getConnection();

    $bank_account = new BankAccount($db);
    $data = json_decode(file_get_contents("php://input"));

    $bank_account->country = (!empty($data->country))?$data->country:"";
    $bank_account->currency = (!empty($data->currency))?$data->currency:"";
    $bank_account->date = date("Y-m-d");

    $stmt = $bank_account->getAllBankAccount();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $balance_mmk = $balance;
            if($currency!="MMK"){
                $balance_mmk = Round(($balance * $rate), 2);
            }
            $detail = array(
                "id" => (int)$id,
                "gl_code" => ($gl_code)?$gl_code:"",
                "country" => ($country)?$country:"",
                "bank_name" => ($bank_name)?$bank_name:"", 
                "branch" => ($branch)?$branch:"", 
                "swift_code" => ($swift_code)?$swift_code:"",   
                "account_no" => ($account_no)?$account_no:"",	
                "account_name" => ($account_name)?$account_name:"",
                "account_type" => ($account_type)?$account_type:"",
                "currency" => ($currency)?$currency:"",         
                "exchange_rate" => ($rate)?(float)ROUND($rate, 2):"",         
                "balance" => ($balance)?(float)$balance:0,    
                "balance_mmk" => (float)$balance_mmk
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>