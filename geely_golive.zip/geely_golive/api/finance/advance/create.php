<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/advance.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $advance = new Advance($db);
    $data = json_decode($_POST['objArr']);

    $targetPath = "";
    $newname = "";

    if(!empty($_FILES['file']))
    {
        $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        if($ext==""){
            $targetPath = "./upload/no_image.jpg";
        }else{
            $newname = date("Y-m-d H-i-s") .  "." . $ext;
            $targetPath = './upload/' . $newname;
            copy($_FILES['file']['tmp_name'], $targetPath);
        }  
    }
    $advance->upload_receipt = $newname;  

    $advance->date = $data[0]->date;
    $advance->due_days = $data[0]->due_days;
    $advance->gl_code_to = $data[0]->gl_code_to;
    $advance->amount = $data[0]->amount;
    $advance->description = $data[0]->description;
    $advance->advance_by = $data[0]->advance_by; 
    $advance->gl_code_from = $data[0]->gl_code_from; 

    $advance->entry_by = $_SESSION['user'];
    $advance->entry_date_time = date("Y-m-d H:i:s");

    if($advance->create()){
        $msg_arr = array(
            "message" => "created"
        );
    }else{
        $msg_arr = array(
            "message" => "error"
        );
    }
    echo json_encode($msg_arr);
?>