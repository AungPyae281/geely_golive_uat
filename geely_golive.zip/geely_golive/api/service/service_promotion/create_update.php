<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service_promotion.php';
	include_once '../../objects/service_promotion_package.php';
	include_once '../../objects/service_promotion_gift.php';
	include_once '../../objects/service_promotion_sparepart.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start(); 

	$database = new Database();
	$db = $database->getConnection();

	$service_promotion = new ServicePromotion($db);
	$service_promotion_package = new ServicePromotionPackage($db);
	$service_promotion_gift = new ServicePromotionGift($db);
	$service_promotion_sparepart = new ServicePromotionSparepart($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$service_promotion->promotion_name = $data->promotion_name;
		$service_promotion->start_date = $data->start_date;
		$service_promotion->end_date = $data->end_date;
		$service_promotion->entry_by = $_SESSION['user'];
		$service_promotion->entry_date_time = date("Y-m-d H:i:s");

		if($data->id){
			$service_promotion->id = $data->id;
			if($service_promotion->update()){
				$service_promotion_package->service_promotion_id = $data->id;
				$service_promotion_gift->service_promotion_id = $data->id;
				$service_promotion_sparepart->service_promotion_id = $data->id;

				$service_promotion_package->delete();
				$service_promotion_gift->delete();
				$service_promotion_sparepart->delete();

				foreach($data->package_lists as $plist){
					$service_promotion_package->service_package_id = $plist->service_package_id;
					$service_promotion_package->discount_percent = $plist->discount_percent;

					if(!$service_promotion_package->create()){
						$msg_arr = array(
							"message" => "error"
						);
						echo json_encode($msg_arr);
						die();
					}
				}

				foreach($data->gift_lists as $glist){
					$service_promotion_gift->service_gift_id = $glist->service_gift_id;
					$service_promotion_gift->quantity = $glist->quantity;

					if(!$service_promotion_gift->create()){
						$msg_arr = array(
							"message" => "error"
						);
						echo json_encode($msg_arr);
						die();
					}
				}

				foreach($data->sparepart_lists as $slist){
					$service_promotion_sparepart->sparepart_code = $slist->sparepart_code;
					$service_promotion_sparepart->discount_percent = $slist->discount_percent;

					if(!$service_promotion_sparepart->create()){
						$msg_arr = array(
							"message" => "error"
						);
						echo json_encode($msg_arr);
						die();
					}
				}

				$msg_arr = array(
					"message" => "updated"
				);
			}else{
				$msg_arr = array(
					"message" => "errorU"
				);
			}
		}else{
			if($service_promotion->isExist()){
		        $msg_arr = array(
		            "message" => "duplicate"
		        );
		    }else{
		    	if($service_promotion->create()){
					foreach($data->package_lists as $plist){
						$service_promotion_package->service_promotion_id = $service_promotion->id;
						$service_promotion_package->service_package_id = $plist->service_package_id;
						$service_promotion_package->discount_percent = $plist->discount_percent;

						if(!$service_promotion_package->create()){
							$msg_arr = array(
								"message" => "errorP"
							);
							echo json_encode($msg_arr);
							die();
						}
					}

					foreach($data->gift_lists as $glist){
						$service_promotion_gift->service_promotion_id = $service_promotion->id;
						$service_promotion_gift->service_gift_id = $glist->service_gift_id;
						$service_promotion_gift->quantity = $glist->quantity;

						if(!$service_promotion_gift->create()){
							$msg_arr = array(
								"message" => "error"
							);
							echo json_encode($msg_arr);
							die();
						}
					}

					foreach($data->sparepart_lists as $slist){
						$service_promotion_sparepart->service_promotion_id = $service_promotion->id;
						$service_promotion_sparepart->sparepart_code = $slist->sparepart_code;
						$service_promotion_sparepart->discount_percent = $slist->discount_percent;

						if(!$service_promotion_sparepart->create()){
							$msg_arr = array(
								"message" => "error"
							);
							echo json_encode($msg_arr);
							die();
						}
					}

					$msg_arr = array(
						"message" => "created"
					);
				}else{
					$msg_arr = array(
						"message" => "errorC"
					);
				}
		    }
		}
	}
	echo json_encode($msg_arr);
?>