<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_package_detail.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $service_package_detail = new ServicePackageDetail($db);
    $data = json_decode(file_get_contents("php://input"));

    $service_package_detail->service_package_id = $data->service_package_id;
    
    $stmt = $service_package_detail->getServicePackageDetail();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
    		$detail = array(
                "code" => $code,
                "service_item" => $service_item,
                "waiting_time" => $waiting_time
            );
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>