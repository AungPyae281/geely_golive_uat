<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");   

    include_once '../../config/database.php';
    include_once '../../objects/service_appointment.php'; 
    
    session_start();  

    $database = new Database();
    $db = $database->getConnection();

    $service_appointment = new ServiceAppointment($db); 

    $arr = array();
    $arr["data"] = array();

    if($_SESSION['service_center']!=""){

        $service_appointment->service_center = $_SESSION['service_center'];

        $stmt = $service_appointment->getAllServiceAppointmentList();
        $num = $stmt->rowCount(); 

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row);
                $detail = array(
                    $plate_no,
                    $appointment_date,
                    $appointment_time,
                    $appointment_type,
                    $contact_person,
                    $contact_phone, 
                    $id
                );
                array_push($arr["data"], $detail);
            }
        }
    }
    echo json_encode($arr);
?>