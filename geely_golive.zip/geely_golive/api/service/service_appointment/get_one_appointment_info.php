<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service.php';
    include_once '../../objects/service_appointment.php';
    include_once '../../objects/service_appointment_item.php';
    include_once '../../objects/warranty_car.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $service = new Service($db);
    $service_appointment = new ServiceAppointment($db);
    $service_appointment_item = new ServiceAppointmentItem($db);
    $warranty_car = new WarrantyCar($db);
    $data = json_decode(file_get_contents("php://input"));

    $service_appointment->id = $data->id;
    $service_appointment_item->service_appointment_id = $data->id;
    $service_appointment->getOneAppointmentInfo();

    $service_appointment_items = array();

    $stmt = $service_appointment_item->getServiceAppointmentItem();
    $num = $stmt->rowCount();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "i_id" => $i_id,
                "code" => $code,
                "name" => $name,
                "i_waiting_time" => $i_waiting_time,
                "price" => number_format($price)
            );
            array_push($service_appointment_items, $detail);
        }
    }

    $service->plate_no = $service_appointment->plate_no;

    $warranty_car->plate_no = $service->plate_no;
    
    $stmt1 = $warranty_car->getValidWarrantyByPlateNo();
    $num1 = $stmt1->rowCount();
    $valid_warranty = array();

    if($num1>0){
        while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            array_push($valid_warranty, $warranty);
        }
    }

    $arr = array(
        "id" => $service_appointment->id,
        "service_car_id" => $service_appointment->service_car_id,
        "service_customer_id" => $service_appointment->service_customer_id,
        "plate_no" => $service_appointment->plate_no,
        "appointment_date" => $service_appointment->appointment_date,
        "appointment_time" => $service_appointment->appointment_time,
        "appointment_type" => $service_appointment->appointment_type,
        "contact_phone" => $service_appointment->contact_phone,
        "contact_person" => $service_appointment->contact_person,
        "service_center" => $service_appointment->service_center,
        "model" => $service_appointment->model,
        "vin_no" => $service_appointment->vin_no,
        "kilometer" => number_format($service->getLastKilometer()),
        "owner_name" => $service_appointment->owner_name,
        "owner_phone" => $service_appointment->owner_phone,
        "service_appointment_items" => $service_appointment_items,
        "valid_warranty" => $valid_warranty
    );
    echo json_encode($arr);
?>