<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_bay_services.php';
    include_once '../../objects/service_appointment.php';

    $database = new Database();
    $db = $database->getConnection();

    $service_bay_services = new ServiceBayServices($db);
    $service_appointment = new ServiceAppointment($db);
    $data = json_decode(file_get_contents("php://input"));

    $service_bay_services->service_center = $data->service_center;
     
    $stmt1 = $service_bay_services->getAvailableServicesBySC();
    $num1 = $stmt1->rowCount();
    $arr = array();
    $arr["records"] = array();
    
    if($num1>0){
        while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array( 
                "id" => $id,
                "name" => $name,
                "waiting_time" => $waiting_time,
                "price" => $price,
                "aval_qty" => (int)$aval_qty,
                "col1" => 0,
                "col2" => 0,
                "col3" => 0,
                "col4" => 0,
                "col5" => 0
            );
            array_push($arr["records"], $detail);
        }
    }    

    $start_date = $data->start_date;
    $end_date = date('Y-m-d', strtotime($start_date . '+4 days'));

    $service_appointment->service_center = $data->service_center;
    $service_appointment->appointment_time = $data->time;

    $x = 0;
    while ($start_date<=$end_date) {
        ++$x;
        $arr[$x] = $start_date;
        $service_appointment->appointment_date = $start_date;

        $stmt2 = $service_appointment->getUsedServices();
        $num2 = $stmt2->rowCount();
        $arr_useditem = array();
        
        if($num2>0){
            while ($row = $stmt2->fetch(PDO::FETCH_ASSOC)){
                extract($row);
                $chk_val = array_search($service_item_id, array_column($arr["records"], 'id'));
                if(gettype($chk_val)=="integer"){
                    $arr["records"][$chk_val]["col" . $x] = (int)$used_qty;
                }
            }
        }  
        $start_date = date('Y-m-d', strtotime($start_date . '+1 day'));
    }
    echo json_encode($arr);
?>