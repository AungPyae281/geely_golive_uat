<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service.php';
    include_once '../../objects/service_payment.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $service = new Service($db);
    $service_payment = new ServicePayment($db);
    $data = json_decode($_POST['objArr']);

    if($_SESSION['user']!=""){

        $targetPath = "";
        $newname = "";

        if(!empty($_FILES['file']))
        {
            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
            $newname = date("Y-m-d H-i-s") .  "." . $ext;
            $targetPath = './upload/' . $newname;
            copy($_FILES['file']['tmp_name'], $targetPath);
        }
        $service_payment->upload_receipt = $newname;  

        $service_payment->service_id = $data[0]->id;
        $service_payment->date = $data[0]->date;
        $service_payment->gl_code = $data[0]->gl_code;
        $service_payment->gl_code_bank_or_cash = $data[0]->gl_code_bank_or_cash;
        $service_payment->amount = $data[0]->amount;
        $service_payment->paid_by = $data[0]->paid_by; 
        $service_payment->description = $data[0]->description;

        $service_payment->entry_by = $_SESSION['user'];
        $service_payment->entry_date_time = date("Y-m-d H:i:s");

        if($service_payment->create()){

            $service->id = $data[0]->id;
            $service->car_return_date = date("Y-m-d");
            $service->car_return_time = date("H:i");
            $service->status = "Paid";

            $service->updateByPayment();

            $msg_arr = array(
                "message" => "created"
            );
        }else{
            $msg_arr = array(
                "message" => "error"
            );
        }
    }else{
        $msg_arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($msg_arr);
?>