<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service_detail_sparepart.php';
	include_once '../../objects/sparepart_stock_out.php';
	include_once '../../objects/sparepart_stock_balance.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start(); 

	$database = new Database();
	$db = $database->getConnection();

	$service_detail_sparepart = new ServiceDetailSparepart($db);
	$sparepart_stock_out = new SparepartStockOut($db);
	$sparepart_stock_balance = new SparepartStockBalance($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['service_center']!=""){
		
		$service_detail_sparepart->service_id = $data->service_id;

		$sparepart_stock_out->date = $data->date;
		$sparepart_stock_out->service_id = $data->service_id;
		$sparepart_stock_out->store_name = $data->store_name; 
		$sparepart_stock_out->damage = 0;
		$sparepart_stock_out->lost = 0;
		$sparepart_stock_out->stock_out_by = $data->stock_out_by;
		$sparepart_stock_out->remark = "";
		$sparepart_stock_out->entry_by = $_SESSION['user'];
		$sparepart_stock_out->entry_date_time = date("Y-m-d H:i:s"); 

		$sparepart_stock_balance->store_name = $data->store_name;  

		$out_of_stock_items = "";

		//Check Item Out of Stock
		foreach ($data->spareparts_lists as $splist) { 

			$sparepart_stock_balance->sparepart_code = $splist->sparepart_code;

			if($sparepart_stock_balance->checkSparepartForStockOut()){
				if((int)$sparepart_stock_balance->bal_qty<=0 || (int)$sparepart_stock_balance->bal_qty<(int)$splist->quantity){
					$out_of_stock_items .= (($out_of_stock_items=="")?'':'<br>') . '<b> - ' . $splist->sparepart_name . '</b>';
				}
			}else{
				$out_of_stock_items .= (($out_of_stock_items=="")?'':'<br>') . '<b> - ' . $splist->sparepart_name . '</b>';
			}
		}
		//Check Item Out of Stock

		if($out_of_stock_items==""){
			foreach ($data->spareparts_lists as $splist) { 

				$service_detail_sparepart->code = $splist->sparepart_code;
				$service_detail_sparepart->quantity = $splist->quantity;
				$service_detail_sparepart->warranty = $splist->warranty;

				$sparepart_stock_out->sparepart_code = $splist->sparepart_code;
				$sparepart_stock_out->sparepart_name = $splist->sparepart_name;
				$sparepart_stock_out->quantity = $splist->quantity;

				$sparepart_stock_balance->sign = "-";
				$sparepart_stock_balance->sparepart_code = $splist->sparepart_code;
				$sparepart_stock_balance->reason = "Issue Note";
				$sparepart_stock_balance->quantity = $splist->quantity;

				if($service_detail_sparepart->updateIssueNote()){

					if($sparepart_stock_out->create()){
						$sparepart_stock_balance->updateFromServiceIssueNote();
				        if(!$sparepart_stock_balance->updateFromStockOut()){
				            $msg_arr = array(
								"message" => "errorStockBalanceUpdate"
							);
							echo json_encode($msg_arr);
							die();
				        }  
				    }else{
				    	$msg_arr = array(
							"message" => "errorStockOutCreate"
						);
						echo json_encode($msg_arr);
						die();
				    }
				}else{
					$msg_arr = array(
						"message" => "errorServiceDetailSparepartUpdate"
					);
					echo json_encode($msg_arr);
					die();
				}
			}
			$msg_arr = array(
				"message" => "updated"
			);
		}else{
			$msg_arr = array(
				"message" => "out of stock",
				"out_of_stock_items" => $out_of_stock_items
			);
		}
	}else{
		
	}
	echo json_encode($msg_arr);
?>