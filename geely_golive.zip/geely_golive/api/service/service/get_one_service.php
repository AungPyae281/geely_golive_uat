<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service.php';
    include_once '../../objects/service_detail_service_item.php';
    include_once '../../objects/service_detail_sparepart.php';
    include_once '../../objects/warranty_car.php';

    date_default_timezone_set('Asia/Rangoon');
     
    $database = new Database();
    $db = $database->getConnection();

    $service = new Service($db);
    $service_detail_service_item = new ServiceDetailServiceItem($db);
    $service_detail_sparepart = new ServiceDetailSparepart($db);
    $warranty_car = new WarrantyCar($db);
    $data = json_decode(file_get_contents("php://input"));

    $service->id = $data->id;
    $service->getOneService();

    $service_items = array();
    $service_detail_service_item->service_id = $data->id;

    $stmt1 = $service_detail_service_item->getServiceDetail();
    $num1 = $stmt1->rowCount();

    if($num1>0){
        while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $detail = array(
                "id" => $id,
                "service_type" => $service_type,
                "package_id" => (int)$package_id,
                "package_name" => $package_name,
                "item_code" => $item_code,
                "item_name" => $item_name,
                "item_wt" => $item_wt,
                "item_price" => number_format($item_price),
                "warranty" => (int)$warranty,
                "package_price" => number_format($package_price),
                "technician_id" => (int)$technician_id,
                "technician_name" => $technician_name,
                "bay_no" => $bay_no,
                "start_time" => (($start_time!="")?date('h:i A', strtotime($start_time)):""),
                "end_time" => (($end_time!="")?date('h:i A', strtotime($end_time)):"")
            );
            array_push($service_items, $detail);
        }
    }

    $spareparts = array();
    $service_detail_sparepart->service_id = $data->id;
    
    $stmt2 = $service_detail_sparepart->getSparepartDetail();
    $num2 = $stmt2->rowCount();

    if($num2>0){
        while ($row = $stmt2->fetch(PDO::FETCH_ASSOC)) {
            extract($row);
            $detail = array(
                "id" => $id,
                "code" => $code,
                "name" => $name,
                "qty" => (int)$qty,
                "receive_qty" => (int)$receive_qty,
                "price" => number_format($price),
                "amount" => ((int)$warranty==1)?0:number_format((int)$qty * (int)$price),
                "warranty" => (int)$warranty
            );
            array_push($spareparts, $detail);
        }
    }

    $valid_warranty = array();
    $warranty_car->plate_no = $service->plate_no;
    $stmt3 = $warranty_car->getValidWarrantyByPlateNo();
    $num3 = $stmt3->rowCount();

    if($num3>0){
        while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)) {
            extract($row3);
            array_push($valid_warranty, $warranty);
        }
    }
     
    $arr = array(
        "id" =>  $service->id,
        "appointment_id" => $service->appointment_id,
        "service_center" => $service->service_center,
        "registration_no" => $service->registration_no,
        "owner_name" => $service->owner_name,
        "owner_phone" => $service->owner_phone,
        "appt_contact_person" => $service->appt_contact_person,
        "appt_contact_phone" => $service->appt_contact_phone,
        "service_customer_id" => $service->service_customer_id,
        "contact_person" => $service->contact_person,
        "contact_phone" => $service->contact_phone,
        "service_car_id" => $service->service_car_id,
        "plate_no" => $service->plate_no,
        "model" => $service->model,
        "vin_no" => $service->vin_no,
        "engine_no" => $service->engine_no,
        "kilometer" => number_format($service->kilometer),
        "car_receive_date" => $service->car_receive_date,
        "car_receive_time" => (($service->car_receive_time!="")?date('h:i A', strtotime($service->car_receive_time)):""),
        "insp_service_booklet" => (int)$service->insp_service_booklet,
        "insp_jack_and_handle" => (int)$service->insp_jack_and_handle,
        "insp_paking_sign" => (int)$service->insp_paking_sign,
        "insp_spare_wheel" => (int)$service->insp_spare_wheel,
        "insp_mobile_charger" => (int)$service->insp_mobile_charger,
        "insp_car_key" => (int)$service->insp_car_key,
        "insp_wheel_tax" => (int)$service->insp_wheel_tax,
        "insp_fuel_level" => (int)$service->insp_fuel_level,
        "insp_other_items" => $service->insp_other_items,
        "insp_remark" => $service->insp_remark,
        "car_inspection_img" => $service->car_inspection_img,
        "main_technician_id" => $service->main_technician_id,
        "main_technician_name" => $service->main_technician_name,
        "sa_id" => $service->sa_id,
        "sa_name" => $service->sa_name,
        "visit_type" => $service->visit_type,
        "promotion" => $service->promotion,
        "total_waiting_time" => $service->total_waiting_time,
        "service_remark" => $service->service_remark,
        "test_drive_agree" => (int)$service->test_drive_agree, 
        "discount" => number_format((int)$service->discount), 
        "status" => $service->status,
        "service_items" => $service_items,
        "spareparts" => $spareparts,
        "valid_warranty" => $valid_warranty
    );
    echo json_encode($arr);
?>