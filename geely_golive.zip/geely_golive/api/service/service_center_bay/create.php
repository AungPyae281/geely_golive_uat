<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service_center_bay.php';
	session_start();

	$database = new Database();
	$db = $database->getConnection();

	$service_center_bay = new ServiceCenterBay($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$service_center_bay->service_center_id = $data->service_center_id;
		$service_center_bay->bay_no = $data->bay_no;

		if($service_center_bay->isExist()){
			$msg_arr = array(
				"message" => "duplicate"
			);
		}else{
			if($service_center_bay->create()){
				$msg_arr = array(
					"message" => "created"
				);
			}else{
				$msg_arr = array(
					"message" => "error"
				);
			}
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>