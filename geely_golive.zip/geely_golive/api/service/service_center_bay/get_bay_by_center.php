<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service_center_bay.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $service_center_bay = new ServiceCenterBay($db);
    $data = json_decode(file_get_contents("php://input"));

    $service_center_bay->service_center = $data->service_center;   

    $stmt = $service_center_bay->getBayByCenter();
    $num = $stmt->rowCount();

    $arr = array();
    $arr["records"] = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                "bay_no" => $bay_no
            );  
            array_push($arr["records"], $detail);
        }
    }
    echo json_encode($arr);
?>