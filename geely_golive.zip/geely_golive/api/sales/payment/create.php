<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/payment.php';
    include_once '../../objects/sales.php';   
        
    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $payment = new Payment($db);
    $sales = new Sales($db);
    $data = json_decode($_POST['objArr']);

    if($_SESSION['staff_id']!=""){
        $targetPath = "";
        $img = "";

        if(!empty($_FILES['file-payment']))
        {
            $ext = pathinfo($_FILES['file-payment']['name'], PATHINFO_EXTENSION);
            if($ext!=""){
                if (!is_dir('./upload/' . $data[0]->oc_no)) {
                    mkdir('./upload/' . $data[0]->oc_no, 0777, true);
                }

                $newname = date("Y-m-d H-i-s") .  "." . $ext;
                $targetPath = './upload/' . $data[0]->oc_no . '/' . $newname;
                move_uploaded_file($_FILES['file-payment']['tmp_name'], $targetPath);
                $img = $newname;
            }   
        }

        $payment->oc_no = $data[0]->oc_no;
        $payment->gl_code = $data[0]->gl_code;
        $payment->gl_code_bank_or_cash = $data[0]->gl_code_bank_or_cash;
        $payment->date = $data[0]->date;
        $payment->paid_by = $data[0]->paid_by;
        $payment->receive_by = $_SESSION['user'];
        $payment->amount = $data[0]->amount;
        $payment->description = $data[0]->description;
        $payment->receipt = $img;
        $payment->entry_date_time = date("Y-m-d H:i:s");

        $sales->oc_no = $data[0]->oc_no;

        if($payment->create()){ 
            $payment->getPaymentPercentNBalance();
            $full_payment_percent = ROUND((((int)$payment->total_payment/(int)$payment->selling_price) * 100), 2);

            if($full_payment_percent>=50){ 
                $sales->checkStatus();
                if($sales->processing=="Payment"){ 
                    $sales->status = "Payment";
                    $sales->processing = "Purchase Permit";
                    
                    if(!$sales->updateStatus()){
                        $arr = array(
                            "message" => "Status Update Error"
                        );
                        echo json_encode($arr);
                        die();
                    }
                }else if($sales->processing=="Purchase Permit"){
                    $percent = 0;

                    if($payment->payment_type=="Cash"){
                        $percent = ROUND((((int)$payment->total_payment/((int)$payment->selling_price - 1000000)) * 100), 2);
                    }else{
                        $percent = ROUND((((int)$payment->total_payment/(int)$payment->selling_price) * 100), 2);
                    }

                    if($percent>=100 && (int)$sales->pp_done==1){
                        $sales->status = "Purchase Permit";
                        $sales->processing = "Income Tax";
                        
                        if(!$sales->updateStatus()){
                            $arr = array(
                                "message" => "Status Update Error"
                            );
                            echo json_encode($arr);
                            die();
                        }
                    }
                }
            }
            
            $arr = array(
                "message" => "created",
                "payment_percent" => $full_payment_percent
            );
        }else{
            $arr = array(
                "message" => "error"
            );
        }
    }else{
        $arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($arr);
?>