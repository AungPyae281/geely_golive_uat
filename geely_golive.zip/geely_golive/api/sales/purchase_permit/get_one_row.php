<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/purchase_permit.php';
    include_once '../../objects/sales.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $purchase_permit = new Purchase_Permit($db);
    $sales = new Sales($db);
    $data = json_decode(file_get_contents("php://input"));

    $purchase_permit->oc_no = $data->oc_no;

    $purchase_permit->getOneRow();

    $sales->oc_no = $data->oc_no;
    $sales->checkStatus();

    $arr = array(
        "id" => $purchase_permit->id,
        "entry_date" => $purchase_permit->entry_date,
        "permit_submission_date" => $purchase_permit->permit_submission_date,
        "permit_received_date" => $purchase_permit->permit_received_date,
        "oc_no" => $purchase_permit->oc_no,
        "name" => $purchase_permit->name,
        "nrc" => $purchase_permit->nrc,
        "mobile_no" => $purchase_permit->mobile_no,
        "email" => $purchase_permit->email,
        "address" => $purchase_permit->address,
        "sales_center" => $purchase_permit->sales_center,
        "bank" => $purchase_permit->bank,
        "ac_no" => $purchase_permit->ac_no,
        "foreign_currency_balance" => $purchase_permit->foreign_currency_balance,
        "balance_date" => $purchase_permit->balance_date,
        "vehicle_type" => $purchase_permit->vehicle_type,
        "brand" => $purchase_permit->brand,
        "model_year" => $purchase_permit->model_year,
        "engine_power" => $purchase_permit->engine_power,
        "value" => $purchase_permit->value,
        "country_of_origin" => $purchase_permit->country_of_origin,
        "commission" => $purchase_permit->commission,
        "according_to" => $purchase_permit->according_to,
        "other_name" => $purchase_permit->other_name,
        "other_nrc" => $purchase_permit->other_nrc,
        "other_address" => $purchase_permit->other_address, 
        "pp_done" => ($sales->pp_done)?(int)$sales->pp_done:0
    );
    echo json_encode($arr);
?>