<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/due_date_setting.php';	

	$database = new Database();
	$db = $database->getConnection();
	 
	$due_date_setting = new DueDateSetting($db);
	$data = json_decode(file_get_contents("php://input"));

	$due_date_setting->id = $data->id;
	$due_date_setting->due_day = $data->due_day;
	$due_date_setting->due_hour = $data->due_hour;

	if($due_date_setting->update()){
		$msg_arr = array(
			"message" => "updated"
		);
	}else{
		$msg_arr = array(
			"message" => "error"
		);
	}
	echo json_encode($msg_arr);
?>