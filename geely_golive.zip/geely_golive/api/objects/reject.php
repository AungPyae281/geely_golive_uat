<?php
class Reject{
	private $conn;
	private $table_name = "reject";

	public $id;
	public $role;
	public $staff_id;
	public $main_id;
	public $order_no;
	public $process;
	public $reject_date_time;
	public $remark; 
	public $fixed;

	public function __construct($db){
		$this->conn = $db;
	}

    function create(){
		$query = "INSERT INTO `" . $this->table_name . "` SET role=:role, staff_id=:staff_id, main_id=:main_id, `process`=:process, reject_date_time=:reject_date_time, remark=:remark, order_no=:order_no";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":role", $this->role);
		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->bindParam(":main_id", $this->main_id);
		$stmt->bindParam(":process", $this->process);
		$stmt->bindParam(":reject_date_time", $this->reject_date_time);
		$stmt->bindParam(":remark", $this->remark);
		$stmt->bindParam(":order_no", $this->order_no);

		if($stmt->execute()){
			return true;
		}
		return false;
    }

    function createForOC(){
		$query = "INSERT INTO `" . $this->table_name . "` SET role=:role, staff_id=:staff_id, main_id=:main_id, `process`=:process, reject_date_time=:reject_date_time, remark=:remark, order_no=:order_no; UPDATE approval SET approve=0 WHERE main_id=:main_id AND `process`=:process AND order_no=" . $this->previous_order_no;
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":role", $this->role);
		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->bindParam(":main_id", $this->main_id);
		$stmt->bindParam(":process", $this->process);
		$stmt->bindParam(":reject_date_time", $this->reject_date_time);
		$stmt->bindParam(":remark", $this->remark);
		$stmt->bindParam(":order_no", $this->order_no);

		if($stmt->execute()){
			return true;
		}
		return false;
    }

    // function updateReject(){
	// 	$query = "UPDATE `" . $this->table_name . "` SET fixed=1 WHERE main_id=:main_id AND `process`=:process AND order_no=:order_no";
		 
	// 	$stmt = $this->conn->prepare($query);
		
	// 	$stmt->bindParam(":main_id", $this->main_id);
	// 	$stmt->bindParam(":process", $this->process);
	// 	$stmt->bindParam(":order_no", $this->order_no);

	// 	if($stmt->execute()){
	// 		return true;
	// 	}
	// 	return false;
    // }
}
?>