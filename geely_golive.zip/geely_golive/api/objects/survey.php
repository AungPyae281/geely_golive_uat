<?php
class Survey{ 
	private $conn;
	private $table_name = "survey"; 

	public $id;
	public $ser_one;
	public $ser_two;
	public $ser_three;
	public $ser_four;
	public $ser_five;
	public $contact_name;
	public $contact_phone;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET ser_one=:ser_one, ser_two=:ser_two, ser_three=:ser_three, ser_four=:ser_four, ser_five=:ser_five, contact_name=:contact_name, contact_phone=:contact_phone, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":ser_one", $this->ser_one);
		$stmt->bindParam(":ser_two", $this->ser_two);
		$stmt->bindParam(":ser_three", $this->ser_three);
		$stmt->bindParam(":ser_four", $this->ser_four);
		$stmt->bindParam(":ser_five", $this->ser_five);
		$stmt->bindParam(":contact_name", $this->contact_name);
		$stmt->bindParam(":contact_phone", $this->contact_phone);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		
		if($stmt->execute()){
			return true;
		}
		return false;
	}
}
?>