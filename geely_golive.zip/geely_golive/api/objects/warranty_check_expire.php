<?php
class WarrantyCheckExpire{
    private $conn;
    private $table_name = "warranty_check_expire";
 
	public $date;
 
    public function __construct($db){
        $this->conn = $db;
    }

	function checkDate(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE date=:date";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":date", $this->date);	
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function update(){
		$query = "INSERT INTO " . $this->table_name . " (`date`) VALUES (:date) ON DUPLICATE KEY UPDATE `date`=:date";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":date", $this->date);	
		if($stmt->execute()){
			return true;
		}
		return false;
	}
}
?>