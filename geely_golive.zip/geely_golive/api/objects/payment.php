<?php
class Payment{
    private $conn;
    private $table_name = "payment";
 
	public $id;
	public $oc_no;
	public $gl_code;
	public $gl_code_bank_or_cash;
	public $date;
	public $paid_by;
	public $receive_by;
	public $amount;
	public $description;
	public $receipt;
	public $entry_date_time;	
	
    public function __construct($db){
        $this->conn = $db;
    }

    function create(){
		$statement = "";
		if($this->receipt){
			$statement .= ", receipt=:receipt";
		}
		$query = "INSERT INTO " . $this->table_name . " SET oc_no=:oc_no, gl_code=:gl_code, gl_code_bank_or_cash=:gl_code_bank_or_cash, date=:date, paid_by=:paid_by, receive_by=:receive_by, amount=:amount, description=:description, entry_date_time=:entry_date_time" . $statement;
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":gl_code", $this->gl_code);	
		$stmt->bindParam(":gl_code_bank_or_cash", $this->gl_code_bank_or_cash);	
		$stmt->bindParam(":date", $this->date);	
		$stmt->bindParam(":paid_by", $this->paid_by);	
		$stmt->bindParam(":receive_by", $this->receive_by);
		$stmt->bindParam(":amount", $this->amount);	
		$stmt->bindParam(":description", $this->description);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);	
		if($this->receipt) $stmt->bindParam(":receipt", $this->receipt);

		if($stmt->execute()){ 
			return true;
		}	 
		return false;
	} 

	function getPaymentPercentNBalance(){
    	$query = "SELECT selling_price, deposit, payment_type, IFNULL(total_payment, 0) AS total_payment FROM (SELECT oc_no, SUM(amount) AS total_payment FROM payment GROUP BY oc_no) AS pm RIGHT JOIN sales ON pm.oc_no=sales.oc_no WHERE sales.oc_no=:oc_no";
		$stmt = $this->conn->prepare( $query );	 
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->selling_price = (int)$row['selling_price'];
			$this->deposit = (int)$row['deposit'];
			$this->payment_type = $row['payment_type'];
			$this->total_payment = (int)$row['total_payment'];
		}else{
			$this->selling_price = 0;
			$this->deposit = 0;
			$this->payment_type = "";
			$this->total_payment = 0;
		}
    }

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE oc_no=:oc_no ORDER BY date, entry_date_time";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->execute();
		return $stmt;
	}
}
?>
