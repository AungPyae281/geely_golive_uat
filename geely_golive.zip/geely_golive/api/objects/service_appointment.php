<?php
class ServiceAppointment{ 
	private $conn;
	private $table_name = "service_appointment"; 

	public $id;
	public $service_car_id;
	public $service_customer_id;
	public $plate_no;
	public $appointment_date;
	public $appointment_time;
	public $appointment_type;
	public $contact_phone;
	public $contact_person;
	public $service_center;
	public $total_waiting_time; 

	public function __construct($db){
		$this->conn = $db;
	} 

	function getAllServiceAppointmentList(){	
		$query = "SELECT service_appointment.* FROM " . $this->table_name . " LEFT JOIN service ON service_appointment.id=service.appointment_id WHERE service.appointment_id IS NULL AND service_appointment.service_center=:service_center ORDER BY service_appointment.appointment_date, service_appointment.appointment_time DESC";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}

	function getUsedServices(){
		$query = "SELECT service_item_id, COUNT(service_item_id) AS used_qty FROM " . $this->table_name . " AS sa LEFT JOIN service_appointment_item AS sai ON sa.id=sai.service_appointment_id WHERE sa.service_center=:service_center AND sa.appointment_date=:appointment_date AND sa.appointment_time=:appointment_time GROUP BY service_item_id";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->bindParam(":appointment_date", $this->appointment_date);
		$stmt->bindParam(":appointment_time", $this->appointment_time);
		$stmt->execute();
		return $stmt;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `plate_no`=:plate_no and appointment_date=:appointment_date LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->plate_no=htmlspecialchars(strip_tags($this->plate_no));
		$this->appointment_date=htmlspecialchars(strip_tags($this->appointment_date));

		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->bindParam(":appointment_date", $this->appointment_date);

		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_car_id=:service_car_id, service_customer_id=:service_customer_id, plate_no=:plate_no, `appointment_date`=:appointment_date, `appointment_time`=:appointment_time, appointment_type=:appointment_type, contact_phone=:contact_phone, contact_person=:contact_person, total_waiting_time=:total_waiting_time, service_center=:service_center";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_car_id", $this->service_car_id);
		$stmt->bindParam(":service_customer_id", $this->service_customer_id);
		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->bindParam(":appointment_date", $this->appointment_date);
		$stmt->bindParam(":appointment_time", $this->appointment_time);
		$stmt->bindParam(":appointment_type", $this->appointment_type);
		$stmt->bindParam(":contact_phone", $this->contact_phone);
		$stmt->bindParam(":contact_person", $this->contact_person);
		$stmt->bindParam(":total_waiting_time", $this->total_waiting_time);
		$stmt->bindParam(":service_center", $this->service_center);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;		
	}  

	function getOneAppointmentInfo(){	
		$query = "SELECT service_appointment.*, service_car.model, service_car.vin_no, service_customer.name AS owner_name, service_customer.phone_no AS owner_phone FROM service_appointment
LEFT JOIN service_car ON service_appointment.service_car_id=service_car.id
LEFT JOIN service_customer ON service_appointment.service_customer_id=service_customer.id
WHERE service_appointment.id=:id";
		$stmt = $this->conn->prepare($query);
			
		$stmt->bindParam(":id", $this->id);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];	
			$this->service_car_id = $row['service_car_id'];	
			$this->service_customer_id = $row['service_customer_id'];
			$this->plate_no = $row['plate_no'];		
			$this->appointment_date = $row['appointment_date'];	
			$this->appointment_time = $row['appointment_time'];
			$this->appointment_type = $row['appointment_type'];
			$this->contact_phone = $row['contact_phone'];	
			$this->contact_person = $row['contact_person'];
			$this->service_center = $row['service_center'];	
			$this->model = $row['model'];		
			$this->vin_no = $row['vin_no'];	
			$this->owner_name = $row['owner_name'];		
			$this->owner_phone = $row['owner_phone'];
		}
	}   
}
?>