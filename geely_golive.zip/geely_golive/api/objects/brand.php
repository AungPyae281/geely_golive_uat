<?php
class Brand{
    // database connection and table name
	private $conn;
	private $table_name = "brand";

    // object properties
    public $id;	
	public $brand;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY brand";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `brand` = :brand LIMIT 0, 1";
		$stmt = $this->conn->prepare( $query );
		$this->brand = htmlspecialchars(strip_tags($this->brand)); 
		$stmt->bindParam(":brand", $this->brand); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET brand=:brand"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":brand", $this->brand); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}
	
}
