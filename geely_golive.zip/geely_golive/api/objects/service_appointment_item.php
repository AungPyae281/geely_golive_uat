<?php
class ServiceAppointmentItem{ 
	private $conn;
	private $table_name = "service_appointment_item"; 

	public $id;
	public $service_appointment_id;
	public $service_item_id;
	public $waiting_time;

	public function __construct($db){
		$this->conn = $db;
	} 

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_appointment_id=:service_appointment_id, service_item_id=:service_item_id, waiting_time=:waiting_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_appointment_id", $this->service_appointment_id);
		$stmt->bindParam(":service_item_id", $this->service_item_id);
		$stmt->bindParam(":waiting_time", $this->waiting_time);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getServiceAppointmentItem(){
		$query = "SELECT sai.*, si.id AS i_id, `code`, `name`, si.waiting_time AS i_waiting_time, price FROM " . $this->table_name . " AS sai LEFT JOIN service_item AS si ON sai.service_item_id=si.id WHERE service_appointment_id=:service_appointment_id ORDER BY sai.id ";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_appointment_id", $this->service_appointment_id);
		$stmt->execute();
		return $stmt;
	} 
}
?>