<?php
class ServiceCenterBay{ 
	private $conn;
	private $table_name = "service_center_bay"; 

	public $id;
	public $service_center_id;
	public $bay_no;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE service_center_id = :service_center_id AND bay_no = :bay_no LIMIT 0,1";
		$stmt = $this->conn->prepare( $query ); 

		$stmt->bindParam(":service_center_id", $this->service_center_id);
		$stmt->bindParam(":bay_no", $this->bay_no);

		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_center_id=:service_center_id, bay_no=:bay_no"; 
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_center_id", $this->service_center_id);
		$stmt->bindParam(":bay_no", $this->bay_no);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$condition = "";
		if($this->service_center_id){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " service_center_id =:service_center_id ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}
		$query = "SELECT service_center_bay.*, service_center.`name` FROM " . $this->table_name . " LEFT JOIN service_center ON service_center_bay.service_center_id=service_center.id " . $condition . " ORDER BY service_center_id, service_center_bay.id";
		$stmt = $this->conn->prepare( $query );
		if($this->service_center_id) $stmt->bindParam(":service_center_id", $this->service_center_id);
		$stmt->execute();
		return $stmt;
	} 

	function getBayByCenter(){
		$query = "SELECT service_center_bay.bay_no FROM " . $this->table_name . " LEFT JOIN service_center ON service_center_bay.service_center_id=service_center.id WHERE service_center.`name`=:service_center ORDER BY bay_no";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}
}
?>