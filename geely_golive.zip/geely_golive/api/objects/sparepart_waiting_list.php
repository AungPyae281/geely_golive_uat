<?php
class SparepartWaitingList{ 
	private $conn;
	private $table_name = "sparepart_waiting_list"; 

	public $id;
	public $wl_id;
	public $service_center;
	public $service_customer_id;
	public $service_car_id;
	public $plate_no; 
	public $remark;
	public $cancel;
	public $entry_by;
	public $entry_date_time;
	public $cancel_by;
	public $cancel_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function getAllSparepartWaitingList(){	
		$query = "SELECT sparepart_waiting_list.*, service_customer.name, service_customer.phone_no FROM " . $this->table_name . " LEFT JOIN service_customer ON sparepart_waiting_list.service_customer_id=service_customer.id WHERE pre_order=0 AND cancel=0 AND service_center=:service_center ORDER BY wl_id";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->execute();
		return $stmt;
	}

	function generateCode(){
		$query = "SELECT RIGHT(wl_id, 6) AS wl_id FROM " . $this->table_name . " ORDER BY wl_id DESC LIMIT 0,1";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return sprintf("%06d", (($row['wl_id']) + 1));
		}else{
			return "000001";
		}
	} 

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET wl_id=:wl_id, service_center=:service_center, service_customer_id=:service_customer_id, service_car_id=:service_car_id, plate_no=:plate_no, remark=:remark, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":wl_id", $this->wl_id);
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->bindParam(":service_customer_id", $this->service_customer_id);
		$stmt->bindParam(":service_car_id", $this->service_car_id);
		$stmt->bindParam(":plate_no", $this->plate_no); 
		$stmt->bindParam(":remark", $this->remark);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;
	}

	function getOneWaitingList(){	
		$query = "SELECT sparepart_waiting_list.*, IFNULL(service_customer.name, '') AS customer_name, IFNULL(service_customer.phone_no, '') AS customer_phone FROM " . $this->table_name . " LEFT JOIN service_customer ON sparepart_waiting_list.service_customer_id=service_customer.id WHERE sparepart_waiting_list.id=:id";
		$stmt = $this->conn->prepare($query);
			
		$stmt->bindParam(":id", $this->id);

		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];	
			$this->wl_id = $row['wl_id'];	
			$this->service_center = $row['service_center'];			
			$this->service_customer_id = $row['service_customer_id'];	
			$this->customer_name = $row['customer_name'];	
			$this->customer_phone = $row['customer_phone'];	
			$this->service_car_id = $row['service_car_id'];	
			$this->plate_no = $row['plate_no']; 
			$this->remark = $row['remark'];
			$this->entry_by = $row['entry_by'];	
			$this->entry_date_time = $row['entry_date_time'];
		}
	}

	function updateCancel(){
		$query = "UPDATE " . $this->table_name . " SET `cancel`=:cancel, cancel_by=:cancel_by, cancel_date_time=:cancel_date_time WHERE id=:id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":cancel", $this->cancel); 
		$stmt->bindParam(":cancel_by", $this->cancel_by); 
		$stmt->bindParam(":cancel_date_time", $this->cancel_date_time); 
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function updatePreOrder(){
		$query = "UPDATE " . $this->table_name . " SET pre_order=:pre_order WHERE wl_id=:wl_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":wl_id", $this->wl_id);
		$stmt->bindParam(":pre_order", $this->pre_order); 
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}
}
?>