<?php
class ExteriorColor{
    // database connection and table name
	private $conn;
	private $table_name = "exterior_color";

    // object properties
    public $id;	
	public $color;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . "  ORDER BY color";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET color=:color"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":color", $this->color); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `color` = :color LIMIT 0, 1";
		$stmt = $this->conn->prepare( $query );
		$this->color = htmlspecialchars(strip_tags($this->color)); 
		$stmt->bindParam(":color", $this->color); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}
	
}
