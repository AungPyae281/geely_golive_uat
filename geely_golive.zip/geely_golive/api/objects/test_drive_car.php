<?php
class TestDriveCar{
    // database connection and table name
	private $conn;
	private $table_name = "test_drive_car";

	// object properties 
	public $id;
	public $model;
	public $plate_no;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE plate_no=:plate_no LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET model=:model, plate_no=:plate_no"; 
		$stmt = $this->conn->prepare($query); 
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":plate_no", $this->plate_no); 
		if($stmt->execute()){
			return true;
		}
		return false;		
	} 

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY model, plate_no";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(1, $this->id);
		if($stmt->execute()){
			return true;
		}
		return false;
	} 

// 	function getAllCars(){
// 		$query = "SELECT bl.id, test_drive_car.plate_no, IFNULL(`time`, '') AS `time`
// FROM test_drive_car
// LEFT JOIN (
// SELECT id, plate_no, `time`
// FROM test_drive
// WHERE time_out='' AND model=:model AND `date`=:date) AS bl ON test_drive_car.plate_no=bl.plate_no ORDER BY test_drive_car.plate_no";
// 		$stmt = $this->conn->prepare( $query );

// 		$stmt->bindParam(":date", $this->date);
// 		$stmt->bindParam(":model", $this->model);

// 		$stmt->execute();
// 		return $stmt;
// 	}
}
?>