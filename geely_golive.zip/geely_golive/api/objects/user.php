<?php
class User{
    private $conn;
    private $table_name = "user";
 
	public $id;	
	public $staff_id;
	public $staff_name;
    public $username;
	public $password;
	public $userrole; 
	public $dashboard; 
	public $profilepicture; 
 
    public function __construct($db){
        $this->conn = $db;
    }	
 
    function isExist(){ 
		// $query = "SELECT `user`.*, staff.position, IFNULL(staff_store.store_name, '') AS store_name, IFNULL(scs.service_center, '') AS service_center FROM " . $this->table_name . "
		// LEFT JOIN staff ON `user`.staff_id = staff.id
		// LEFT JOIN staff_store ON `user`.staff_id=staff_store.staff_id
		// LEFT JOIN service_center_store AS scs ON staff_store.store_name=scs.store_name WHERE username = ? AND password = ? LIMIT 0,1";

		$query = "SELECT `user`.*, staff.position, IFNULL(ssc.service_center_id, '') AS service_center_id, IFNULL(ssc.service_center, '') AS service_center, IFNULL(ssc.store_name, '') AS store_name FROM " . $this->table_name . " LEFT JOIN staff ON `user`.staff_id = staff.id LEFT JOIN staff_service_center AS ssc ON staff.id=ssc.staff_id WHERE username = ? AND password = ? LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->username = htmlspecialchars(strip_tags($this->username));
		$this->password = htmlspecialchars(strip_tags($this->password));
	 
		$stmt->bindParam(1, $this->username);
		$stmt->bindParam(2, $this->password);
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			extract($row);
			$this->id = $id;	
			$this->staff_id = $staff_id;
			$this->staff_name = $staff_name;
			$this->userrole = $userrole; 
			$this->dashboard = $dashboard; 
			$this->profilepicture = $profilepicture;
			$this->position = $position; 
			$this->service_center_id = $service_center_id; 
			$this->service_center = $service_center; 
			$this->store_name = $store_name; 
			return true;
		}
		return false;
	} 

	function getUsers(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY FIELD(userrole, 'KEY') DESC, dashboard, username";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function isExistUsername(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE username = ? LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->username = htmlspecialchars(strip_tags($this->username));	 
		$stmt->bindParam(1, $this->username);
		
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$condition = ""; 
		if($this->profilepicture!=""){
			$condition = ", profilepicture = :profilepicture";
		}
		$query = "INSERT INTO " . $this->table_name . " SET staff_id = :staff_id, staff_name = :staff_name, username = :username, `password` = :password, userrole = :userrole, dashboard = :dashboard" . $condition;
		$stmt = $this->conn->prepare($query);	
	 
		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->bindParam(":staff_name", $this->staff_name);
		$stmt->bindParam(":username", $this->username);
		$stmt->bindParam(":password", $this->password);
		$stmt->bindParam(":userrole", $this->userrole);
		$stmt->bindParam(":dashboard", $this->dashboard);
		if($this->profilepicture) $stmt->bindParam(":profilepicture", $this->profilepicture);
	 
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function getOneRow(){
		$query = "SELECT user.*, staff.department, staff.position FROM " . $this->table_name . " LEFT JOIN staff on user.staff_id = staff.id WHERE user.id = :id";
		$stmt = $this->conn->prepare( $query );	 
		$stmt->bindParam(":id", $this->id);		
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			extract($row);
			$this->staff_id = $staff_id;
			$this->staff_name = $staff_name;
			$this->username = $username; 
			$this->userrole = $userrole; 
			$this->dashboard = $dashboard; 
			$this->profilepicture = $profilepicture;
			$this->department = $department;
			$this->position = $position;
			return true;
		}
		return false;
	}

	function update(){
		$condition = ""; 
		if($this->profilepicture!=""){
			$condition = ", profilepicture = :profilepicture";
		}
		$query = "UPDATE " . $this->table_name . " SET dashboard = :dashboard, userrole = :userrole" . $condition . " WHERE username = :username";
		$stmt = $this->conn->prepare($query);	
	 
		$stmt->bindParam(":username", $this->username);
		$stmt->bindParam(":dashboard", $this->dashboard);
		$stmt->bindParam(":userrole", $this->userrole);
		if($this->profilepicture) $stmt->bindParam(":profilepicture", $this->profilepicture);
	 
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(1, $this->id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}
 
	function updatePassword(){
		$query = "UPDATE " . $this->table_name . " SET password=:password WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":password", $this->password);
		
		if($stmt->execute()){
			return true;
		}	 
		return false;
	} 

	function updateStaff(){
		$query = "UPDATE " . $this->table_name . " SET staff_name=:staff_name WHERE staff_id=:staff_id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":staff_id", $this->staff_id);
		$stmt->bindParam(":staff_name", $this->staff_name);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	} 
}
?>