<?php
class WarrantyCar{
    private $conn;
    private $table_name = "warranty_car";
 
	public $id;
	public $plate_no;
	public $date;
	public $start_date;
	public $expire_date;
	public $warranty;
	public $valid_kilometer;
	public $status;
	public $remark;
	public $entry_by;
	public $entry_date_time;
	public $update_by;
	public $update_date_time;
 
    public function __construct($db){
        $this->conn = $db;
    }

    function create(){
		$query = "INSERT INTO " . $this->table_name . " SET plate_no=:plate_no, start_date=:start_date, expire_date=:expire_date, warranty=:warranty, valid_kilometer=:valid_kilometer, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->bindParam(":start_date", $this->start_date);
		$stmt->bindParam(":expire_date", $this->expire_date);
		$stmt->bindParam(":warranty", $this->warranty);
		$stmt->bindParam(":valid_kilometer", $this->valid_kilometer);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

    function autocomplete(){	
		$condition = "";
		
		if($this->plate_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (plate_no LIKE  :plate_no '%' or plate_no LIKE '%' :plate_no '%' or plate_no Like '%' :plate_no )";
		}

		if($condition!=""){
			$condition = " HAVING " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . " GROUP BY plate_no " . $condition . " ORDER BY plate_no";
		$stmt = $this->conn->prepare($query);
		if($this->plate_no) $stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->execute();
		return $stmt;
	}

	function search(){
		$condition = "";

		if($this->plate_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " wc.plate_no=:plate_no ";
		}

		if($this->warranty_status){
			if($condition!=""){
				$condition .= " AND ";
			}
			if($this->warranty_status=="Yes"){
				$condition .= " (A='Valid' OR B='Valid' OR C='Valid' OR D='Valid' OR E='Valid') ";
			}else if($this->warranty_status=="No"){
				$condition .= " (A<>'Valid' AND B<>'Valid' AND C<>'Valid' AND D<>'Valid' AND E<>'Valid')";
			}
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT wc.*, IFNULL(last_visited_date, '') AS last_visited_date, IFNULL(kilometer, 0) AS kilometer FROM (SELECT plate_no,             
MAX(CASE WHEN warranty = 'A' THEN if(`status`='', 'Valid', `status`) END) `A`,                                        
MAX(CASE WHEN warranty = 'B' THEN if(`status`='', 'Valid', `status`) END) `B`,                                        
MAX(CASE WHEN warranty = 'C' THEN if(`status`='', 'Valid', `status`) END) `C`,                                        
MAX(CASE WHEN warranty = 'D' THEN if(`status`='', 'Valid', `status`) END) `D`,                                        
MAX(CASE WHEN warranty = 'E' THEN if(`status`='', 'Valid', `status`) END) `E` FROM warranty_car GROUP BY plate_no) AS wc
LEFT JOIN (SELECT MAX(car_receive_date) AS last_visited_date, MAX(kilometer) AS kilometer, plate_no                                   
FROM service GROUP BY plate_no) AS serv ON wc.plate_no=serv.plate_no " . $condition;

		$stmt = $this->conn->prepare($query);

		if($this->plate_no) $stmt->bindParam(":plate_no", $this->plate_no);	

		$stmt->execute();
		return $stmt;
	}

	function getWarrantyByPlateNo(){
		$query = "SELECT id, plate_no, warranty, IF(status='', 'Valid', status) AS status, `date`, remark FROM " . $this->table_name . " WHERE plate_no=:plate_no ";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":plate_no", $this->plate_no);	
		$stmt->execute();
		return $stmt;
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET `status`=:status, remark=:remark, update_by=:update_by, update_date_time=:update_date_time WHERE id=:id AND plate_no=:plate_no";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);	
		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->bindParam(":status", $this->status);
		$stmt->bindParam(":remark", $this->remark);
		$stmt->bindParam(":update_by", $this->update_by);
		$stmt->bindParam(":update_date_time", $this->update_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function updateStatusExpireDate(){
		$query = "UPDATE " . $this->table_name . " SET date=:date, `status`=:status, update_by=:update_by, update_date_time=:update_date_time WHERE expire_date<:date AND `status`=''";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":date", $this->date);	
		$stmt->bindParam(":status", $this->status);
		$stmt->bindParam(":update_by", $this->update_by);
		$stmt->bindParam(":update_date_time", $this->update_date_time);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getValidWarrantyByPlateNo(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE plate_no=:plate_no AND `status`=''";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->execute();
		return $stmt;
	}

	function updateStatusExpireKilometer(){
		$query = "UPDATE " . $this->table_name . " SET date=:date, `status`=:status, update_by=:update_by, update_date_time=:update_date_time WHERE valid_kilometer<=:kilometer AND `status`=''";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":date", $this->date);	
		$stmt->bindParam(":status", $this->status);
		$stmt->bindParam(":update_by", $this->update_by);
		$stmt->bindParam(":update_date_time", $this->update_date_time);
		$stmt->bindParam(":kilometer", $this->kilometer);

		if($stmt->execute()){
			return true;
		}
		return false;
	} 
}
?>