<?php
class Model{
    // database connection and table name
    private $conn;
    private $table_name = "model";
 
    // object properties
	public $id;
	public $brand;
	public $model;
	public $model_year;
 
    public function __construct($db){
        $this->conn = $db;
    }

    function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `brand`=:brand and `model`=:model and `model_year`=:model_year LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->brand = htmlspecialchars(strip_tags($this->brand));
		$this->model = htmlspecialchars(strip_tags($this->model));
		$this->model_year = htmlspecialchars(strip_tags($this->model_year));

		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":model_year", $this->model_year);

		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET brand=:brand, model=:model, model_year=:model_year";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":brand", $this->brand);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":model_year", $this->model_year);
		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY brand, model, model_year";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}

	function getModelByBrand(){ 
		$query = "SELECT * FROM " . $this->table_name . " WHERE brand = :brand GROUP BY model ORDER BY model";
		$stmt = $this->conn->prepare($query);
		$this->brand = htmlspecialchars(strip_tags($this->brand));
		$stmt->bindParam(":brand", $this->brand);
		$stmt->execute();
		return $stmt;
	}

	function getModelYearByModel(){ 
		$query = "SELECT * FROM " . $this->table_name . " WHERE model=:model GROUP BY model_year ORDER BY model_year";
		$stmt = $this->conn->prepare($query);
		$this->model = htmlspecialchars(strip_tags($this->model));
		$stmt->bindParam(":model", $this->model);
		$stmt->execute();
		return $stmt;
	} 

	function getAllModel(){
		$query = "SELECT * FROM " . $this->table_name . " GROUP BY model ORDER BY model";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	}
}
?>