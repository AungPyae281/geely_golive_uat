<?php
class PaymentTerm{
	private $conn;
	private $table_name = "payment_term";

	public $id;
	public $payment_term;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}
 
    function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY payment_term";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	} 
}
?>