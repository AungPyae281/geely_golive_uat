<?php
class Sales{
    private $conn;
    private $table_name = "sales";
 
	public $id;
	public $date;
	public $oc_no; 
	public $customer_id;
	public $broker_id;
	public $broker_name;

    public $vehicle_status;

	public $brand;
	public $model;
    public $grade;
    public $model_year;
    public $vin_no;
    public $engine_no; 
    public $exterior_color;
    public $interior_color;

	public $sales_center;

    public $sales_type;
	public $vehicle_price;	
	public $commercial_tax;
	public $rtad_tax;
	public $promotion_code;
	public $promotion_discount;
	public $selling_price;
	public $payment_type;
	public $bank;
	public $payment_percent;
	public $payment_term;
	public $deposit; 

    public $same_as_buyer;
    public $rtad_name;
    public $rtad_nrc_no;
    public $rtad_mobile_no;
    public $rtad_township;

    public $customer_type;
    public $company_name;
    public $company_register_no;

	public $staff_id;

	public $additional_discount;

	public $dc_due_date_time; 
    public $payment_due_date_time; 

    public $dc_nrc;
    public $dc_census;
    public $dc_id;
    public $dc_bl;
    public $dc_custom_statement;
    public $dc_purchase_permit;
    public $dc_income_tax;
    public $dc_license;
    public $dc_rta_fees_slip; 
    public $dc_sale_invoice;
    public $dc_sale_contract;
    public $dc_delivery_note;
    public $dc_owner_book;
    public $dc_others;

    public $pp_done;
    public $it_done;
    public $appt_done;
    public $pn_done;
    public $ff_done;
    public $pdi_done;
    public $rtd_done;

    public $income_tax;
    public $income_tax_amount;
    public $it_submission_date;
    public $it_received_date;
    
    public $appointment_date;
    public $appointment_time;
    public $rta_office_location;

    public $plate_no;
    public $special_plate;
    public $plate_no_img;

    public $fuel_amount;

    public $handover_date;
    public $handover_vehicle_img;

    public $status;
    public $processing;

    public function __construct($db){
        $this->conn = $db;
    }

    function create(){
        $query = "INSERT INTO `" . $this->table_name . "` SET `date`=:date
        , oc_no=:oc_no
        , customer_id=:customer_id
        , broker_id=:broker_id
        , broker_name=:broker_name

        , vehicle_status=:vehicle_status

        , brand=:brand
        , model=:model
        , grade=:grade
        , model_year=:model_year
        , vin_no=:vin_no
        , engine_no=:engine_no
        , exterior_color=:exterior_color
        , interior_color=:interior_color

        , sales_center=:sales_center

        , sales_type=:sales_type
        , vehicle_price=:vehicle_price 
        , commercial_tax=:commercial_tax 
        , rtad_tax=:rtad_tax 
        , promotion_code=:promotion_code
        , promotion_discount=:promotion_discount
        , selling_price=:selling_price
        , payment_type=:payment_type
        , bank=:bank
        , payment_percent=:payment_percent
        , payment_term=:payment_term
        , deposit=:deposit

        , same_as_buyer=:same_as_buyer
        , rtad_name=:rtad_name
        , rtad_nrc_no=:rtad_nrc_no
        , rtad_mobile_no=:rtad_mobile_no
        , rtad_township=:rtad_township

        , customer_type=:customer_type
        , company_name=:company_name
        , company_register_no=:company_register_no

        , staff_id=:staff_id 

        , status=:status
        , processing=:processing";
         
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":date", $this->date);
        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->bindParam(":customer_id", $this->customer_id);
        $stmt->bindParam(":broker_id", $this->broker_id);
        $stmt->bindParam(":broker_name", $this->broker_name);

        $stmt->bindParam(":vehicle_status", $this->vehicle_status);
        $stmt->bindParam(":brand", $this->brand);
        $stmt->bindParam(":model", $this->model);
        $stmt->bindParam(":grade", $this->grade);
        $stmt->bindParam(":model_year", $this->model_year);
        $stmt->bindParam(":vin_no", $this->vin_no);
        $stmt->bindParam(":engine_no", $this->engine_no);
        $stmt->bindParam(":exterior_color", $this->exterior_color);
        $stmt->bindParam(":interior_color", $this->interior_color);

        $stmt->bindParam(":sales_center", $this->sales_center);

        $stmt->bindParam(":sales_type", $this->sales_type);
        $stmt->bindParam(":vehicle_price", $this->vehicle_price);   
        $stmt->bindParam(":commercial_tax", $this->commercial_tax); 
        $stmt->bindParam(":rtad_tax", $this->rtad_tax); 
        $stmt->bindParam(":promotion_code", $this->promotion_code); 
        $stmt->bindParam(":promotion_discount", $this->promotion_discount); 
        $stmt->bindParam(":selling_price", $this->selling_price);   
        $stmt->bindParam(":payment_type", $this->payment_type);
        $stmt->bindParam(":bank", $this->bank);
        $stmt->bindParam(":payment_percent", $this->payment_percent);
        $stmt->bindParam(":payment_term", $this->payment_term);
        $stmt->bindParam(":deposit", $this->deposit);

        $stmt->bindParam(":same_as_buyer", $this->same_as_buyer);
        $stmt->bindParam(":rtad_name", $this->rtad_name);
        $stmt->bindParam(":rtad_nrc_no", $this->rtad_nrc_no);
        $stmt->bindParam(":rtad_mobile_no", $this->rtad_mobile_no);
        $stmt->bindParam(":rtad_township", $this->rtad_township);

        $stmt->bindParam(":customer_type", $this->customer_type);
        $stmt->bindParam(":company_name", $this->company_name);
        $stmt->bindParam(":company_register_no", $this->company_register_no);

        $stmt->bindParam(":staff_id", $this->staff_id); 
        
        $stmt->bindParam(":status", $this->status);
        $stmt->bindParam(":processing", $this->processing);

        if($stmt->execute()){
            $this->id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    function getSalesList(){
        $condition = "";
        if($this->position=="Sales Executive"){
            $condition .= " AND sales.staff_id=:staff_id";
        }else if($this->position=="Sales Admin"){
            $condition .= " AND staff.sa_id=:staff_id";
        }
        $query = "SELECT sales.*, `order`.entry_date_time, ((IFNULL(tp.total_payment, 0)/sales.selling_price) * 100) AS percent, customer.name AS `name` FROM sales LEFT JOIN `order` ON sales.oc_no=`order`.oc_no LEFT JOIN (SELECT oc_no, sum(amount) AS total_payment FROM payment GROUP BY payment.oc_no) AS tp ON sales.oc_no=tp.oc_no LEFT JOIN customer ON customer.id=sales.customer_id LEFT JOIN staff ON sales.staff_id=staff.id WHERE sales.processing<>'' AND dc_due_date_time<>'' " . $condition;
        $stmt = $this->conn->prepare( $query );
        if($this->position=="Sales Executive" || $this->position=="Sales Admin") $stmt->bindParam(":staff_id", $this->staff_id);
        $stmt->execute();
        return $stmt;
    }

    function getSalesDetail(){
        $query = "SELECT sales.*, customer.registration_no AS c_registration_no, customer.name AS c_name, customer.nrc_no AS c_nrc_no, customer.mobile_no AS c_mobile_no, customer.email AS c_email,
customer.township AS c_township, IFNULL(broker.name, '') AS b_name, IFNULL(broker.registration_no, '') AS b_registration_no, IFNULL(payment.total_payment, 0) AS total_payment
FROM sales
LEFT JOIN customer ON sales.customer_id=customer.id
LEFT JOIN broker ON sales.broker_id=broker.id
LEFT JOIN (SELECT oc_no, SUM(amount) AS total_payment FROM payment WHERE oc_no=:oc_no) AS payment ON sales.oc_no=payment.oc_no
WHERE sales.oc_no=:oc_no";

        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->execute();
        if($stmt->rowCount()>0){
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->sales_center = $row['sales_center'];

            $this->c_registration_no = $row['c_registration_no'];
            $this->c_name = $row['c_name'];
            $this->c_nrc_no = $row['c_nrc_no'];
            $this->c_mobile_no = $row['c_mobile_no'];
            $this->c_email = $row['c_email'];
            $this->c_township = $row['c_township'];
            $this->customer_type = $row['customer_type'];
            $this->company_name = $row['company_name'];
            $this->company_register_no = $row['company_register_no'];

            $this->b_name = $row['b_name'];
            $this->b_registration_no = $row['b_registration_no']; 

            $this->same_as_buyer = $row['same_as_buyer'];
            $this->rtad_name = $row['rtad_name'];
            $this->rtad_nrc_no = $row['rtad_nrc_no'];
            $this->rtad_mobile_no = $row['rtad_mobile_no'];
            $this->rtad_township = $row['rtad_township'];

            $this->brand = $row['brand'];
            $this->model = $row['model'];
            $this->model_year = $row['model_year'];
            $this->grade = $row['grade']; 
            $this->vin_no = $row['vin_no'];
            $this->engine_no = $row['engine_no'];
            $this->exterior_color = $row['exterior_color'];
            $this->interior_color = $row['interior_color'];

            $this->date = $row['date'];
            $this->sales_type = $row['sales_type'];
            $this->payment_type = $row['payment_type'];
            $this->bank = $row['bank'];
            $this->payment_percent = $row['payment_percent'];
            $this->payment_term = $row['payment_term'];
            $this->vehicle_price = $row['vehicle_price'];
            $this->commercial_tax = $row['commercial_tax'];
            $this->rtad_tax = $row['rtad_tax'];
            $this->promotion_code = $row['promotion_code'];
            $this->promotion_discount = $row['promotion_discount'];
            $this->selling_price = $row['selling_price'];
            $this->deposit = $row['deposit'];
            $this->total_payment = $row['total_payment'];

            $this->it_done = $row['it_done'];
            $this->income_tax = $row['income_tax'];
            $this->income_tax_amount = $row['income_tax_amount'];
            $this->it_submission_date = $row['it_submission_date'];
            $this->it_received_date = $row['it_received_date'];

            $this->appointment_date = $row['appointment_date'];
            $this->appointment_time = $row['appointment_time'];
            $this->rta_office_location = $row['rta_office_location'];
            $this->appt_done = $row['appt_done'];

            $this->plate_no = $row['plate_no'];
            $this->special_plate = $row['special_plate'];
            $this->plate_no_img = $row['plate_no_img'];
            $this->pn_done = $row['pn_done'];

            $this->fuel_amount = $row['fuel_amount'];
            $this->ff_done = $row['ff_done'];

            $this->handover_date = $row['handover_date'];
            $this->handover_vehicle_img = $row['handover_vehicle_img'];

            $this->owner_book_img = $row['owner_book_img'];

            $this->processing = $row['processing'];
        }
    }

    function updateStatus(){
        $query = "UPDATE `" . $this->table_name . "` SET `status`=:status, processing=:processing WHERE oc_no=:oc_no";
        $stmt = $this->conn->prepare( $query );  
        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->bindParam(":status", $this->status);
        $stmt->bindParam(":processing", $this->processing);
        $stmt->execute();
        if($stmt->rowCount()>0){
            return true;
        }
        return false;
    }

    function checkStatus(){
        $query = "SELECT * FROM `" . $this->table_name . "` WHERE oc_no=:oc_no LIMIT 0, 1";
        $stmt = $this->conn->prepare( $query );  
        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->execute();
        if($stmt->rowCount()>0){
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->status = $row['status'];
            $this->processing = $row['processing'];
            $this->pp_done = $row['pp_done'];
        }
    }

    function deleteDC(){
        $statement = "";
        if($this->column_name=="dc_others"){
            $statement = " SET `" . $this->column_name . "`=REPLACE(`" . $this->column_name . "`, :file_name, '')";
        }else{
            $statement = " SET `" . $this->column_name . "`=''";
        }
        $query = "UPDATE " . $this->table_name . $statement . " WHERE oc_no=:oc_no";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":oc_no", $this->oc_no);
        if($this->column_name=="dc_others") $stmt->bindParam(":file_name", $this->file_name);
        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function updateDC(){
        $statement = "";
        if($this->column_name=="dc_others"){
            $statement = " SET `" . $this->column_name . "`=CONCAT(`" . $this->column_name . "`, :file_name)";
        }else{
            $statement = " SET `" . $this->column_name . "`=:file_name";
        }
        $query = "UPDATE " . $this->table_name . $statement . " WHERE oc_no=:oc_no";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->bindParam(":file_name", $this->file_name);
        if($stmt->execute()){
            return true;
        }
        return false;
    } 

    function getOneRow(){
        $query = "SELECT sales.*, IFNULL(p_amount, 0) AS p_amount FROM `" . $this->table_name . "` LEFT JOIN (SELECT oc_no, SUM(amount) AS p_amount FROM payment WHERE oc_no=:oc_no) as payment ON sales.oc_no=payment.oc_no WHERE payment.oc_no=:oc_no";

        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->execute();
        if($stmt->rowCount()>0){
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            $this->vehicle_price = $row['vehicle_price'];
            $this->commercial_tax = $row['commercial_tax'];
            $this->rtad_tax = $row['rtad_tax'];
            $this->selling_price = $row['selling_price'];
            $this->payment_type = $row['payment_type'];
            $this->deposit = $row['deposit'];
            $this->p_amount = $row['p_amount'];

            $this->dc_nrc = $row['dc_nrc'];
            $this->dc_census = $row['dc_census'];
            $this->dc_id = $row['dc_id'];
            $this->dc_bl = $row['dc_bl'];
            $this->dc_custom_statement = $row['dc_custom_statement'];
            $this->dc_purchase_permit = $row['dc_purchase_permit'];
            $this->dc_income_tax = $row['dc_income_tax'];
            $this->dc_license = $row['dc_license'];
            $this->dc_rta_fees_slip = $row['dc_rta_fees_slip']; 
            $this->dc_sale_invoice = $row['dc_sale_invoice'];
            $this->dc_sale_contract = $row['dc_sale_contract'];
            $this->dc_delivery_note = $row['dc_delivery_note'];
            $this->dc_owner_book = $row['dc_owner_book'];
            $this->dc_others = $row['dc_others'];

            $this->pp_done = $row['pp_done'];

            $this->it_done = $row['it_done'];
            $this->vehicle_price = $row['vehicle_price'];
            $this->income_tax = $row['income_tax'];
            $this->it_submission_date = $row['it_submission_date'];
            $this->it_received_date = $row['it_received_date'];

            $this->appointment_date = $row['appointment_date'];
            $this->appointment_time = $row['appointment_time'];
            $this->rta_office_location = $row['rta_office_location'];
            $this->appt_done = $row['appt_done'];

            $this->plate_no = $row['plate_no'];
            $this->special_plate = $row['special_plate'];
            $this->plate_no_img = $row['plate_no_img'];
            $this->pn_done = $row['pn_done'];

            $this->fuel_amount = $row['fuel_amount'];
            $this->ff_done = $row['ff_done'];

            $this->pdi_done = $row['pdi_done'];

            $this->rtd_done = $row['rtd_done'];

            $this->handover_date = $row['handover_date'];
            $this->handover_vehicle_img = $row['handover_vehicle_img'];
        }
    }

    function getOnePrint(){
        $query = "SELECT `sales`.*, customer.registration_no AS customer_registration_no, customer.name AS customer_name, customer.township, customer.address, customer.email, customer.mobile_no, customer.nrc_no, IFNULL(broker.registration_no, '') AS broker_registration_no, staff.name AS staff_name, staff.signature AS staff_sig FROM `sales` LEFT JOIN customer ON `sales`.customer_id = customer.id LEFT JOIN broker ON sales.broker_id=broker.id LEFT JOIN staff ON `sales`.staff_id = staff.id WHERE sales.oc_no=:oc_no";

        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->execute();
        if($stmt->rowCount()>0){
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            $this->id = $row['id'];
            $this->date = $row['date'];
            $this->oc_no = $row['oc_no'];

            $this->sales_center = $row['sales_center']; 
            $this->sales_type = $row['sales_type'];

            $this->customer_id = $row['customer_id'];
            $this->customer_registration_no = $row['customer_registration_no'];
            $this->customer_name = $row['customer_name'];
            $this->nrc_no = $row['nrc_no'];
            $this->mobile_no = $row['mobile_no'];
            $this->email = $row['email'];
            $this->township = $row['township'];
            $this->address = $row['address'];

            $this->broker_id = $row['broker_id'];
            $this->broker_registration_no = $row['broker_registration_no'];
            $this->broker_name = $row['broker_name'];

            $this->brand = $row['brand'];   
            $this->model = $row['model'];
            $this->model_year = $row['model_year'];
            $this->grade = $row['grade']; 
            $this->exterior_color = $row['exterior_color'];
            $this->interior_color = $row['interior_color'];    
            $this->vin_no = $row['vin_no'];
            $this->engine_no = $row['engine_no'];  

            $this->vehicle_price = $row['vehicle_price'];
            $this->commercial_tax = $row['commercial_tax'];
            $this->rtad_tax = $row['rtad_tax'];
            $this->promotion_code = $row['promotion_code'];
            $this->promotion_discount = $row['promotion_discount'];
            $this->selling_price = $row['selling_price'];
            $this->payment_type = $row['payment_type'];
            $this->bank = $row['bank'];
            $this->payment_percent = $row['payment_percent'];
            $this->payment_term = $row['payment_term'];
            $this->payment_due_date_time = $row['payment_due_date_time'];  

            $this->same_as_buyer = $row['same_as_buyer'];
            $this->rtad_name = $row['rtad_name'];
            $this->rtad_nrc_no = $row['rtad_nrc_no'];
            $this->rtad_mobile_no = $row['rtad_mobile_no'];
            $this->rtad_township = $row['rtad_township'];

            $this->customer_type = $row['customer_type'];   
            $this->company_name = $row['company_name'];
            $this->company_register_no = $row['company_register_no'];

            $this->staff_id = $row['staff_id'];

            $this->deposit = $row['deposit'];
            $this->dc_due_date_time = $row['dc_due_date_time'];  

            $this->staff_sig = $row['staff_sig'];
            $this->staff_name = $row['staff_name'];

            $this->dc_nrc = $row['dc_nrc'];
            $this->dc_census = $row['dc_census'];
            $this->dc_id = $row['dc_id'];
            $this->dc_bl = $row['dc_bl'];
            $this->dc_custom_statement = $row['dc_custom_statement'];
            $this->dc_purchase_permit = $row['dc_purchase_permit'];
            $this->dc_income_tax = $row['dc_income_tax'];
            $this->dc_license = $row['dc_license'];
            $this->dc_rta_fees_slip = $row['dc_rta_fees_slip'];
            $this->dc_owner_book = $row['dc_owner_book'];
            $this->dc_others = $row['dc_others'];

            $this->processing = $row["processing"];
        }
    }

    function updateDone(){
        $query = "UPDATE " . $this->table_name . " SET `" . $this->column_name . "`=1 WHERE oc_no=:oc_no";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":oc_no", $this->oc_no);
        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function updateAppointmentDateTime(){
        $query = "UPDATE " . $this->table_name . " SET appointment_date=:appointment_date, appointment_time=:appointment_time, rta_office_location=:rta_office_location WHERE oc_no=:oc_no";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->bindParam(":appointment_date", $this->appointment_date);
        $stmt->bindParam(":appointment_time", $this->appointment_time);
        $stmt->bindParam(":rta_office_location", $this->rta_office_location);

        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function updatePlateNo(){
        $statement = "";
        if($this->plate_no_img){
            $statement = ", plate_no_img=:plate_no_img";
        }
        $query = "UPDATE " . $this->table_name . " SET plate_no=:plate_no, special_plate=:special_plate " . $statement . " WHERE oc_no=:oc_no";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->bindParam(":plate_no", $this->plate_no);
        $stmt->bindParam(":special_plate", $this->special_plate);
        if($this->plate_no_img) $stmt->bindParam(":plate_no_img", $this->plate_no_img);

        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function updateIncomeTax(){
        $query = "UPDATE " . $this->table_name . " SET it_done=1, income_tax=:income_tax, income_tax_amount=:income_tax_amount, it_submission_date=:it_submission_date, it_received_date=:it_received_date WHERE oc_no=:oc_no";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->bindParam(":income_tax", $this->income_tax);
        $stmt->bindParam(":income_tax_amount", $this->income_tax_amount);
        $stmt->bindParam(":it_submission_date", $this->it_submission_date);
        $stmt->bindParam(":it_received_date", $this->it_received_date);

        if($stmt->execute()){
            return true;
        }
        return false;
    } 

    function updateFuel(){
        $query = "UPDATE " . $this->table_name . " SET fuel_amount=:fuel_amount WHERE oc_no=:oc_no";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->bindParam(":fuel_amount", $this->fuel_amount);

        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function updateHandover(){
        $statement = "";
        if($this->handover_vehicle_img){
            $statement = ", handover_vehicle_img=:handover_vehicle_img";
        }
        $query = "UPDATE " . $this->table_name . " SET handover_date=:handover_date " . $statement . " WHERE oc_no=:oc_no";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->bindParam(":handover_date", $this->handover_date);
        if($this->handover_vehicle_img) $stmt->bindParam(":handover_vehicle_img", $this->handover_vehicle_img);

        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function getOneDeliveryNote(){
        $query = "SELECT customer.name AS c_name, customer.mobile_no AS c_mobile_no, customer.address AS c_address, model, grade, vin_no, engine_no, exterior_color, interior_color, staff.name AS sales_person FROM sales LEFT JOIN customer ON sales.customer_id=customer.id LEFT JOIN staff ON sales.staff_id=staff.id WHERE sales.oc_no=:oc_no";

        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->execute();
        if($stmt->rowCount()>0){
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->c_name = $row['c_name'];
            $this->c_mobile_no = $row['c_mobile_no'];
            $this->c_address = $row['c_address'];
            $this->model = $row['model'];
            $this->grade = $row['grade'];
            $this->vin_no = $row['vin_no'];
            $this->engine_no = $row['engine_no'];
            $this->exterior_color = $row['exterior_color'];
            $this->interior_color = $row['interior_color'];
            $this->sales_person = $row['sales_person'];
        }
    }

    function updateOwnerBook(){
        $query = "UPDATE " . $this->table_name . " SET owner_book_img=:owner_book_img WHERE oc_no=:oc_no";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->bindParam(":owner_book_img", $this->owner_book_img);
        
        if($stmt->execute()){
            return true;
        }
        return false;
    } 
 
 	function updateDueDateTime(){
		$query = "UPDATE " . $this->table_name . " SET `dc_due_date_time`=:dc_due_date_time WHERE oc_no=:oc_no";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":oc_no", $this->oc_no);
		$stmt->bindParam(":dc_due_date_time", $this->dc_due_date_time);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	} 

    function getAllOCProductionOrder(){
        $query = "SELECT sales.*, customer.name AS customer_name FROM " . $this->table_name . " LEFT JOIN `order` ON sales.oc_no=`order`.oc_no LEFT JOIN customer ON sales.customer_id=customer.id WHERE sales.vin_no='' AND dc_due_date_time<>'' AND sales.brand=:brand AND sales.model=:model AND sales.model_year=:model_year AND sales.grade=:grade AND sales.exterior_color=:exterior_color AND sales.interior_color=:interior_color ORDER BY sales.date, `order`.entry_date_time";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":brand", $this->brand);
        $stmt->bindParam(":model", $this->model);
        $stmt->bindParam(":model_year", $this->model_year);
        $stmt->bindParam(":grade", $this->grade);
        $stmt->bindParam(":exterior_color", $this->exterior_color);
        $stmt->bindParam(":interior_color", $this->interior_color);

        $stmt->execute();
        return $stmt;
    } 

    function updateVNAssign(){
        $query = "UPDATE " . $this->table_name . " SET vin_no=:vin_no, engine_no=:engine_no WHERE oc_no=:oc_no";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->bindParam(":vin_no", $this->vin_no);
        $stmt->bindParam(":engine_no", $this->engine_no);
        
        if($stmt->execute()){
            return true;
        }
        return false;
    } 

    function getAllInvoices(){
        $condition = "";    

        if($this->df){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " date >= :df ";
        }

        if($this->dt){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " date <= :dt ";
        }

        if($this->invoice_type){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " invoice_type = :invoice_type ";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        $query = "SELECT * FROM ((SELECT * FROM (SELECT sales.id, sales.oc_no AS invoice_no, 'Sales' AS invoice_type, `date`, IF(payment_due_date_time='', dc_due_date_time, payment_due_date_time) AS due_date_time, selling_price AS amount, IFNULL(payment, 0) AS payment FROM sales LEFT JOIN (SELECT oc_no, SUM(amount) AS payment FROM payment GROUP BY oc_no) AS pm ON sales.oc_no=pm.oc_no WHERE dc_due_date_time<>'') AS sal WHERE amount>payment)
            UNION ALL (SELECT service.id, service.registration_no AS invoice_no, 'After Sales' AS invoice_type, invoice_date AS `date`, payment_due_date_time AS due_date_time, IFNULL(amount, 0) AS amount, 0 AS payment FROM service LEFT JOIN (SELECT service_id, SUM(amount) AS amount FROM (SELECT service_id, SUM(if(warranty=0, qty * fixed_price, 0)) AS amount FROM service_detail_sparepart GROUP BY service_id UNION ALL SELECT service_id, SUM(item_price) AS amount FROM (SELECT service_id, package_price AS item_price FROM service_detail_service_item WHERE package_id<>0 GROUP BY service_id, package_id UNION ALL SELECT service_id, SUM(item_price) AS item_price FROM service_detail_service_item WHERE package_id=0 GROUP BY service_id) AS sdsi GROUP BY service_id) AS spsi GROUP BY service_id) AS spsi1 ON service.id=spsi1.service_id WHERE service.status='Final Inspection')) AS invoices " . $condition . " ORDER BY `date` DESC";

        $stmt = $this->conn->prepare($query);
         
        if($this->df) $this->df=htmlspecialchars(strip_tags($this->df));
        if($this->dt) $this->dt=htmlspecialchars(strip_tags($this->dt));
        if($this->invoice_type) $this->invoice_type=htmlspecialchars(strip_tags($this->invoice_type));
        
        if($this->df) $stmt->bindParam(":df", $this->df);
        if($this->dt) $stmt->bindParam(":dt", $this->dt);
        if($this->invoice_type) $stmt->bindParam(":invoice_type", $this->invoice_type);
        
        $stmt->execute();
        return $stmt;
    } 

    function autocompleteOC(){
        $condition = "";
        
        if($this->oc_no){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (oc_no LIKE  :oc_no '%' or oc_no LIKE '%' :oc_no '%' or oc_no Like '%' :oc_no )";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        $query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY oc_no DESC";
        $stmt = $this->conn->prepare($query);
        if($this->oc_no) $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->execute();
        return $stmt;
    }

    function search(){
        $condition = "";
        
        if($this->df){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " sales.date >= :df";
        }

        if($this->dt){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " sales.date <= :dt";
        }

        if($this->oc_no){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " sales.oc_no = :oc_no";
        }

        if($this->customer_name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " customer.name = :customer_name";
        }

        if($this->customer_phone){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (customer.mobile_no LIKE  :customer_phone '%' or customer.mobile_no LIKE '%' :customer_phone '%' or customer.mobile_no Like '%' :customer_phone )";
        }

        if($this->broker_name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " broker.name = :broker_name";
        }

        if($this->sales_center){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " sales.sales_center = :sales_center";
        }

        if($this->payment_type){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " sales.payment_type = :payment_type";
        }

        if($this->payment){
            if($condition!=""){
                $condition .= " AND ";
            }
            if($this->payment=="Full"){
                $condition .= " sales.selling_price = IFNULL(pm.total_payment, 0)";
            }else{
                $condition .= " sales.selling_price > IFNULL(pm.total_payment, 0)";
            }
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        $query = "SELECT sales.`date`, sales.oc_no, sales.sales_center, customer.name AS customer_name, customer.mobile_no AS customer_phone, IFNULL(broker.name, '') AS broker_name, sales.vin_no, sales.payment_type, if(sales.payment_type='HP', sales.deposit, 0) AS deposit, sales.selling_price, IFNULL(pm.total_payment, 0) AS total_payment, IFNULL(dr.refund_amount, 0) AS refund
FROM sales
LEFT JOIN customer ON sales.customer_id=customer.id
LEFT JOIN broker ON sales.broker_id=broker.id
LEFT JOIN (SELECT oc_no, SUM(amount) AS total_payment FROM payment GROUP BY oc_no) AS pm ON sales.oc_no=pm.oc_no
LEFT JOIN (SELECT oc_no, amount AS refund_amount FROM deposit_refund) AS dr ON sales.oc_no=dr.oc_no " . $condition . " ORDER BY sales.date DESC, sales.oc_no DESC";
        $stmt = $this->conn->prepare($query);
        if($this->df) $stmt->bindParam(":df", $this->df);
        if($this->dt) $stmt->bindParam(":dt", $this->dt);
        if($this->oc_no) $stmt->bindParam(":oc_no", $this->oc_no);
        if($this->customer_name) $stmt->bindParam(":customer_name", $this->customer_name);
        if($this->customer_phone) $stmt->bindParam(":customer_phone", $this->customer_phone);
        if($this->broker_name) $stmt->bindParam(":broker_name", $this->broker_name);
        if($this->sales_center) $stmt->bindParam(":sales_center", $this->sales_center);
        if($this->payment_type) $stmt->bindParam(":payment_type", $this->payment_type);
        $stmt->execute();
        return $stmt;
    }

    function getSalesDetailDPRefund(){
        $query = "SELECT sales.*, customer.name AS customer_name, customer.mobile_no AS customer_phone, IFNULL(deposit_receipt.gl_code, '') AS gl_code, IFNULL(gl_account.name, '') AS gl_code_name FROM " . $this->table_name . "
LEFT JOIN customer ON sales.customer_id=customer.id
LEFT JOIN deposit_receipt ON sales.oc_no=deposit_receipt.oc_no
LEFT JOIN gl_account ON deposit_receipt.gl_code=gl_account.gl_code
WHERE sales.oc_no=:oc_no";

        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(":oc_no", $this->oc_no);
        $stmt->execute();
        if($stmt->rowCount()>0){
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            $this->oc_no = $row['oc_no'];
            $this->sales_center = $row['sales_center'];
            $this->date = $row['date'];

            $this->customer_name = $row['customer_name'];
            $this->customer_phone = $row['customer_phone'];

            $this->selling_price = $row['selling_price'];
            $this->gl_code = $row['gl_code'];
            $this->gl_code_name = $row['gl_code_name'];
            $this->deposit = $row['deposit'];
        }
    }


    function search_S(){
        $condition = "";
        
        if($this->df){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " sales.date >= :df";
        }

        if($this->dt){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " sales.date <= :dt";
        }

        if($this->oc_no){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " sales.oc_no = :oc_no";
        }

        if($this->customer_name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " customer.name = :customer_name";
        }

        if($this->customer_phone){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (customer.mobile_no LIKE  :customer_phone '%' or customer.mobile_no LIKE '%' :customer_phone '%' or customer.mobile_no Like '%' :customer_phone )";
        }

        if($this->broker_name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " broker.name = :broker_name";
        }

        if($this->sales_center){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " sales.sales_center = :sales_center";
        }

        if($this->staff_name){
            if($condition!=""){
                $condition .= " AND ";
            }
            $condition .= " (customer.name LIKE  :staff_name '%' or customer.name LIKE '%' :staff_name '%' or customer.name Like '%' :staff_name )";
        }

        if($condition!=""){
            $condition = " WHERE " . $condition;
        }

        $query = "SELECT sales.date, sales.oc_no,customer.name AS customer_name, customer.mobile_no AS customer_phone, IFNULL(broker.name, '') AS broker_name, sales.vin_no, sales.sales_center, sales.payment_type, if(sales.payment_type='HP', sales.deposit, 0) AS deposit, sales.selling_price, staff.name as staff_name, sales.status
FROM `sales`
LEFT JOIN staff ON sales.staff_id=staff.id
LEFT JOIN customer ON sales.customer_id=customer.id
LEFT JOIN broker ON sales.broker_id=broker.id" . $condition . " ORDER BY sales.date DESC, sales.oc_no DESC";
        $stmt = $this->conn->prepare($query);
        if($this->df) $stmt->bindParam(":df", $this->df);
        if($this->dt) $stmt->bindParam(":dt", $this->dt);
        if($this->oc_no) $stmt->bindParam(":oc_no", $this->oc_no);
        if($this->customer_name) $stmt->bindParam(":customer_name", $this->customer_name);
        if($this->customer_phone) $stmt->bindParam(":customer_phone", $this->customer_phone);
        if($this->broker_name) $stmt->bindParam(":broker_name", $this->broker_name);
        if($this->sales_center) $stmt->bindParam(":sales_center", $this->sales_center);
        if($this->staff_name) $stmt->bindParam(":staff_name", $this->staff_name);
        $stmt->execute();
        return $stmt;
    }
}
?>