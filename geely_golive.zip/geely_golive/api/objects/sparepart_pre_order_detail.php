<?php
class SparepartPreOrderDetail{ 
	private $conn;
	private $table_name = "sparepart_pre_order_detail";

	// object properties

	public $id;
	public $sparepart_pre_order_id;
	public $sparepart_code;
	public $sparepart_name;
	public $price;
	public $quantity;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET sparepart_pre_order_id=:sparepart_pre_order_id, sparepart_code=:sparepart_code, sparepart_name=:sparepart_name, quantity=:quantity";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":sparepart_pre_order_id", $this->sparepart_pre_order_id);
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":sparepart_name", $this->sparepart_name); 
		$stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}
		return false;		
	} 

	function getPreOrderDetail(){	
		$query = "SELECT sparepart_pre_order_detail.*, sales_price AS price FROM " . $this->table_name . " LEFT JOIN sparepart ON sparepart_pre_order_detail.sparepart_code=sparepart.`code` WHERE sparepart_pre_order_id=:sparepart_pre_order_id ORDER BY id";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":sparepart_pre_order_id", $this->sparepart_pre_order_id);
		$stmt->execute();
		return $stmt;
	}
}
?>