<?php
class BankAccount{ 
	private $conn;
	private $table_name = "bank_account";
 
	public $id;
	public $gl_code;
	public $country;
	public $bank_name; 
	public $branch;
	public $swift_code;
	public $currency;
	public $account_no;
	public $account_name;
	public $account_type;
	public $opening_balance;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE account_no=:account_no LIMIT 0,1";
		$stmt = $this->conn->prepare( $query ); 
		$stmt->bindParam(":account_no", $this->account_no); 
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET gl_code=:gl_code, country=:country, bank_name=:bank_name, branch=:branch, swift_code=:swift_code, currency=:currency, account_no=:account_no, account_name=:account_name, account_type=:account_type, opening_balance=:opening_balance, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":gl_code", $this->gl_code);
		$stmt->bindParam(":country", $this->country);
		$stmt->bindParam(":bank_name", $this->bank_name);
		$stmt->bindParam(":branch", $this->branch);
		$stmt->bindParam(":swift_code", $this->swift_code);
		$stmt->bindParam(":currency", $this->currency);
		$stmt->bindParam(":account_no", $this->account_no);
		$stmt->bindParam(":account_name", $this->account_name);
		$stmt->bindParam(":account_type", $this->account_type);
		$stmt->bindParam(":opening_balance", $this->opening_balance);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){ 
			return true;
		}
		return false;		
	}

	function getAllBankAccount(){
		$condition = "";	

		if($this->country){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " bank_account.country =:country ";
		}

		if($this->currency){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " bank_account.currency =:currency ";
		} 

		if($condition!=""){
			$condition = " WHERE " . $condition;
		} 

		$query = "SELECT bank_account.*, (opening_balance + IFNULL(SUM(debit), 0) - IFNULL(SUM(credit), 0)) AS balance, IFNULL(er.rate, 0) AS rate FROM bank_account
LEFT JOIN (SELECT gl_code_from AS gl_code, SUM(amount_from) AS credit, 0 AS debit FROM bank_account_transfer GROUP BY gl_code_from
UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit, 0 AS debit FROM account_transfer GROUP BY gl_code_from
UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit, 0 AS debit FROM advance GROUP BY gl_code_from
UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS credit, 0 AS debit FROM deposit_refund GROUP BY gl_code_bank_or_cash
UNION ALL SELECT gl_code_to AS gl_code, 0 AS credit, SUM(amount) AS debit FROM advance_claim GROUP BY gl_code_to
UNION ALL SELECT gl_code_to AS gl_code, 0 AS credit, SUM(amount_to) AS debit FROM bank_account_transfer GROUP BY gl_code_to
UNION ALL SELECT gl_code_to AS gl_code, 0 AS credit, SUM(amount) AS debit FROM account_transfer GROUP BY gl_code_to
UNION ALL SELECT gl_code_bank_or_cash AS gl_code, 0 AS credit, SUM(deposit) AS debit FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no GROUP BY gl_code_bank_or_cash
UNION ALL SELECT gl_code_bank_or_cash AS gl_code, 0 AS credit, SUM(amount) AS debit FROM payment GROUP BY gl_code_bank_or_cash
UNION ALL SELECT gl_code_bank_or_cash AS gl_code, 0 AS credit, SUM(amount) AS debit FROM service_payment GROUP BY gl_code_bank_or_cash) AS crdeb ON bank_account.gl_code=crdeb.gl_code
LEFT JOIN (SELECT currency, rate FROM exchange_rate WHERE id IN (SELECT MAX(id) FROM exchange_rate WHERE `date`<=:date GROUP BY currency)) AS er ON bank_account.currency=er.currency
GROUP BY bank_account.gl_code " . $condition . " ORDER BY bank_account.country, bank_account.bank_name, bank_account.account_name";

		$stmt = $this->conn->prepare($query);
		 
		if($this->country) $this->country=htmlspecialchars(strip_tags($this->country));
		if($this->currency) $this->currency=htmlspecialchars(strip_tags($this->currency));
		
		if($this->country) $stmt->bindParam(":country", $this->country);
		if($this->currency) $stmt->bindParam(":currency", $this->currency);
		$stmt->bindParam(":date", $this->date);
		
		$stmt->execute();
		return $stmt;
	} 

	function getAllBankAndCashAccount(){
		$query = "SELECT gl_account.*, (IFNULL(bank_account.opening_balance, 0) + SUM(IFNULL(debit, 0)) - SUM(IFNULL(credit, 0))) AS balance FROM gl_account
LEFT JOIN bank_account ON gl_account.gl_code=bank_account.gl_code
LEFT JOIN (SELECT gl_code_from AS gl_code, SUM(amount_from) AS credit, 0 AS debit FROM bank_account_transfer GROUP BY gl_code_from
UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit, 0 AS debit FROM account_transfer GROUP BY gl_code_from
UNION ALL SELECT gl_code_from AS gl_code, SUM(amount) AS credit, 0 AS debit FROM advance GROUP BY gl_code_from
UNION ALL SELECT gl_code_bank_or_cash AS gl_code, SUM(amount) AS credit, 0 AS debit FROM deposit_refund GROUP BY gl_code_bank_or_cash
UNION ALL SELECT gl_code_to AS gl_code, 0 AS credit, SUM(amount) AS debit FROM advance_claim GROUP BY gl_code_to
UNION ALL SELECT gl_code_to AS gl_code, 0 AS credit, SUM(amount_to) AS debit FROM bank_account_transfer GROUP BY gl_code_to
UNION ALL SELECT gl_code_to AS gl_code, 0 AS credit, SUM(amount) AS debit FROM account_transfer GROUP BY gl_code_to
UNION ALL SELECT gl_code_bank_or_cash AS gl_code, 0 AS credit, SUM(deposit) AS debit FROM deposit_receipt LEFT JOIN sales ON deposit_receipt.oc_no=sales.oc_no GROUP BY gl_code_bank_or_cash
UNION ALL SELECT gl_code_bank_or_cash AS gl_code, 0 AS credit, SUM(amount) AS debit FROM payment GROUP BY gl_code_bank_or_cash
UNION ALL SELECT gl_code_bank_or_cash AS gl_code, 0 AS credit, SUM(amount) AS debit FROM service_payment GROUP BY gl_code_bank_or_cash) AS crdeb ON gl_account.gl_code=crdeb.gl_code
WHERE gl_account.category IN ('Bank', 'Cash') AND (bank_account.currency IS NULL OR bank_account.currency='MMK')
GROUP BY gl_account.gl_code
ORDER BY gl_account.gl_code, gl_account.`name`";
		$stmt = $this->conn->prepare($query);	
		$stmt->execute();
		return $stmt;
	} 
}
?>