<?php 
	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	 
	include_once 'config/_globle.php';
	include_once 'api/config/database.php';
	include_once 'api/objects/user.php';
	include_once 'api/objects/user_log.php';
	include_once 'api/objects/warranty_check_expire.php';
	include_once 'api/objects/warranty_car.php';

    session_start();
	date_default_timezone_set('Asia/Rangoon'); 

	$database = new Database();
	$db = $database->getConnection();
	
	$user = new User($db);
	$user_log = new UserLog($db);
	$warranty_check_expire = new WarrantyCheckExpire($db);
	$warranty_car = new WarrantyCar($db);

	$user->username = $_POST["username"];
	$user->password = $_POST["password"];

	if($user->isExist()){
		$_SESSION['userid'] = $user->id;
		$_SESSION['user'] = $user->username;
		$_SESSION['staff_id'] = $user->staff_id;
		$_SESSION['staff_name'] = $user->staff_name;
        $_SESSION['userrole'] = $user->userrole; 
        $_SESSION['dashboard'] = $user->dashboard; 
		$_SESSION['profilepicture'] = $user->profilepicture;
        $_SESSION['position'] = $user->position;  
        $_SESSION['sales_center'] = "";  
        $_SESSION['service_center_id'] = $user->service_center_id;  
        $_SESSION['service_center'] = $user->service_center;  
        $_SESSION['store_name'] = $user->store_name;   
		$_SESSION['start'] = time();
        $_SESSION['expire'] = $_SESSION['start'] + ((180 * 60) * 18); // ending a session in 30 minutes from the starting time

        if($user->userrole=="KEY"){
        	header("location:" . $app_url . "index." . $user->dashboard . ".php");
        }else{
        	header("location:" . $app_url . "index." . $user->dashboard . ".php"); 
        }

        $warranty_check_expire->date = date("Y-m-d");

		if(!$warranty_check_expire->checkDate()){
			$warranty_car->date = date("Y-m-d");
			$warranty_car->status = "Expire (Date)";
			$warranty_car->update_by = "System";
			$warranty_car->update_date_time = date("Y-m-d H:i:s");

			if($warranty_car->updateStatusExpireDate()){
				$warranty_check_expire->update();
			}
		}

		//inserting user log
		$user_log->username = $user->username;
		$user_log->ip_address = getUserIpAddr();
		$user_log->date_time = date("Y-m-d H:i:s");
		$user_log->create();
	}else{
		header("location:" . $app_url . "login.html?l=". $_POST["username"]);
	} 

	function getUserIpAddr(){
		if(!empty($_SERVER['HTTP_CLIENT_IP'])){
			//ip from share internet
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
			//ip pass from proxy
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}else{
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}
?>