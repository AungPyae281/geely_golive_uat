<?php include 'header.php'; ?>   
<div class="content-wrapper">
	<div class="content-header">
		<h3>Dashboard</h3>
	</div>
	<section class="content">
		<div class="container-fluid">
		</div>
	</section>
</div>	

<?php include 'footer.php'; ?>

<script>
	$(function() {
		$("body").addClass("sidebar-collapse"); 
	});	 
</script>