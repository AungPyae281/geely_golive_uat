<?php include '../header.php'; ?>
<?php
	$action = "";
	$id = "";

	if(isset($_GET['act'])){
		if(!empty($_GET['act'])){
			$action = $_GET['act'];
		}
	}

	if(isset($_GET['id'])){
		if(!empty($_GET['id'])){
			$id = $_GET['id'];
		}
	}
?>
<style>
	.form-group{
		font-size: 13px !important;
	}

	.col-form-label {
		padding-top: calc(0.20rem + 1px);
		padding-bottom: calc(0.375rem + 1px);
		margin-bottom: 0;
		font-size: 13px;
		line-height: 1.2;
	}

	.form-control {
		display: block;
		width: 100%;
		height: calc(1.11rem + 11px);
		padding: 0.375rem 0.75rem;
		font-size: 0.9rem;
		font-weight: 400;
		line-height: 1.2;
		color: #495057;
		background-color: #ffffff;
		background-clip: padding-box;
		border: 1px solid #ced4da;
		border-radius: 0.25rem;
		box-shadow: inset 0 0 0 rgba(0, 0, 0, 0);
		transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
	}

	.card-header {
		background-color: transparent;
		border-bottom: 1px solid rgba(0, 0, 0, 0.125);
		position: relative;
		padding: 0.35rem 1.10rem;
		border-top-left-radius: 0.25rem;
		border-top-right-radius: 0.25rem;
	}

	.btn{
		font-size: 13px;
		line-height: 1.4;
	}

	.table th, .table td {
		padding: 0.40rem;
	}

	select{
		padding-top: 1px !important;
	}

	.breadcrumb-item {
		color: gray;
	}

	.breadcrumb-item.done{
		color: #000;
	}

	.breadcrumb-item.active {
		color: #000 !important;
		font-weight: bold;
	}

	.breadcrumb-item + .breadcrumb-item:before{
		content: ">" !important;
		font-weight: normal !important;
	}

	.badge{
		padding: 5px 12px;
		font-size: 11px;
		margin-right: 3px;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Service Arrival Inspection</h1>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item active">Arrival Inspection</li>
						<li class="breadcrumb-item">Service</li>
						<li class="breadcrumb-item">Job Card</li>
						<li class="breadcrumb-item">Final Inspection</li>
					</ol>
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360" style="margin: 70px 45%;"></i>
						</div>
						<div class="card-body">	
							<div class="row">
								<div class="col-md-6">
									<div class="form-group row">
										<input type="hidden" id="txtAppointmentID">
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Center: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceCenter" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Registration No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceRegistrationNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Owner Name: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtOwnerName" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Owner Phone: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtOwnerPhone" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Appt. Contact Person: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtApptContactPerson" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Appt. Contact Phone: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtApptContactPhone" value="" disabled>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Plate No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtPlateNo" data-id="" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Model Name: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtModelName" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Vin No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtVinNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row" style="display:none;">
										<label class="col-md-4 col-form-label" style="text-align: right;">Valid Warranty: </label>
										<div class="col-md-8" id="ValidWarranty"></div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Kilometer: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);" id="txtKilometer" value="0" style="text-align:right;">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Car Receive Date/Time: </label>
										<div class="col-md-4">
											<div class="input-group input-append date" id="datePicker" data-date="2020-02-07" data-date-format="yyyy-mm-dd">
												<div class="input-group-prepend">
													<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
														<i class="far fa-calendar-alt"></i>
													</span>
												</div>
												<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
											</div>
										</div>
										<div class="col-md-4">
											<div class="input-group bootstrap-timepicker">
                                                <div class="input-group-addon input-group-text" style="border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: 29px !important;">
                                                    <i class="far fa-clock"></i>
                                                </div>
                                                <input type="text" class="form-control timepicker" id="txtTimePicker" readonly>
                                            </div>
										</div>
									</div>
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group row">
										<div class="col-md-12 car_wrapper" style="text-align: right;">
											<img id="img_car" src="" style="display:none;" />
											<canvas id="canvas_car" class="signature-pad" width=400 height=300></canvas>
										</div>
									</div>
									<div class="form-group row">
										<div class="col-md-12" style="text-align: right;">
											<button type="button" class="btn btn-primary" id="btnSaveCar" style="width: 100px;">Save</button>
											<button type="button" class="btn btn-danger" id="btnClearCar" style="width: 100px;">Clear</button>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group row" style="margin-bottom: 0px !important;">
										<label class="col-md-4 col-form-label" style="text-align: right;"></label>
										<div class="col-md-4 icheck-primary d-inline">
											<input id="chkServiceBooklet" type="checkbox">
											<label for="chkServiceBooklet">Service Booklet</label>
										</div>
										<div class="col-md-4 icheck-primary d-inline">
											<input id="chkJackandHandle" type="checkbox">
											<label for="chkJackandHandle">Jack and Handle</label>
										</div>
									</div>
									<div class="form-group row" style="margin-bottom: 0px !important;">
										<label class="col-md-4 col-form-label" style="text-align: right;"></label>
										<div class="col-md-4 icheck-primary d-inline">
											<input id="chkPakingSign" type="checkbox">
											<label for="chkPakingSign">Paking Sign</label>
										</div>
										<div class="col-md-4 icheck-primary d-inline">
											<input id="chkSpareWheel" type="checkbox">
											<label for="chkSpareWheel">Spare Wheel</label>
										</div>
									</div>
									<div class="form-group row" style="margin-bottom: 0px !important;">
										<label class="col-md-4 col-form-label" style="text-align: right;"></label>
										<div class="col-md-4 icheck-primary d-inline">
											<input id="chkMobileCharger" type="checkbox">
											<label for="chkMobileCharger">Mobile Charger</label>
										</div>
										<div class="col-md-4 icheck-primary d-inline">
											<input id="chkCarKey" type="checkbox">
											<label for="chkCarKey">Car Key</label>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;"></label>
										<div class="col-md-4 icheck-primary d-inline">
											<input id="chkWheelTax" type="checkbox">
											<label for="chkWheelTax">Wheel Tax</label>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Fuel Level: </label>
										<div class="col-md-8">
											<select class="form-control" id="cboFuelLevel"></select>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Other Items: </label>
										<div class="col-md-8">
											<textarea class="form-control" id="txtOtherItems" rows="3"></textarea>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Remark: </label>
										<div class="col-md-8">
											<textarea class="form-control" id="txtInspectionRemark" rows="4"></textarea>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-9 col-form-label"></label>
										<div class="col-md-3">
											<?php if($action=="entry"){ ?>
												<button type="button" class="btn btn-block btn-success" onclick="validateAndSave()">Submit</button>
											<?php }else{ ?>
												<button type="button" class="btn btn-block btn-primary" onclick="validateAndUpdate()">Update</button>
											<?php } ?>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div> 
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
    var action = '<?= $action ?>';
    var id = '<?= $id ?>';
	var d = new Date();
    var mm = (d.getMonth("MM")+1);
    var dd = d.getDate();
    var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
    $('#datePicker').attr("data-date", customDate);
    $("#txtDatePicker").val(customDate);

	$(function() {
		$("body").addClass("sidebar-collapse");
    	$('#datePicker').datepicker();
    	$('#txtTimePicker').timepicker({
            minuteStep: 5,
            showInputs: false
        });
        $('#txtTimePicker').timepicker('setTime', '09:00 AM');
        if(action=="entry"){
        	getAppointmentInfo();
        }else{
        	getServiceInspectionDetail();
        }

		signaturePad(APP_URL + "img/car-sheet.png", "");
	});

	function addFuelLevel(num){
		$("#cboFuelLevel").find("option").remove();
		for (var i = 5; i <= 100; i+=5) {
			if(parseInt(num)==i){
				$("#cboFuelLevel").append("<option value='" + i + "' selected>" + i + "</option>");
			}else{
				$("#cboFuelLevel").append("<option value='" + i + "'>" + i + "</option>");
			}
		}
	}

	function signaturePad(orgImg, finalImg){
		//SignaturePad
		const canvas = document.getElementById("canvas_car");
		const context = canvas.getContext("2d");
		const img = new Image();
		img.src = ((finalImg!="")?finalImg:orgImg);
		img.onload = () => { 
			context.drawImage(img, 0, 0, canvas.width, canvas.height);
		}

		var signaturePad = new SignaturePad(canvas, {
			backgroundColor: 'rgba(255, 255, 255, 0)',
			penColor: 'rgb(227, 0, 0)'
		});

		var saveButton = document.getElementById('btnSaveCar');
		var clearButton = document.getElementById('btnClearCar');

		clearButton.addEventListener('click', function (event) {
			signaturePad.clear();
			$("#img_car").attr("src", "");
			img.src = orgImg;
			img.onload = () => { 
				context.drawImage(img, 0, 0, canvas.width, canvas.height);
			}
		});

		saveButton.addEventListener("click", () => {
			if (signaturePad.isEmpty()) {
				bootbox.alert("Please provide a signature first.");
			} else {
				canvas.getContext("2d");
				$("#img_car").attr("src", canvas.toDataURL("image/png"));
			}
		}); 
	}

	function GenerateRegNo(){
		$.ajax({
			url: APP_URL + "api/service/service/get_generate_reg_no.php"
		}).done(function(data){
			$("#txtServiceRegistrationNo").val(data);
		});		
	}

	function getAppointmentInfo(){
		$("#ValidWarranty").empty();
		$.ajax({
			url: APP_URL + "api/service/service_appointment/get_one_appointment_info.php",
			type: "POST",
			data: JSON.stringify({ id: id }),
		}).done(function(data){
			$("#txtAppointmentID").val(id);
			$("#txtServiceCenter").val(data.service_center);
			GenerateRegNo();
			$("#txtOwnerName").val(data.owner_name);
			$("#txtOwnerPhone").val(data.owner_phone);
			$("#txtApptContactPerson").val(data.contact_person);
			$("#txtApptContactPhone").val(data.contact_phone);
			$("#txtPlateNo").val(data.plate_no);
			$("#txtPlateNo").attr("data-id", data.service_car_id);
			$("#txtModelName").val(data.model);
			$("#txtVinNo").val(data.vin_no);
			$("#txtEngineNo").val(data.engine_no);
			$("#txtKilometer").val(data.kilometer);
			addFuelLevel();

			if(data.valid_warranty.length>0){
				$("#ValidWarranty").parent().css("display", "");
				$.each(data.valid_warranty, function(i, v){
					$("#ValidWarranty").append('<span class="badge bg-primary">' + v + '</span>');
				});
			}else{
				$("#ValidWarranty").parent().css("display", "none");
			}
		});		
	} 

	function validateAndSave(){
		var appointment_id = $("#txtAppointmentID").val();
		var service_car_id = $("#txtPlateNo").attr("data-id");
		var plate_no = $("#txtPlateNo").val(); 
		var service_center = $("#txtServiceCenter").val();
		var kilometer = parseInt($("#txtKilometer").val().replace(/,/g, ''));
		var car_receive_date = $("#txtDatePicker").val();
		var car_receive_time = $("#txtTimePicker").val();
		var car_inspection_img = $("#img_car").attr("src");
		var insp_service_booklet = (($("#chkServiceBooklet").prop("checked"))?1:0);
		var insp_jack_and_handle = (($("#chkJackandHandle").prop("checked"))?1:0);
		var insp_paking_sign = (($("#chkPakingSign").prop("checked"))?1:0);
		var insp_spare_wheel = (($("#chkSpareWheel").prop("checked"))?1:0);
		var insp_mobile_charger = (($("#chkMobileCharger").prop("checked"))?1:0);
		var insp_car_key = (($("#chkCarKey").prop("checked"))?1:0);
		var insp_wheel_tax = (($("#chkWheelTax").prop("checked"))?1:0);
		var insp_fuel_level = $("#cboFuelLevel").val();
		var insp_other_items = $("#txtOtherItems").val();
		var insp_remark = $("#txtInspectionRemark").val();

		if(kilometer==0){
			bootbox.alert("Please fill kilometer.");
		}else{
			$("#loading").css("display", "block");
			$.ajax({
				url: APP_URL + "api/service/service/create_inspection.php",
				type: "POST",
				data: JSON.stringify({ appointment_id: appointment_id, service_car_id: service_car_id, plate_no: plate_no, service_center: service_center, kilometer: kilometer, car_receive_date: car_receive_date, car_receive_time: car_receive_time, car_inspection_img: car_inspection_img, insp_service_booklet: insp_service_booklet, insp_jack_and_handle: insp_jack_and_handle, insp_paking_sign: insp_paking_sign, insp_spare_wheel: insp_spare_wheel, insp_mobile_charger: insp_mobile_charger, insp_car_key: insp_car_key, insp_wheel_tax: insp_wheel_tax, insp_fuel_level: insp_fuel_level, insp_other_items: insp_other_items, insp_remark: insp_remark })
			}).done(function(data) {
				$("#loading").css("display", "none");
				if(data.message=="created"){ 
					bootbox.confirm({
			            message: "<h4>Do you want to add services?</h4>",
			            buttons: {
			                cancel: {
			                    label: '<span class="glyphicon glyphicon-ok"></span> No',
			                    className: 'btn-danger'
			                },
			                confirm: {
			                    label: '<span class="glyphicon glyphicon-ok"></span> Yes',
			                    className: 'btn-primary'
			                }
			            },
			            callback: function (result) {
			                if(result){
			                	document.location = APP_URL + "service/service.php?act=entry&id=" + data.id; 
			                }else{
			                	document.location = APP_URL + "service/service_appointment_list.php"; 
			                }
			            }
			        });
				}else if(data.message=="session expire"){
					bootbox.alert("Session Expire! Please refresh the browser and login again.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function getServiceInspectionDetail(){
		$.ajax({
			url: APP_URL + "api/service/service/get_one_service.php",
			type: "POST",
			data: JSON.stringify({ id: id }),
		}).done(function(data){
			var tf = false;
			$(".breadcrumb-item").removeClass("done");
			$(".breadcrumb-item").removeClass("active");
			$(".breadcrumb-item").each(function(){
				if(tf){
					$(this).addClass("active");
					return false;
				}else{
					$(this).addClass("done");
				}
				if($(this).text()==data.status){
					tf = true;
				}
			});

			addFuelLevel(data.insp_fuel_level);

			$("#txtAppointmentID").val(data.appointment_id);
			$("#txtServiceCenter").val(data.service_center);
			$("#txtServiceRegistrationNo").val(data.registration_no);
			$("#txtOwnerName").val(data.owner_name);
			$("#txtOwnerPhone").val(data.owner_phone);
			$("#txtApptContactPerson").val(data.appt_contact_person);
			$("#txtApptContactPhone").val(data.appt_contact_phone);
			$("#txtPlateNo").val(data.plate_no);
			$("#txtPlateNo").attr("data-id", data.service_car_id);
			$("#txtModelName").val(data.model);
			$("#txtVinNo").val(data.vin_no);
			$("#txtEngineNo").val(data.engine_no);
			$("#txtKilometer").val(data.kilometer);
			$("#txtDatePicker").val(data.car_receive_date);
			$("#datePicker").datepicker("setDate", data.car_receive_date);
            $("#txtTimePicker").val(data.car_receive_time);

            $("#chkServiceBooklet").prop("checked", data.insp_service_booklet);
            $("#chkJackandHandle").prop("checked", data.insp_jack_and_handle);
            $("#chkPakingSign").prop("checked", data.insp_paking_sign);
            $("#chkSpareWheel").prop("checked", data.insp_spare_wheel);
            $("#chkMobileCharger").prop("checked", data.insp_mobile_charger);
            $("#chkCarKey").prop("checked", data.insp_car_key);
            $("#chkWheelTax").prop("checked", data.insp_wheel_tax);
            $("#txtOtherItems").val(data.insp_other_items);
            $("#txtInspectionRemark").val(data.insp_remark);

            var finalImg = "";
			if(data.car_inspection_img!=""){
				finalImg = APP_URL + "api/service/service/" + data.car_inspection_img.split("./")[1] + "?t" + d.getTime();
			}
			signaturePad(APP_URL + "img/car-sheet.png", finalImg);
		});		
	}

	function validateAndUpdate(){ 
		var kilometer = parseInt($("#txtKilometer").val().replace(/,/g, ''));
		var car_receive_date = $("#txtDatePicker").val();
		var car_receive_time = $("#txtTimePicker").val();
		var car_inspection_img = $("#img_car").attr("src");
		var insp_service_booklet = (($("#chkServiceBooklet").prop("checked"))?1:0);
		var insp_jack_and_handle = (($("#chkJackandHandle").prop("checked"))?1:0);
		var insp_paking_sign = (($("#chkPakingSign").prop("checked"))?1:0);
		var insp_spare_wheel = (($("#chkSpareWheel").prop("checked"))?1:0);
		var insp_mobile_charger = (($("#chkMobileCharger").prop("checked"))?1:0);
		var insp_car_key = (($("#chkCarKey").prop("checked"))?1:0);
		var insp_wheel_tax = (($("#chkWheelTax").prop("checked"))?1:0);
		var insp_fuel_level = $("#cboFuelLevel").val();
		var insp_other_items = $("#txtOtherItems").val();
		var insp_remark = $("#txtInspectionRemark").val();

		if(kilometer==0){
			bootbox.alert("Please fill kilometer.");
		}else{
			$("#loading").css("display", "block");
			$.ajax({
				url: APP_URL + "api/service/service/update_inspection.php",
				type: "POST",
				data: JSON.stringify({ id: id, kilometer: kilometer, car_receive_date: car_receive_date, car_receive_time: car_receive_time, car_inspection_img: car_inspection_img, insp_service_booklet: insp_service_booklet, insp_jack_and_handle: insp_jack_and_handle, insp_paking_sign: insp_paking_sign, insp_spare_wheel: insp_spare_wheel, insp_mobile_charger: insp_mobile_charger, insp_car_key: insp_car_key, insp_wheel_tax: insp_wheel_tax, insp_fuel_level: insp_fuel_level, insp_other_items: insp_other_items, insp_remark: insp_remark })
			}).done(function(data) {
				$("#loading").css("display", "none");
				if(data.message=="updated"){ 
					document.location = APP_URL + "service/servicing_list.php"; 
				}else if(data.message=="session expire"){
					bootbox.alert("Session Expire! Please refresh the browser and login again.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
		$(obj).val(parseInt(amount).toLocaleString());
    }	
</script>	
