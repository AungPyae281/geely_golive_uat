<?php include '../header.php'; ?>
<?php
	$action = "";
	$id = "";
	if(isset($_GET['act'])){
		if(!empty($_GET['act'])){
			$action = $_GET['act'];
		}
	}

	if(isset($_GET['id'])){
		if(!empty($_GET['id'])){
			$id = $_GET['id'];
		}
	}
?>
<style> 
	.form-group{
		font-size: 13px !important;
	}

	.col-form-label {
		padding-top: calc(0.20rem + 1px);
		padding-bottom: calc(0.375rem + 1px);
		margin-bottom: 0;
		font-size: 13px;
		line-height: 1.2;
	}

	.form-control {
		display: block;
		width: 100%;
		height: calc(1.11rem + 11px);
		padding: 0.375rem 0.75rem;
		font-size: 0.9rem;
		font-weight: 400;
		line-height: 1.2;
		color: #495057;
		background-color: #ffffff;
		background-clip: padding-box;
		border: 1px solid #ced4da;
		border-radius: 0.25rem;
		box-shadow: inset 0 0 0 rgba(0, 0, 0, 0);
		transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
	}

	.card-header {
		background-color: transparent;
		border-bottom: 1px solid rgba(0, 0, 0, 0.125);
		position: relative;
		padding: 0.35rem 1.10rem;
		border-top-left-radius: 0.25rem;
		border-top-right-radius: 0.25rem;
	}

	.btn{
		font-size: 13px;
		line-height: 1.4;
	}

	.table th, .table td {
		padding: 0.40rem;
	}

	select{
		padding-top: 1px !important;
	}

	.breadcrumb-item {
		color: gray;
	}

	.breadcrumb-item.done{
		color: #000;
	}

	.breadcrumb-item.active {
		color: #000 !important;
		font-weight: bold;
	}

	.breadcrumb-item + .breadcrumb-item:before{
		content: ">" !important;
		font-weight: normal !important;
	}

	.tblTitle{
		font-weight: bold;
		font-size: 16px;
	}

	#myTableToDoList tbody td:nth-child(2){
		width: 5%;
		text-align: right;
	}

	#myTableProcessingList tbody td:nth-child(5){
		width: 15%;
		text-align: right;
	}

	#myTableCompletedList tbody td:nth-child(1), #myTableCompletedList tbody td:nth-child(7){
		width: 5%;
		text-align: center;
		padding-left: 5px !important;
		padding-right: 5px !important;
	}

	#myTableCompletedList tbody td:nth-child(7){
	}

	.btnProcess{
		padding-top: 1px;
		padding-bottom: 1px;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Job Card</h1>
				</div>
				<div class="col-md-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item">Arrival Inspection</li>
						<li class="breadcrumb-item">Service</li>
						<li class="breadcrumb-item active">Job Card</li>
						<li class="breadcrumb-item">Final Inspection</li>
					</ol>
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="card-body">	
							<div class="row">
								<div class="col-md-6">
									<div class="form-group row"> 
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Center: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceCenter" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Registration No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceRegistrationNo" value="" disabled>
										</div> 
									</div> 
									<div class="form-group row"> 
										<label class="col-md-4 col-form-label" style="text-align: right;">Contact Person: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceContactPerson" data-id="" value="" disabled> 
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Contact Phone: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtServiceContactPhone" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right; padding-top: 7px;">Test Drive Agree:</label>
										<div class="col-md-8 icheck-success d-inline">
											<input id="chkTestDriveAgree" type="checkbox" disabled>
											<label for="chkTestDriveAgree"></label>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Plate No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtPlateNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Model Name: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtModelName" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Vin No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtVinNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Engine No.: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtEngineNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Main Technician: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtMainTechnician" value="" disabled>
										</div>
									</div>
								</div>
							</div> 
							
							<div class="row" style="margin-top:30px;">
								<div class="col-md-4">
									<div class="card card-outline">
										<div class="card-header">
											<h3 class="card-title tblTitle" style="font-weight: bold;">To Do List</h3>
										</div>
										<div class="card-body p-0" style="max-height: 200px; overflow-y: auto;">
											<table class="table table-hover" id="myTableToDoList">
												<tbody></tbody>
											</table>
										</div>
									</div>
								</div>
								<div class="col-md-8">
									<div class="card card-outline">
										<div class="card-header">
											<h3 class="card-title tblTitle" style="font-weight: bold;">Processing List</h3>
										</div>
										<div class="card-body p-0" style="max-height: 200px; overflow-y: auto;">
											<table class="table table-hover" id="myTableProcessingList">
												<tbody></tbody>
											</table>
										</div>
									</div>
								</div>
							</div>

							<div class="row" style="margin-top: 10px;">
								<div class="col-md-12">
									<div class="card card-outline">
										<div class="card-header">
											<h3 class="card-title tblTitle" style="font-weight: bold;">Completed List</h3>
										</div>
										<div class="card-body p-0" style="max-height: 200px; overflow-y: auto;">
											<table class="table table-bordered table-striped" id="myTableCompletedList">
												<thead>
													<tr>
														<th>No.</th>
														<th>Item</th>
														<th>Technician</th>
														<th>Bay No.</th>
														<th>Start Time</th>
														<th>End Time</th>
														<th></th>
													</tr>
												</thead>
												<tbody></tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<center>
				<div class="modal fade" id="myModalToDo">
					<div class="modal-dialog" style="max-width: 100% !important;">
						<div class="modal-content" style="width: 500px; top: 30px;">
							<div class="modal-header" style="padding: 10px 15px;">
								<h4 class="modal-title"></h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<div class="row">
									<input type="hidden" id="txtIDMyModalToDo">
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-3 col-form-label" style="text-align: right;">Item Code: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtItemCodeMyModalToDo" disabled>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-3 col-form-label" style="text-align: right;">Item Name: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtItemNameMyModalToDo" disabled>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-3 col-form-label" style="text-align: right;">Technician: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboTechnicianMyModalToDo"></select>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-3 col-form-label" style="text-align: right;">Bay No.: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboBayNoMyModalToDo"></select>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-3 col-form-label" style="text-align: right;">Start Time: </label>
											<div class="col-md-8">
												<div class="input-group bootstrap-timepicker">
		                                            <div class="input-group-addon input-group-text" style="border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: 29px !important;">
		                                                <i class="far fa-clock"></i>
		                                            </div>
		                                            <input type="text" class="form-control timepicker" id="txtTimePickerStart" readonly>
		                                        </div>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-7 col-form-label"></label>
											<div class="col-md-4">
												<button type="button" class="btn btn-block btn-primary" onclick="addProcessing(this)">Add</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 
			</center>

			<center>
				<div class="modal fade" id="myModalProcessing"> 
					<div class="modal-dialog" style="max-width: 100% !important;">
						<div class="modal-content" style="width: 500px; top: 30px;">
							<div class="modal-header" style="padding: 10px 15px;">
								<h4 class="modal-title"></h4>
								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>
							<div class="modal-body">
								<div class="row">
									<input type="hidden" id="txtIDMyModalProcessing">
									<input type="hidden" id="txtWTMyModalProcessing">
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-3 col-form-label" style="text-align: right;">Item Code: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtItemCodeMyModalProcessing" disabled>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-3 col-form-label" style="text-align: right;">Item Name: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtItemNameMyModalProcessing" disabled>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-3 col-form-label" style="text-align: right;">Technician: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtTechnicianMyModalProcessing" data-id="" disabled>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-3 col-form-label" style="text-align: right;">Bay No.: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtBayNoMyModalProcessing" disabled>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-3 col-form-label" style="text-align: right;">Start Time: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtStartTimeMyModalProcessing" disabled>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-3 col-form-label" style="text-align: right;">End Time: </label>
											<div class="col-md-8">
												<div class="input-group bootstrap-timepicker">
		                                            <div class="input-group-addon input-group-text" style="border-top-right-radius: 0px; border-bottom-right-radius: 0px;height: 29px !important;">
		                                                <i class="far fa-clock"></i>
		                                            </div>
		                                            <input type="text" class="form-control timepicker" id="txtTimePickerEnd" readonly>
		                                        </div>
											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="form-group row" style="margin-bottom: 5px !important;">
											<label class="col-md-7 col-form-label"></label>
											<div class="col-md-4">
												<button type="button" class="btn btn-block btn-success" onclick="addComplete(this)">Done</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> 
			</center>

		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
    var action = '<?= $action ?>';
    var id = '<?= $id ?>';
    var STATUS = "";
    var SERVICE_ITEM_COUNT = "";
    var btnToDo = " <button class='btn btn-primary btnProcess btnToDo' title='Process'><i class='fa fa-wrench'></i></button>";
    var btnProcessUndo = " <button class='btn btn-danger btnProcess btnProcessUndo' title='Undo'><i class='fas fa-undo'></i></button>";
    var btnCompleted = " <button class='btn btn-success btnProcess btnCompleted' title='Done'><i class='fas fa-check'></i></button>";
    var btnCompletedUndo = " <button class='btn btn-danger btnProcess btnCompletedUndo' title='Undo'><i class='fas fa-undo'></i></button>";

	$(function() {
		$("body").addClass("sidebar-collapse"); 
		$('#txtTimePickerStart').timepicker({
            minuteStep: 5,
            showInputs: false
        });
        $('#txtTimePickerStart').timepicker('setTime', '09:00 AM');

        $('#txtTimePickerEnd').timepicker({
            minuteStep: 5,
            showInputs: false
        });
		getOneService(); 
	}); 

	$(document).on("click", ".btnToDo", function(){
		$("#myModalToDo").modal('show');
		$("#txtIDMyModalToDo").val($(this).parent().parent().attr("data-id"));
		$("#txtItemCodeMyModalToDo").val($(this).parent().parent().find(".tdItemCode").eq(0).text());
		$("#txtItemNameMyModalToDo").val($(this).parent().parent().find(".tdItemName").eq(0).text());
	});

	$(document).on("click", ".btnCompleted", function(){
		$("#myModalProcessing").modal('show');
		$("#txtIDMyModalProcessing").val($(this).parent().parent().attr("data-id"));
		$("#txtWTMyModalProcessing").val($(this).parent().parent().attr("data-wt"));
		$("#txtItemCodeMyModalProcessing").val($(this).parent().parent().find(".tdItemCode").eq(0).text());
		$("#txtItemNameMyModalProcessing").val($(this).parent().parent().find(".tdItemName").eq(0).text());
		$("#txtTechnicianMyModalProcessing").val($(this).parent().parent().find("td").eq(1).text());
		$("#txtTechnicianMyModalProcessing").attr("data-id", $(this).parent().parent().find("td").eq(1).attr("data-id"));
		$("#txtBayNoMyModalProcessing").val($(this).parent().parent().find("td").eq(2).text());
		$("#txtStartTimeMyModalProcessing").val($(this).parent().parent().find("td").eq(3).text());
        $('#txtTimePickerEnd').timepicker('setTime', $(this).parent().parent().find("td").eq(3).text());
	});

	$(document).on("click", ".btnProcessUndo", function(){
		processUndo(this);
	});

	$(document).on("click", ".btnCompletedUndo", function(){
		completedUndo(this);
	});

	function getAllTechnician(){
		$("#cboTechnicianMyModalToDo").find("option").remove();
        $("#cboTechnicianMyModalToDo").append("<option value=''></option>");
        $.ajax({
            url: APP_URL + "api/hr/staff/get_staff_by_position.php",
            type: "POST",
            data: JSON.stringify({ position: "Technician" })
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboTechnicianMyModalToDo").append("<option value='" + v.id + "'>" + v.name + "</option>");
            });
        });
	}

	function getAllBay(sc){
		$("#cboBayNoMyModalToDo").find("option").remove();
        $("#cboBayNoMyModalToDo").append("<option value=''></option>");
        $.ajax({
            url: APP_URL + "api/service/service_center_bay/get_bay_by_center.php",
            type: "POST",
            data: JSON.stringify({ service_center: sc })
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboBayNoMyModalToDo").append("<option value='" + v.bay_no + "'>" + v.bay_no + "</option>");
            });
        });
	}

	function getOneService(){
		$("#myTableToDoList").find("tbody tr").remove();
		$.ajax({
			url: APP_URL + "api/service/service/get_one_service.php",
			type: "POST",
			data: JSON.stringify({ id: id })
		}).done(function(data) {
			var tf = false;
			$(".breadcrumb-item").removeClass("done");
			$(".breadcrumb-item").removeClass("active");
			$(".breadcrumb-item").each(function(){
				if(tf){
					$(this).addClass("active");
					return false;
				}else{
					$(this).addClass("done");
				}
				if($(this).text()==data.status){
					tf = true;
				}
			});

			$("#txtServiceCenter").val(data.service_center);
			$("#txtServiceRegistrationNo").val(data.registration_no);
			$("#txtServiceContactPerson").val(data.contact_person);
			$("#txtServiceContactPerson").attr("data-id", data.service_customer_id);
			$("#txtServiceContactPhone").val(data.contact_phone);
			$("#chkTestDriveAgree").prop("checked", data.test_drive_agree);
			$("#txtPlateNo").val(data.plate_no);
			$("#txtModelName").val(data.model);
			$("#txtVinNo").val(data.vin_no);
			$("#txtEngineNo").val(data.engine_no);
			$("#txtMainTechnician").val(data.main_technician_name);
			getAllTechnician();
			getAllBay(data.service_center);

			$.each(data.service_items, function(i, v) {
				if(v.technician_id==0){
					$("#myTableToDoList").find("tbody")
					.append($('<tr data-id="' + v.id + '" data-wt="' + v.item_wt + '">')
						.append("<td>(<span class='tdItemCode'>" + v.item_code + "</span>) <span class='tdItemName'>" + v.item_name + "</span></td>")
						.append("<td>" + btnToDo + "</td>")
					);
				}else if(v.start_time!="" && v.end_time==""){
					$("#myTableProcessingList").find("tbody")
					.append($('<tr data-id="' + v.id + '" data-wt="' + v.item_wt + '">')
						.append("<td>(<span class='tdItemCode'>" + v.item_code + "</span>) <span class='tdItemName'>" + v.item_name + "</span></td>")
						.append("<td data-id='" + v.technician_id + "'>" + v.technician_name + "</td>")
						.append("<td>" + v.bay_no + "</td>")
						.append("<td>" + v.start_time + "</td>")
						.append("<td>" + btnProcessUndo + btnCompleted + "</td>")
					);
				}else if(v.end_time!=""){
					$("#myTableCompletedList").find("tbody")
					.append($('<tr data-id="' + v.id + '" data-wt="' + v.item_wt + '">')
						.append("<td>" + ($("#myTableCompletedList tbody tr").length + 1) + "</td>")
						.append("<td>(<span class='tdItemCode'>" + v.item_code + "</span>) <span class='tdItemName'>" + v.item_name + "</span></td>")
						.append("<td data-id='" + v.technician_id + "'>" + v.technician_name + "</td>")
						.append("<td>" + v.bay_no + "</td>")
						.append("<td>" + v.start_time + "</td>")
						.append("<td>" + v.end_time + "</td>")
						.append("<td>" + btnCompletedUndo + "</td>")
					);
				}
			});

			STATUS = data.status;
			SERVICE_ITEM_COUNT = data.service_items.length;
		});
	}

	function addProcessing(obj){
		$(obj).attr("disabled", true);
		var detail_id = $("#txtIDMyModalToDo").val();
		var item_code = $("#txtItemCodeMyModalToDo").val();
		var item_name = $("#txtItemNameMyModalToDo").val();
		var technician_id = $("#cboTechnicianMyModalToDo").val();
		var technician_name = $("#cboTechnicianMyModalToDo option:selected").text();
		var bay_no = $("#cboBayNoMyModalToDo").val();
		var start_time = $("#txtTimePickerStart").val();

		if(technician_id==""){
			bootbox.alert("Please choose technician.");
			$(obj).attr("disabled", false);
		}else if(bay_no==""){
			bootbox.alert("Please choose bay.");
			$(obj).attr("disabled", false);
		}else{
			jobCardProcessChange("Process", detail_id, item_code, item_name, technician_id, technician_name, bay_no, start_time, '');
			$(obj).attr("disabled", false);
		}
	}

	function processUndo(obj){
		var detail_id = $(obj).parent().parent().attr("data-id");
		var item_code = $(obj).parent().parent().find(".tdItemCode").eq(0).text();
		var item_name = $(obj).parent().parent().find(".tdItemName").eq(0).text();

		bootbox.confirm({
            message: "<h4>Do you want to undo this process?</h4>",
            buttons: {
                cancel: {
                    label: '<span class="glyphicon glyphicon-ok"></span> No',
                    className: 'btn-danger'
                },
                confirm: {
                    label: '<span class="glyphicon glyphicon-ok"></span> Yes',
                    className: 'btn-primary'
                }
            },
            callback: function (result) {
                if(result){
                	jobCardProcessChange("Process Undo", detail_id, item_code, item_name, 0, '', '', '', '', obj);
					$(obj).parent().parent().remove();
                } 
            }
        }); 
	}

	function addComplete(obj){
		$(obj).attr("disabled", true);
		var detail_id = $("#txtIDMyModalProcessing").val();
		var item_code = $("#txtItemCodeMyModalProcessing").val();
		var item_name = $("#txtItemNameMyModalProcessing").val();
		var technician_id = $("#txtTechnicianMyModalProcessing").attr("data-id");
		var technician_name = $("#txtTechnicianMyModalProcessing").val();
		var bay_no = $("#txtBayNoMyModalProcessing").val();
		var start_time = $("#txtStartTimeMyModalProcessing").val();
		var end_time = $("#txtTimePickerEnd").val();

		if(end_time==""){
			bootbox.alert("Please choose end time.");
			$(obj).attr("disabled", false);
		}else{
			jobCardProcessChange("Completed", detail_id, item_code, item_name, technician_id, technician_name, bay_no, start_time, end_time, obj);
			$(obj).attr("disabled", false);
		}
	}

	function completedUndo(obj){
		var detail_id = $(obj).parent().parent().attr("data-id");
		var item_code = $(obj).parent().parent().find(".tdItemCode").eq(0).text();
		var item_name = $(obj).parent().parent().find(".tdItemName").eq(0).text();
		var technician_id = $(obj).parent().parent().find("td").eq(2).attr("data-id");
		var technician_name = $(obj).parent().parent().find("td").eq(2).text();
		var bay_no = $(obj).parent().parent().find("td").eq(3).text();
		var start_time = $(obj).parent().parent().find("td").eq(4).text();

		bootbox.confirm({
            message: "<h4>Do you want to undo this process?</h4>",
            buttons: {
                cancel: {
                    label: '<span class="glyphicon glyphicon-ok"></span> No',
                    className: 'btn-danger'
                },
                confirm: {
                    label: '<span class="glyphicon glyphicon-ok"></span> Yes',
                    className: 'btn-primary'
                }
            },
            callback: function (result) {
                if(result){
                	jobCardProcessChange("Completed Undo", detail_id, item_code, item_name, technician_id, technician_name, bay_no, start_time, '', obj);
					$(obj).parent().parent().remove();
					rearrangeSorting("myTableCompletedList");
                } 
            }
        }); 
	}

	function jobCardProcessChange(stat, detail_id, item_code, item_name, technician_id, technician_name, bay_no, start_time, end_time, obj){
		var status = "";
		if(STATUS=="Service" && stat=="Completed" && $("#myTableToDoList tbody tr").length==0 && $("#myTableProcessingList tbody tr").length==1){
			status = "Job Card";
		}
		$.ajax({
			url: APP_URL + "api/service/service/job_card_process_change.php",
			type: "POST",
			data: JSON.stringify({ id: id, detail_id: detail_id, technician_id: technician_id, bay_no: bay_no, start_time: start_time, end_time: end_time, status: status })
		}).done(function(data) {
			if(data.message=="updated"){ 
				if(stat=="Process"){

					$("#myTableProcessingList").find("tbody")
					.append($('<tr data-id="' + detail_id + '">')
						.append("<td>(<span class='tdItemCode'>" + item_code + "</span>) <span class='tdItemName'>" + item_name + "</span></td>")
						.append("<td data-id='" + technician_id + "'>" + technician_name + "</td>")
						.append("<td>" + bay_no + "</td>")
						.append("<td>" + start_time + "</td>")
						.append("<td>" + btnProcessUndo + btnCompleted + "</td>")
					);
					$("#myTableToDoList tbody tr[data-id='" + detail_id + "']").remove();
					$("#myModalToDo").modal('hide');

				}else if(stat=="Process Undo"){

                    $("#myTableToDoList").find("tbody")
					.append($('<tr data-id="' + detail_id + '">')
						.append("<td>(<span class='tdItemCode'>" + item_code + "</span>) <span class='tdItemName'>" + item_name + "</span></td>")
						.append("<td>" + btnToDo + "</td>")
					);

				}else if(stat=="Completed"){

					$("#myTableCompletedList").find("tbody")
					.append($('<tr data-id="' + detail_id + '">')
						.append("<td>" + ($("#myTableCompletedList tbody tr").length + 1) + "</td>")
						.append("<td>(<span class='tdItemCode'>" + item_code + "</span>) <span class='tdItemName'>" + item_name + "</span></td>")
						.append("<td data-id='" + technician_id + "'>" + technician_name + "</td>")
						.append("<td>" + bay_no + "</td>")
						.append("<td>" + start_time + "</td>")
						.append("<td>" + end_time + "</td>")
						.append("<td>" + btnCompletedUndo + "</td>")
					);
					$("#myTableProcessingList tbody tr[data-id='" + detail_id + "']").remove();
					$("#myModalProcessing").modal('hide');

					if($("#myTableToDoList tbody tr").length==0 && $("#myTableProcessingList tbody tr").length==0){
						document.location = APP_URL + "service/servicing_list.php";
					}

				}else if(stat=="Completed Undo"){

                	$("#myTableProcessingList").find("tbody")
					.append($('<tr data-id="' + detail_id + '">')
						.append("<td>(<span class='tdItemCode'>" + item_code + "</span>) <span class='tdItemName'>" + item_name + "</span></td>")
						.append("<td data-id='" + technician_id + "'>" + technician_name + "</td>")
						.append("<td>" + bay_no + "</td>")
						.append("<td>" + start_time + "</td>")
						.append("<td>" + btnProcessUndo + btnCompleted + "</td></td>")
					);

				}
			}else if(data.message=="session expire"){
				bootbox.alert("Session Expire! Please refresh the browser and login again.");
			}else{
				bootbox.alert("Error on server side.");
			}
			$(obj).attr("disabled", false);
		});
	}

	function rearrangeSorting(id){
		$("#" + id + " tbody tr").each(function(){
			$(this).find("td").eq(0).text($(this).index() + 1);
		});
	}
</script>	
