<?php include '../header.php'; ?>
<?php
    $accno = "";
    if(isset($_GET['accno'])){
        if(!empty($_GET['accno'])){
            $accno = $_GET['accno'];
        }
    }
?>
<style>
	select {
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Bank Account Transfer - Entry</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;padding-left: 0px;">Account (From): </label>
											<div class="col-md-8">
												<select class="form-control" id="cboAccountFrom"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Balance: </label>
											<div class="col-md-6">
												<input type="text" class="form-control" id="txtBalanceFrom" disabled style="text-align:right;" value="0">
											</div>
											<div class="col-md-2">
												<input type="text" class="form-control" id="txtCurrencyFrom" disabled>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Account (To): </label>
											<div class="col-md-8">
												<select type="text" class="form-control" id="cboAccountTo"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Balance: </label>
											<div class="col-md-6">
												<input type="text" class="form-control" id="txtBalanceTo" disabled style="text-align:right;" value="0">
											</div>
											<div class="col-md-2">
												<input type="text" class="form-control" id="txtCurrencyTo" disabled>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Date: </label>
											<div class="col-md-8">  
												<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Amount (From): </label>
											<div class="col-md-6">
												<input type="text" class="form-control" id="txtAmountFrom" value="0" style="text-align:right;">
											</div>
											<div class="col-md-2">
												<input type="text" class="form-control" id="txtAmountFromCurrency" disabled>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Amount (To): </label>
											<div class="col-md-6">
												<input type="text" class="form-control" id="txtAmountTo" value="0" style="text-align:right;">
											</div>
											<div class="col-md-2">
												<input type="text" class="form-control" id="txtAmountToCurrency" disabled>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Exchange Rate: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtExchangeRate" value="0" style="text-align:right;" disabled>
											</div> 
										</div> 
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 control-label" style="text-align: right;">Upload Receipt:</label>
											<div class="col-md-8">
												<input style="display:none" name="file" id="input-image-hidden" onchange="document.getElementById('previewing').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
												<img id="previewing" name="previewing" src="<?=$app_url;?>img/no_image.jpg" style="height:133px; width:auto;cursor:pointer;"onclick="HandleBrowseClick('input-image-hidden');" title="Click to Change the Photo.">
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-4"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" id="btnSubmit">Transfer</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title"><span id="total_records" style="font-weight:bold;"> </span></h3>
						</div>
						<div class="card-body p-0">
							<table class="table table-striped table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%">No.</th> 
										<th>Account (From)</th>
										<th>Account (To)</th>
										<th>Amount (From)</th>
										<th>Amount (To)</th> 
										<th>Exchange Rate</th> 
										<th style="width: 10%">Upload Receipt</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var accno = '<?= $accno; ?>';
	var d = new Date();
	var mm = (d.getMonth("MM") + 1);
	var dd = d.getDate();
  	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function() {
		$("body").addClass("sidebar-collapse");
		$('#datePicker').datepicker();
		getAllBankAccount();
		getAllRows();
	});

	$("#txtAmountFrom").on("input", function(){
		isNumberDecimal(this);
		calculateExchangeRate();
	});

	$("#txtAmountTo").on("input", function(){
		isNumberDecimal(this);
		calculateExchangeRate();
	});
 
	$("#txtCharges").on("input", function(){
		isNumberDecimal(this);
	});

	$("#txtDatePicker").change(function(){
		getAllRows();
	});

	$('#cboAccountFrom').on('change',function(){
		if($("#cboAccountFrom").val()!=""){
			$("#txtBalanceFrom").val(parseFloat($("#cboAccountFrom option:selected").attr("data-balance")).toLocaleString());
			$("#txtCurrencyFrom").val($('#cboAccountFrom option:selected').attr('data-currency'));
			$("#txtAmountFromCurrency").val($('#cboAccountFrom option:selected').attr('data-currency'));
			$("#cboAccountTo").find("option").show();
			$("#cboAccountTo").find("option[value='" + $(this).val() + "']").hide();
		}else{
			$("#txtBalanceFrom").val(0);
			$("#txtCurrencyFrom").val("");
			$("#txtAmountFromCurrency").val("");
			$("#cboAccountTo").find("option").show();
		}
	});

	$('#cboAccountTo').on('change',function(){
		if($("#cboAccountTo").val()!=""){
			$("#txtBalanceTo").val(parseFloat($("#cboAccountTo option:selected").attr("data-balance")).toLocaleString());
			$("#txtCurrencyTo").val($('#cboAccountTo option:selected').attr('data-currency'));
			$("#txtAmountToCurrency").val($('#cboAccountTo option:selected').attr('data-currency'));
			$("#cboAccountFrom").find("option").show();
			$("#cboAccountFrom").find("option[value='" + $(this).val() + "']").hide();
		}else{
			$("#txtBalanceTo").val(0);
			$("#txtCurrencyTo").val("");
			$("#txtAmountToCurrency").val("");
			$("#cboAccountFrom").find("option").show();
		}
	});

	function getAllBankAccount(){
		$("#txtCurrencyFrom").val("");
		$("#txtCurrencyTo").val("");
		$("#txtAmountFromCurrency").val("");
		$("#txtAmountToCurrency").val("");
		$("#cboAccountFrom").find("option").remove();
		$("#cboAccountFrom").append("<option value='' data-glcode='' data-id='' data-currency='' data-balance='0'></option>");
		$("#cboAccountTo").find("option").remove();
		$("#cboAccountTo").append("<option value='' data-glcode='' data-id='' data-currency='' data-balance='0'></option>");

		$.ajax({
			url: APP_URL + "api/finance/bank_account/get_all_bank_account.php"
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				$("#cboAccountFrom").append("<option value = '" + v.account_no + "' data-glcode='" + v.gl_code + "' data-id = '" + v.id + "' data-currency = '" + v.currency + "' data-balance = '" + v.balance + "'>" + v.account_no + " (" + v.bank_name + " - " + v.currency + ")</option>");
				$("#cboAccountTo").append("<option value= '" + v.account_no + "' data-glcode='" + v.gl_code + "' data-id = '"+ v.id + "' data-currency = '"+ v.currency +"' data-balance = '" + v.balance + "'>" + v.account_no + " (" + v.bank_name + " - " + v.currency + ")</option>");
			});

			if(accno){
				$("#cboAccountFrom").find("option[value='" + accno + "']").attr("selected", "selected");
				$("#txtBalanceFrom").val(parseFloat($("#cboAccountFrom option:selected").attr("data-balance")).toLocaleString());
				$("#txtCurrencyFrom").val($('#cboAccountFrom option:selected').attr('data-currency')); 
				$("#cboAccountTo").find("option").show();
				$("#cboAccountTo").find("option[value='" + accno + "']").hide();
			}
		});
	}

	function calculateExchangeRate(){
		var exchange_rate = 0;
		var currency_from = $("#txtCurrencyFrom").val();
		var currency_to = $("#txtCurrencyTo").val();
		var amount_from = parseFloat($("#txtAmountFrom").val().replace(/,/g, ''));
		var amount_to = parseFloat($("#txtAmountTo").val().replace(/,/g, ''));

		if(currency_from!="" && currency_to!="" && amount_from>0 && amount_to>0 && currency_from!=currency_to){
			exchange_rate = (currency_from=="MMK")?(Math.round(((amount_from/amount_to) + Number.EPSILON) * 100) / 100):(Math.round(((amount_to/amount_from) + Number.EPSILON) * 100) / 100);
		}
		$("#txtExchangeRate").val(exchange_rate);
	}

	$("#btnSubmit").click(function(){ 
		$("#frmEntry").submit(); 
	});

	$("#frmEntry").on('submit',(function(e) {
		e.preventDefault();
		var formData = new FormData(this); 
		var fileInput = $('#input-image-hidden')[0];
		var file = fileInput.files[0];
		var gl_code_from = $("#cboAccountFrom option:selected").attr("data-glcode"); 
		var account_from = $("#cboAccountFrom").val(); 
		var gl_code_to = $("#cboAccountTo option:selected").attr("data-glcode"); 
		var account_to = $("#cboAccountTo").val(); 
		var date = $("#txtDatePicker").val();
		var amount_from = parseFloat($("#txtAmountFrom").val().replace(/,/g, ''));
		var amount_to = parseFloat($("#txtAmountTo").val().replace(/,/g, ''));
		var exchange_rate = parseFloat($("#txtExchangeRate").val().replace(/,/g, '')); 
		var balance_from = parseFloat($("#txtBalanceFrom").val().replace(/,/g, ''));
		var balance_to = parseFloat($("#txtBalanceTo").val().replace(/,/g, ''));

		if (!file){
			bootbox.alert("Please upload receipt.");
		}else if(account_from==""){
			bootbox.alert("Please choose account (from).");
		}else if(account_to==""){
			bootbox.alert("Please choose account (to).");
		}else if(balance_from<amount_from){
			bootbox.alert("Balance insufficient.");
		}else{
			$("#loading").css("display", "block");
			var objArr = [];
			objArr.push({ "gl_code_from": gl_code_from, "account_from": account_from, "gl_code_to": gl_code_to, "account_to": account_to, "date": date, "amount_from": amount_from, "amount_to": amount_to, "exchange_rate": exchange_rate });
			formData.append('objArr', JSON.stringify( objArr ));
			$.ajax({
				url: APP_URL + "api/finance/bank_account_transfer/create.php",
				type: "POST",
				processData: false,
				contentType: false,
				data: formData,
				success: function(data){
					$("#loading").css("display", "none");
					if(data.message=="created"){
						bootbox.alert("Successfully transfer.");
						$("#frmEntry")[0].reset();
						$("#txtDatePicker").val(customDate);
						$("#datePicker").datepicker("setDate", customDate);
						document.getElementById('previewing').src = APP_URL + "img/no_image.jpg";
						getAllBankAccount();
						getAllRows();
					}else{
						bootbox.alert("Error on server side.");
					}
				}
			});
		}
	}));

	function getAllRows(){
		var date = $("#txtDatePicker").val();
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/finance/bank_account_transfer/get_all_rows.php",
			type: "POST",
			data: JSON.stringify({ date: date })
		}).done(function(data) {	
			if(data.records.length>1){
            	$("#total_records").text(date + " (" + data.records.length + " records found)");
            }else{
            	$("#total_records").text(date + " (" + data.records.length + " record found)");
            }

			$.each(data.records, function(i, v) {	
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td style='width: 10px'>" + (i + 1) + "</td>") 
					.append("<td>" + v.account_from + "</td>")
					.append("<td>" + v.account_to + "</td>")
					.append("<td style='text-align:right; padding-right:20px;'>" + v.amount_from.toLocaleString() + "</td>")
					.append("<td style='text-align:right; padding-right:20px;'>" + v.amount_to.toLocaleString() + "</td>")
					.append("<td style='text-align:right; padding-right:20px;'>" + v.exchange_rate.toLocaleString() + "</td>")
					.append("<td style='text-align:center;'>" + ((v.upload_receipt)?"<img src='" + APP_URL + "api/finance/bank_account_transfer/upload/" + v.upload_receipt + "' style='width:60px; height:60px'/>":"") + "</td>")
				);
			});
		});
	}

	function HandleBrowseClick(input_image){
		var fileinput = document.getElementById(input_image);
		fileinput.click();
	}

	function isNumberDecimal(obj) {
        var val = obj.value;
        var re = /^([0-9]+[\.]?[0-9]?[0-9]?|[0-9]+)$/g;
        var re1 = /^([0-9]+[\.]?[0-9]?[0-9]?|[0-9]+)/g;
        if(!re.test(val)) {
        	val = re1.exec(val);
            if (val) {
                obj.value = val[0];
            } else {
                obj.value = 0;
            }
        }
    }
 </script>