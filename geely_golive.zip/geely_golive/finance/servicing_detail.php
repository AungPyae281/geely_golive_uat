<?php include '../header.php'; ?>
<?php
	$id = "";
	if(isset($_GET['id'])){
		if(!empty($_GET['id'])){
			$id = $_GET['id'];
		}
	}
?>
<style>
	.form-group{
		font-size: 13px !important;
	}

	.col-form-label {
		padding-top: calc(0.20rem + 1px);
		padding-bottom: calc(0.375rem + 1px);
		margin-bottom: 0;
		font-size: 13px;
		line-height: 1.2;
	}

	.form-control {
		display: block;
		width: 100%;
		height: calc(1.11rem + 11px);
		padding: 0.375rem 0.75rem;
		font-size: 0.9rem;
		font-weight: 400;
		line-height: 1.2;
		color: #495057;
		background-color: #ffffff;
		background-clip: padding-box;
		border: 1px solid #ced4da;
		border-radius: 0.25rem;
		box-shadow: inset 0 0 0 rgba(0, 0, 0, 0);
		transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
	}

	.card-header {
		background-color: transparent;
		border-bottom: 1px solid rgba(0, 0, 0, 0.125);
		position: relative;
		padding: 0.35rem 1.10rem;
		border-top-left-radius: 0.25rem;
		border-top-right-radius: 0.25rem;
	}

	.btn{
		font-size: 13px;
		line-height: 1.4;
	}

	.table th, .table td {
		padding: 0.40rem;
	}

	.badge{
		padding: 5px 12px;
		font-size: 11px;
		margin-right: 3px;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Service Detail</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title" style="padding-top: 5px;">Info</h3>
							<button type="button" class="btn btn-primary" style="height: 33px; line-height: 0px; font-weight: bold; font-size: 16px; min-width: 65px; background-color: #fff; color: #000; border-color: #007bff; float: right;" id="btnGoBack" onclick="goToServicingList();"><i class="fas fa-arrow-left" style="margin-right: 6px;"></i> Go Back</button>
						</div>
						<div class="card-body">	
							<div class="row">
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Center: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceCenter" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Registration No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceRegistrationNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Owner Name: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtOwnerName" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Owner Phone: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtOwnerPhone" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Appt. Contact Person: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtApptContactPerson" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Appt. Contact Phone: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtApptContactPhone" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Contact Person: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceContactPerson" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Contact Phone: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServiceContactPhone" value="" disabled>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Plate No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtPlateNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Model Name: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtModelName" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Vin No.: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtVinNo" value="" disabled>
										</div>
									</div>
									<div class="form-group row" style="display:none;">
										<label class="col-md-4 col-form-label" style="text-align: right;">Valid Warranty: </label>
										<div class="col-md-8" id="ValidWarranty"></div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Main Technician: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtMainTechnician" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Visit Type: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtVisitType" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Promotion: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtServicePromotion" value="" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">SA Name: </label>
										<div class="col-md-8">
											<input class="form-control" id="txtSA" value="" disabled>
										</div>
									</div>
								</div>
							</div> 

							<div class="card-body p-0" style="max-height:250px; overflow-y: auto; margin-top: 20px;">
								<table class="table table-bordered" id="myTableServiceItem">
									<thead>                  
										<tr> 
											<th style="width: 15%">Service Type</th>
											<th style="width: 15%">Package Name</th>
											<th style="width: 15%">Code</th>
											<th>Name</th>
											<th style="width: 15%">Waiting Time</th>
											<th style="width: 15%">Price</th>
											<th style="width: 10%">Warranty</th>
										</tr>
									</thead>
									<tbody></tbody>
								</table>
							</div>

							<div class="card-body p-0" style="max-height:192px; overflow-y: auto; margin-top: 40px; margin-bottom: 20px;">
								<table class="table table-bordered" id="myTableSparepart">
									<thead>                  
										<tr> 
											<th style="width: 12%;">Code</th>
											<th>Name</th>
											<th style="width: 10%">Warranty</th> 
											<th style="width: 15%">Price</th>
											<th style="width: 9%">Quantity</th>
											<th style="width: 15%">Amount</th>
										</tr>
									</thead>
									<tbody></tbody>
								</table>
							</div>

							<div class="row" style="padding-top:9px;"> 
								<div class="col-md-4"></div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Total Waiting Time: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtTotalWaitingTime" value="" disabled>
										</div>
									</div>
									<div class="form-group row" style="margin-bottom: 3px !important;">
										<label class="col-md-4 col-form-label" style="text-align: right;">Remark: </label>
										<div class="col-md-8">
											<textarea class="form-control" id="txtServiceRemark" rows="2" disabled></textarea>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right; padding-top: 7px;">Test Drive Agree:</label>
										<div class="col-md-8 icheck-success d-inline">
											<input id="chkTestDriveAgree" type="checkbox" disabled>
											<label for="chkTestDriveAgree"></label>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Total Amount: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtTotalAmount" value="0" style="text-align:right;" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Discount: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtDiscount" value="0" style="text-align:right;" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Net Amount: </label>
										<div class="col-md-8">
											<input type="text" class="form-control" id="txtNetAmount" value="0" style="text-align:right;" disabled>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div> 

				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
    var id = '<?= $id ?>';

	$(function() {
		$("body").addClass("sidebar-collapse"); 
		getOneService();
	}); 

	function getOneService(){
		$("#ValidWarranty").empty();
		$.ajax({
			url: APP_URL + "api/service/service/get_one_service.php",
			type: "POST",
			data: JSON.stringify({ id: id })
		}).done(function(data) {
			$("#txtServiceCenter").val(data.service_center);
			$("#txtServiceRegistrationNo").val(data.registration_no);
			$("#txtOwnerName").val(data.owner_name);
			$("#txtOwnerPhone").val(data.owner_phone);
			$("#txtApptContactPerson").val(data.appt_contact_person);
			$("#txtApptContactPhone").val(data.appt_contact_phone);
			$("#txtServiceContactPerson").val(data.contact_person);
			$("#txtServiceContactPhone").val(data.contact_phone);

			$("#txtPlateNo").val(data.plate_no);
			$("#txtModelName").val(data.model);
			$("#txtVinNo").val(data.vin_no);
			$("#txtMainTechnician").val(data.main_technician_name);
			$("#txtVisitType").val(data.visit_type);
			$("#txtServicePromotion").val(data.promotion);
			$("#txtSA").val(data.sa_name);

			if(data.valid_warranty.length>0){
				$("#ValidWarranty").parent().css("display", "");
				$.each(data.valid_warranty, function(i, v){
					$("#ValidWarranty").append('<span class="badge bg-primary">' + v + '</span>');
				});
			}else{
				$("#ValidWarranty").parent().css("display", "none");
			}

			var package_id = 0;
			var x = 1;
			$.each(data.service_items, function(i, v) {
				if(v.service_type=="Package"){
					$("#myTableServiceItem").find("tbody")
					.append($('<tr class="svpk' + v.package_id + '" data-service-type="' + v.service_type + '" data-package-name="' + v.package_name + '" data-item-code="' + v.item_code + '" data-item-name="' + v.item_name + '" data-item-wt="' + v.item_wt + '" data-item-price="0" data-package-price="' + v.package_price + '" data-technician-id="' + v.technician_id + '" data-bay-no="' + v.bay_no + '" data-start-time="' + v.start_time + '" data-end-time="' + v.end_time + '" data-warranty="' + v.warranty + '">')
						.append((package_id!=v.package_id)?("<td rowspan='' class='package" + v.package_id + "' style='vertical-align: middle;'>" + v.service_type + "</td>"):"")
						.append((package_id!=v.package_id)?("<td rowspan='' class='package" + v.package_id + "' style='vertical-align: middle;'>" + v.package_name + "</td>"):"")
						.append("<td style='padding: 0.40rem !important;'>" + v.item_code + "</td>")
						.append("<td style='padding: 0.40rem !important;'>" + v.item_name + "</td>")
						.append("<td style='padding: 0.40rem !important;'>" + v.item_wt + "</td>")
						.append((package_id!=v.package_id)?("<td rowspan='' class='package" + v.package_id + "' style='text-align:right; padding-right: 20px; vertical-align: middle;'>" + v.package_price + "</td>"):"")
						.append("<td>" + ((v.warranty==1)?"Yes":"No") + "</td>")
					);
					if(v.package_id==package_id){
						++x;
						$("#myTableServiceItem .package" + package_id).attr("rowspan", x);
					}else{
						x = 1;
					}
					if(v.technician_id!=0){
						$(".btn" + v.package_id).remove();
					}
					package_id = v.package_id;
				}else{
					$("#myTableServiceItem").find("tbody")
					.append($('<tr class="svpk' + v.package_id + '" data-service-type="' + v.service_type + '" data-package-name="' + v.package_name + '" data-item-code="' + v.item_code + '" data-item-name="' + v.item_name + '" data-item-wt="' + v.item_wt + '" data-item-price="' + v.item_price + '" data-package-price="0" data-technician-id="' + v.technician_id + '" data-bay-no="' + v.bay_no + '" data-start-time="' + v.start_time + '" data-end-time="' + v.end_time + '" data-warranty="' + v.warranty + '">')
						.append("<td>" + v.service_type + "</td>")
						.append("<td data-package-id=''></td>")
						.append("<td>" + v.item_code + "</td>")
						.append("<td>" + v.item_name + "</td>")
						.append("<td>" + v.item_wt + "</td>")
						.append("<td style='text-align:right; padding-right: 20px;'>" + v.item_price + "</td>")
						.append("<td>" + ((v.warranty==1)?"Yes":"No") + "</td>")
					);
				}
			});

			$.each(data.spareparts, function(i, v) { 
				$("#myTableSparepart").find("tbody")
				.append($('<tr>')
					.append("<td>" + v.code + "</td>")
					.append("<td>" + v.name + "</td>")
					.append("<td data-warranty='" + v.warranty + "'>" + ((v.warranty==1)?"Yes":"No") + "</td>") 
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.price + "</td>")
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.qty + "</td>")
					.append("<td style='text-align:right; padding-right: 20px;'>" + v.amount + "</td>") 
				);
			});

			$("#txtTotalWaitingTime").val(data.total_waiting_time);	
			$("#txtServiceRemark").val(data.service_remark);
			$("#chkTestDriveAgree").prop("checked", data.test_drive_agree); 
			$("#txtDiscount").val(data.discount); 
			calculate();
		});
	}

	function calculate(){
		var discount = (($("#txtDiscount").val()!="" && $("#txtDiscount").val()!=null)?parseInt($("#txtDiscount").val().replace(/,/g, '')):0);
		var total_service_item = total_sparepart = total_amount = net_amount = 0;

		$("#myTableServiceItem tbody tr").each(function (i,v){
			if($(this).find("td").length>4){
				total_service_item += parseInt($(this).find("td").eq(5).text().replace(/,/g, ''));
			}
		});
		$("#txtServiceItemTotalAmount").val(total_service_item.toLocaleString());

		$("#myTableSparepart tbody tr").each(function (i,v){
			total_sparepart += parseInt($(this).find("td").eq(5).text().replace(/,/g, ''));
		});
		$("#txtSparepartTotalAmount").val(total_sparepart.toLocaleString());

		total_amount = (total_service_item + total_sparepart);
		net_amount = (total_amount - discount);

		$("#txtTotalAmount").val(total_amount.toLocaleString());
		$("#txtNetAmount").val(net_amount.toLocaleString());
	}  

	function goToServicingList(){
		document.location = APP_URL + "finance/servicing_list.php";
	}
</script>	
