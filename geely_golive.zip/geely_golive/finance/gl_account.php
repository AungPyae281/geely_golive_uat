<?php include '../header.php'; ?>
<style>
	#myTable tbody td{
		padding-top: 5px;
		padding-bottom: 5px;
	}
	select{
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>G/L Account - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Type: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboType"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Category: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboCategory"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">G/L Code: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtGLCode">
											</div>
										</div>
									</div> 
									<div class="col-md-6"> 
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Name: </label>
											<div class="col-md-8">
												<textarea class="form-control" id="txtName" rows="2"></textarea>
											</div>
										</div>
										<div class="form-group row" id="AdvancePanel">
											<label class="col-md-4 col-form-label" style="text-align: right;">Min: </label>
											<div class="col-md-3">
												<input type="text" class="form-control" id="txtMinAmount" value="0" style="text-align:right;" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);">
											</div>
											<label class="col-md-2 col-form-label" style="text-align: right;">Max: </label>
											<div class="col-md-3">
												<input type="text" class="form-control" id="txtMaxAmount" value="0" style="text-align:right;" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);">
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-8"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" onclick="create()">Add</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"> </span></h3>
						</div>
						<div class="card-body p-0" style="max-height: 450px; overflow: auto;">
							<table class="table table-striped table-fixed table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%">No.</th>
										<th style="width: 18%;">Type</th>
										<th style="width: 18%;">Category</th>
										<th style="width: 13%;">G/L Code</th>
										<th>Name</th>
										<th style="width: 10%;">Min Amount</th>
										<th style="width: 10%;">Max Amount</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	$(function() {
		$("body").addClass("sidebar-collapse");	
		getAllType();
		getCategoriesByType();
		getAllRows();
	});

	$("#cboType").change(function(){
		getCategoriesByType();
		getAllRows();
	});

	$("#cboCategory").change(function(){
		getAllRows();
	});

	function getAllType(){
		$("#cboType").find("option").remove();
		$("#cboType").append("<option value = ''></option>");

		$.ajax({
			url: APP_URL + "api/finance/gl_type/get_all_rows.php"
		}).done(function(data) {	
			$.each(data.records, function(i, v) {	
				$("#cboType").append("<option value='" + v.type + "'>" + v.type + "</option>");
			});
		});
	}

	function getCategoriesByType(){
		var type = $("#cboType").val();
		$("#cboCategory").find("option").remove();
		$("#cboCategory").append("<option value = ''></option>");

		$.ajax({
			url: APP_URL + "api/finance/gl_category/get_categories_by_type.php",
			type: "POST",
			data: JSON.stringify({ type: type })
		}).done(function(data) {	
			$.each(data.records, function(i, v) {	
				$("#cboCategory").append("<option value='" + v.category + "'>" + v.category + "</option>");
			});
		});
	}

	function create(){	
		var type = $("#cboType").val();
		var category = $("#cboCategory").val();
		var gl_code = $("#txtGLCode").val();
		var name = $("#txtName").val();
		var min_amount = parseInt($("#txtMinAmount").val().replace(/,/g, ''));
		var max_amount = parseInt($("#txtMaxAmount").val().replace(/,/g, ''));

		if(type==""){
			bootbox.alert("Please choose type.");
		}else if(category==""){
			bootbox.alert("Please choose category.");
		}else if(gl_code==""){
			bootbox.alert("Please fill G/L code.");
		}else if(name==""){
			bootbox.alert("Please fill name.");
		}else{
			$("#loading").css("display","block");
			$.ajax({
				url: APP_URL + "api/finance/gl_account/create.php",
				type: "POST",
				data: JSON.stringify({ type: type, category: category, gl_code: gl_code, name: name, min_amount: min_amount, max_amount: max_amount }),
			}).done(function(data){
				$("#loading").css("display","none");
				if(data.message=="created"){
					$("#txtGLCode").val("");
					$("#txtName").val("");
					$("#txtMinAmount").val(0);
					$("#txtMaxAmount").val(0);
					bootbox.alert("Successfully Added.");
					getAllRows();
				}else if(data.message=="duplicate"){
					bootbox.alert("Not allow duplicate data.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function getAllRows(){
		var type = $("#cboType").val();
		var category = $("#cboCategory").val();
		$("#myTable").find("tbody").find("tr").remove();

		$.ajax({
			url: APP_URL + "api/finance/gl_account/get_all_rows.php",
			type: "POST",
			data: JSON.stringify({ type: type, category: category })
		}).done(function(data) {	
			if(data.records.length>1){
            	$("#total_records").text(" - " + data.records.length + " records found.");
            }else{
            	$("#total_records").text(" - " + data.records.length + " record found.");
            }
			$.each(data.records, function(i, v) {	
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td style='width: 10px'>" + (i + 1) + "</td>")
					.append("<td>" + v.type + "</td>")
					.append("<td>" + v.category + "</td>")
					.append("<td>" + v.gl_code + "</td>")
					.append("<td>" + v.name + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + ((v.min_amount>0)?v.min_amount.toLocaleString():"") + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + ((v.max_amount>0)?v.max_amount.toLocaleString():"") + "</td>")
				);
			});
		});
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function AddComma(obj) {
        var amount = $(obj).val().replace(/,/g, '');
		$(obj).val(parseInt(amount).toLocaleString());
    }
</script>	
