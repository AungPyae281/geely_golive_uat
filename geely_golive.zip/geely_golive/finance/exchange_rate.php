<?php include '../header.php'; ?>
<style>
	select {
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Exchange Rate - Entry</h1>
				</div>
				<div class="col-md-6">
				</div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-5">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-12">
										<div class="form-group row">	
											<label class="col-md-3 col-form-label" style="text-align: right;">Date: </label>
											<div class="col-md-8">
												<div class="input-group input-append date" id="datePicker" data-date="2020-02-07" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
												</div>
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<label class="col-md-3 col-form-label" style="text-align: right;">Currency/Rate: </label>
											<div class="col-md-4">
												<select class="form-control" id="cboCurrency"></select>
											</div>
											<div class="col-md-4">
												<input type="text" class="form-control" id="txtRate" maxlength="15" style="text-align: right;" placeholder="MMK">
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<div class="col-md-7"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" onclick="create()">Add</button>
											</div>
											<div class="col-md-1"></div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="col-md-7">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"> </span></h3>
						</div>
						<div class="card-body p-0" style="max-height: 450px; overflow: auto;">
							<table class="table table-striped table-fixed table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%">No.</th>
										<th>Date</th>
										<th>Currency</th>
										<th>Rate</th>
										<th>Entry Date/Time</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date", customDate);
	$("#txtDatePicker").val(customDate);

	$(function() {
		$("body").addClass("sidebar-collapse");
		$('#datePicker').datepicker();  
		getAllCurrency();
		getAllRows();
	});

	$("#txtRate").on("input", function(){
		isNumberDecimal(this);
	});

	function getAllCurrency(){
        $("#cboCurrency").find("option").remove();
        $.ajax({
            url: APP_URL + "api/finance/currency/get_all_rows.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
            	if(v.currency!="MMK"){
                	$("#cboCurrency").append("<option value='" + v.currency + "'>" + v.currency + "</option>");
            	}
            });
        });
    }

    function create(){	
		var date = $("#txtDatePicker").val();
		var currency = $("#cboCurrency").val();
		var rate = ($("#txtRate").val()!="")?parseFloat($("#txtRate").val().replace(/,/g, '')):0;

		if(rate==0){
			bootbox.alert("Please fill rate.");
		}else{
			$("#loading").css("display","block");
			$.ajax({
				url: APP_URL + "api/finance/exchange_rate/create.php",
				type: "POST",
				data: JSON.stringify({ date: date, currency: currency, rate: rate }),
			}).done(function(data){
				$("#loading").css("display","none");
				if(data.message=="created"){
					$("#txtRate").val("");
					bootbox.alert("Successfully Added.");
					getAllRows();
				}else if(data.message=="duplicate"){
					bootbox.alert("Not allow duplicate data.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function getAllRows(){
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/finance/exchange_rate/get_all_rows.php"
		}).done(function(data) {	
			if(data.records.length>1){
				$("#total_records").text(" - " + data.records.length + " records found.");
			}else{
				$("#total_records").text(" - " + data.records.length + " record found.");
			}
			
			$.each(data.records, function(i, v) {	
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.date + "</td>")
					.append("<td>" + v.currency + "</td>")
					.append("<td style='text-align: right; padding-right: 20px;'>" + v.rate.toLocaleString() + "</td>")
					.append("<td>" + v.entry_date_time + "</td>")
				);
			});
		});
	}

	function isNumberDecimal(obj) {
        var val = obj.value;
        var re = /^([0-9]+[\.]?[0-9]?[0-9]?|[0-9]+)$/g;
        var re1 = /^([0-9]+[\.]?[0-9]?[0-9]?|[0-9]+)/g;
        if(!re.test(val)) {
        	val = re1.exec(val);
            if (val) {
                obj.value = val[0];
            } else {
                obj.value = "";
            }
        }
    } 
</script>	
