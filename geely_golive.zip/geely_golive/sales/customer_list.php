<?php include '../header.php'; ?>  

<style>	
	.tdDisplayNone{
		display: none;
	}
	#myTable td:nth-child(3) {
		text-decoration: underline;
		color: blue;
		cursor: pointer;
    } 
</style>

<div class="content-wrapper">
    <section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Leads List</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                	<div class="card card-outline card-primary">
                		<div class="card-header"> 
                			<?php if($_SESSION["position"]=="Sales Executive"){ ?>
							<button type="button" class="btn btn-success btn-sm" data-id="1" onclick="goToNewLeads();" style="font-size: 17px; float: right; padding-left: 15px; padding-right: 15px;"><i class="fas fa-user-plus"></i> New Leads</button>
							<?php } ?>
						</div>
						<div class="card-body">
							<table id="myTable" class="display nowrap">
								<thead>
									<tr>
										<th>Registration No.</th>	
										<th>Sales Executive</th>	
										<th>Customer Name</th>
										<th>Mobile No.</th> 
										<th>Sales Status</th>
										<th></th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
                	</div>
                </div>  

            </div>
        </div>
    </section>
</div> 
<?php include '../footer.php'; ?> 
<script> 
	var position = '<?=$_SESSION["position"]?>';

	$(function() { 
		$("body").addClass("sidebar-collapse");	 
		fillGrid();
	});

	function fillGrid(){ 
		table = $('#myTable').DataTable({
			"scrollX": true,
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"order": [[ 0, "desc" ]],
			"columnDefs": [	
				{
					'targets': 5,
					'searchable': false,
					'orderable': false,	
					'render': function (data){	 
						var id = data.split("|")[0];
						var case_close = data.split("|")[1];
						return '<td><button type="button" class="btn btn-primary btn-sm btnID" onclick="goToEdit(' + id + ');" style="font-size: 21px; min-width: 44px;" title="Customer Edit" data-id="' + id + '" ' + ((case_close=="1")?"disabled":"") + '><i class="fas fa-edit"></i></button> <button type="button" class="btn btn-primary btn-sm" onclick="goToTestDriveBooking(' + id + ', this);" style="font-size: 21px; min-width: 44px;cursor:not-allowed;" title="Test Drive Booking" ' + ((case_close=="1")?"disabled":"") + ' disabled><i class="fas fa-car"></i></button> <button type="button" class="btn btn-primary btn-sm" data-id="' + id + '" onclick="goToQuotation(' + id + ', this);" style="font-size: 21px; min-width: 44px;cursor:not-allowed;" title="Quotation" ' + ((case_close=="1")?"disabled":"") + ' disabled><i class="fas fa-clipboard-list"></i></button> <button type="button" class="btn btn-primary btn-sm" data-id="' + id + '" onclick="goToFollowUp(' + id + ', this);" style="font-size: 21px; min-width: 44px; color: #fff;cursor:not-allowed;" title="Follow Up" disabled><i class="fas fa-phone"></i></button> <button type="button" class="btn btn-primary btn-sm" data-id="' + id + '" onclick="goToOrder(' + id + ', this);" style="font-size: 21px; min-width: 44px;" title="Order" ' + ((case_close=="1")?"disabled":"") + '><i class="fas fa-dollar-sign"></i></button> <button type="button" class="btn btn-primary btn-sm" data-id="' + id + '" onclick="goToCaseClose(' + id + ', this);" style="font-size: 21px; min-width: 44px;cursor:not-allowed;' + ((case_close=="1")?"display: none;":"") + '" title="Case Close" disabled><i class="fas fa-share"></i></button> <button type="button" class="btn btn-success btn-sm" data-id="' + id + '" onclick="goToCaseClose(' + id + ', this);" style="font-size: 21px; min-width: 44px;cursor:not-allowed;' + ((case_close=="0")?"display: none;":"") + '" title="Case Open"><i class="fas fa-share fa-flip-horizontal" disabled></i></button> <button type="button" class="btn btn-primary btn-sm" data-id="' + id + '" onclick="goToLostSales(' + id + ', this);" style="font-size: 21px; min-width: 44px;cursor:not-allowed;" title="Lost Sales" disabled><i class="fas fa-arrow-down"></i></button></td>';	
					}
				},
				{
					'targets': [1],
					"className": ((position=="Sales Executive")?'tdDisplayNone':'')
				}
			],
			"ajax": APP_URL + "api/sales/customer/get_all_customer_list.php"
		});	
	}

	$('#myTable').on('click', 'tbody td:nth-child(3)', function(e){
		document.location = APP_URL + "sales/customer.php?act=detail&rid=" + $(this).parent().find(".btnID").attr("data-id");
	});

	function goToEdit(id){
		document.location = APP_URL + "sales/customer.php?act=edit&cid=" + id;
	}

	// function goToTestDriveBooking(id, obj){
	// 	document.location = APP_URL + "sales/test_drive_booking.php?act=entry&cid=" + id;
	// } 

	function goToOrder(id, obj){
		document.location = APP_URL + "sales/order.php?act=entry&cid=" + id;
	}	 
 
	function goToNewLeads(){
		document.location = APP_URL + "sales/customer.php";
	} 
</script>