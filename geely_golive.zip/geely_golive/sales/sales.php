<?php include '../header.php'; ?>
<?php
    $oc_no = "";
    if(isset($_GET['oc_no'])){
        if(!empty($_GET['oc_no'])){
            $oc_no = $_GET['oc_no'];
        }
    }
?>
<style>
    .card{
        margin-bottom: 10px !important;
    }
    .card-header{
        padding: 8px 2px 8px 15px;
    }
    .card-body{
        padding: 15px 20px 5px 20px;
    }
    .nav-tabs{
        display: inline-flex;
    }
    .form-group{
        margin-bottom: 5px !important;
    }
    .form-control{
        border: 1px solid #d4d6d8ba !important;
    }
    .form-control:disabled, .form-control[readonly]{
        background-color: #e6e8ea9e !important;
    }
    input, textarea{
        font-size: 14px !important;
    }

    .breadcrumb{
        background: #fff;
    }
    .breadcrumb.wizard {
        margin: 0px !important;
        padding: 0px; 
        list-style: none;
        overflow: hidden;
        margin-top: 20px;
        font-size: 14px;
        height: 50px;
    }
    .breadcrumb.wizard>li+li:before {
        padding: 0;
    }
    .breadcrumb.wizard li {
        float: left;
        background: #eee;
        height: 50px;
    } 
    .breadcrumb.wizard li.current a {
        color: #fff !important; 
        background: brown;
        background: hsl(203.9, 64.2%, 48.2%) !important;
    }
    .breadcrumb.wizard li.completed a {
        color: #fff; 
        background: brown;
        background: hsl(204, 65.6%, 76.1%);
    } 
    .breadcrumb.wizard li.current a:after {
        border-left: 30px solid hsl(203.9, 64.2%, 48.2%) !important;
    }
    .breadcrumb.wizard li.completed a:after {
        border-left: 30px solid hsl(204, 65.6%, 76.1%);
    }

    .breadcrumb.wizard li a {
        height: 50px;
        line-height: 28px;
        color: #000;
        text-decoration: none;
        padding: 10px 0 10px 45px;
        position: relative;
        display: block;
        float: left;
    }
    .breadcrumb.wizard li a:after {
        content: " ";
        display: block;
        width: 0;
        height: 0;
        border-top: 50px solid transparent;
        border-bottom: 50px solid transparent;
        border-left: 30px solid #eee;
        position: absolute;
        top: 50%;
        margin-top: -50px;
        left: 100%;
        z-index: 2;
    }
    .breadcrumb.wizard li a:before {
        content: " ";
        display: block;
        width: 0;
        height: 0;
        border-top: 50px solid transparent;
        border-bottom: 50px solid transparent;
        border-left: 30px solid white;
        position: absolute;
        top: 50%;
        margin-top: -50px;
        margin-left: 1px;
        left: 100%;
        z-index: 1;
    }
    .breadcrumb.wizard li:first-child a {
        padding-left: 15px;
    } 
    .custom-disabled{
        color: #9091916b !important;
        cursor: no-drop !important;
    }
    .branch{
        padding-top: 35px;
    }
    .box-shadow{
        box-shadow: rgba(0, 0, 0, 0.25) 0px 0.0625em 0.0625em, rgba(0, 0, 0, 0.25) 0px 0.125em 0.5em, rgba(255, 255, 255, 0.1) 0px 0px 0px 1px inset;
    }
    #progress{
        padding-right: 47px;
    }
    .dcl-filename{
        height: 35px;
        overflow: auto;
        font-size: 13px;
    }
    .input-group-addon{
        height: 36px !important;
    } 
    .checkbox-inline .toggle{
        margin-left: 0px !important;
        width: 110px !important;
    }
    .toggle-on, .toggle-off{
        line-height: 19px !important;
    }
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
    <section class="content-header">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                </div>
            </div>
        </div>
    </section>
    <section class="content"> 
    	<div class="container-fluid">
    		<div class="row">
                <div class="col-md-12" id="SummaryPanel">
                    <div class="card card-outline card-primary">
                        <div class="card-header">
                            <h3 class="card-title" id="txtProcessing"></h3>
                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">OC No.:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtOCNo" disabled value="<?=$oc_no?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-md-4 col-form-label" style="text-align: right;">Sales Center:</label>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="txtSalesCenter" disabled>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card card-outline card-outline-tabs collapsed-card">
                        <div class="card-header p-0 border-bottom-0">
                            <ul class="nav nav-tabs" id="custom-tabs-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="custom-tabs-customer-tab" data-toggle="pill" href="#custom-tabs-customer" role="tab" aria-controls="custom-tabs-customer" aria-selected="true">Customer Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-vehicle-tab" data-toggle="pill" href="#custom-tabs-vehicle" role="tab" aria-controls="custom-tabs-vehicle" aria-selected="false">Vehicle Info</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-payment-tab" data-toggle="pill" href="#custom-tabs-payment" role="tab" aria-controls="custom-tabs-payment" aria-selected="false">Payment Info</a>
                                </li>
                            </ul>
                            <div class="card-tools" style="padding-top: 10px;">
                                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-plus"></i></button>
                                <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-remove"></i></button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-tabContent">
                                <div class="tab-pane fade active show" id="custom-tabs-customer" role="tabpanel" aria-labelledby="custom-tabs-customer-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerName" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">NRC No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerNRCNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerMobileNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtCustomerTownship" disabled>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-vehicle" role="tabpanel" aria-labelledby="custom-tabs-vehicle-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Vin No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtVinNo" disabled>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Engine No.:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtEngineNo" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Particular:</label>
                                                <div class="col-md-8">
                                                    <textarea class="form-control" id="txtParticular" rows="4" style="height: 100px;" disabled></textarea>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="custom-tabs-payment" role="tabpanel" aria-labelledby="custom-tabs-payment-tab">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPayment" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Total Payment (%):</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtTotalPaymentPercent" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Deposit Amount:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtDeposit" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-md-4 col-form-label" style="text-align: right;">Remaining Balance:</label>
                                                <div class="col-md-8">
                                                    <input type="text" class="form-control" id="txtRemainingBalance" disabled style="text-align:right;">
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card card-outline">
                        <div class="card-header" style="padding: 0px;"> 
                            <ul class="breadcrumb wizard myStepper">
                                <li class="completed" id="DocumentCollect"><a href="javascript:void(0);">Document Collect</a></li>
                                <li id="Handover"><a href="javascript:void(0);">Handover</a></li>
                                <li id="OwnerBookHandover"><a href="javascript:void(0);">Owner Book Handover</a></li>
                            </ul>
                        </div>

                        <div class="card-body branch" data-id="DocumentCollect">
                            <div class="col-md-12" id="myDCLFile">
                                <form role="form" id="frmDCLEntry">
                                    <div class="card-body" style="background-color: #fff;">
                                        <p style="font-size:16px; text-align:center; margin:10px 0px;">
                                        Please upload documents only in 'pdf' format.
                                        </p>
                                        <h3 style="text-align: center; font-size:23px;">
                                        Document Collect
                                        </h3><br>
                                        <div class="row">
                                            <div class="col-md-10" id="mainDCLPanel"></div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="card-body branch" data-id="Handover" style="display:none;">
                            <form id="frmHOEntry">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Payment Percent:</label>
                                            <div class="col-md-6">
                                                <input type="text" class="form-control" id="txtHOPaymentPercent" disabled style="text-align: right;">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Date:</label>
                                            <div class="col-md-6">
                                                <div class="input-group input-append date" id="datePickerHO" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell; height: 31px !important;">
                                                            <i class="far fa-calendar-alt"></i>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control float-right ho-info" id="txtDatePickerHO" value="1982-06-15" readonly>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right; padding-top: 6px;"></label>
                                            <div class="col-md-8">
                                                <button type="button" class="btn btn-info file-upload" id="btnHOSIFileUpload" onclick="goToDocumentCollect(this);" style="width: 120px;">Sales Invoice</button>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right; padding-top: 6px;"></label>
                                            <div class="col-md-8">
                                                <button type="button" class="btn btn-info file-upload" id="btnHOSCFileUpload" onclick="goToDocumentCollect(this);" style="width: 120px;">Sales Contract</button>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right; padding-top: 6px;"></label>
                                            <div class="col-md-8">
                                                <button type="button" class="btn btn-info file-upload" id="btnHODNFileUpload" onclick="goToDocumentCollect(this);" style="width: 120px;">Delivery Note</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Vehicle Photo:</label>
                                            <div class="col-md-8">
                                                <input style="display:none" name="file-ho" id="input-handover-image-hidden" onchange="document.getElementById('handover-previewing').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
                                                <img id="handover-previewing" name="handover-previewing" src="<?=$app_url;?>img/no_image.jpg" style="height:170px; width:auto;cursor:pointer;border: 2px solid #a2a2a2;" onclick="HandleBrowseClick(this)" title="Click to Change the Photo.">
                                            </div>
                                        </div> 
                                    </div>
                                </div> 

                                <div class="row" id="DeliveryNotePanel" style="margin-top: 30px;">
                                    <h5><span style="font-weight: bold;margin-left:10px;">Delivery Note</span></h5>
                                    <legend></legend>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Date:</label>
                                            <div class="col-md-8">  
                                                <div class="input-group input-append date" id="datePickerDN" data-date="2022-09-01" data-date-format="yyyy-mm-dd">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell; height: 31px !important;">
                                                            <i class="far fa-calendar-alt"></i>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control float-right dc-info" id="txtDatePickerDN" value="1982-06-15" readonly>
                                                </div>
                                            </div>
                                        </div>  
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Delivery To:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtDNDeliveryTo"> 
                                            </div>
                                        </div>  
                                    </div> 
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Phone No.:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtDNPhoneNo"> 
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Address:</label>
                                            <div class="col-md-8">
                                                <textarea class="form-control" id="txtDNAddress" rows="2"></textarea>
                                            </div>
                                        </div>
                                    </div> 
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Model Name:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtDNModel" disabled> 
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Grade:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtDNGrade" disabled> 
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Engine:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtDNEngine" disabled> 
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Colour (Ext/Int):</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtDNColourExtInt" disabled> 
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Vin No.:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtDNVinNo" disabled> 
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Registration No.:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtDNRegistrationNo"> 
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Invoice No.:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtDNInvoiceNo"> 
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Sales Person:</label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="txtDNSalesPerson" disabled> 
                                            </div>
                                        </div>
                                        <div class="form-group row" style="text-align: right;">
                                            <div class="col-md-8"></div>
                                            <div class="col-md-4">
                                                <button type="button" class="btn btn-success" id="btnHOSubmit">Submit</button>
                                            </div>
                                        </div>
                                        <!-- <div class="form-group row" style="text-align: right;">
                                            <label class="col-md-8 col-form-label"></label>
                                            <div class="col-md-4">
                                                <button type="button" class="btn btn-primary" id="btnDNGenerate" onclick="generateDeliveryNote();">Generate Delivery Note</button>
                                            </div>
                                        </div> -->
                                    </div>
                                </div> 
                            </form>
                        </div>

                        <div class="card-body branch" data-id="OwnerBookHandover" style="display:none;">
                            <form id="frmOBHOEntry">
                                <div class="row" id="OBHOPaymentFull">
                                    <div class="col-md-6">
                                        <input type="hidden" id="txtPlateNo">
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Payment Percent:</label>
                                            <div class="col-md-5">
                                                <input type="text" class="form-control txtOBHOPaymentPercent" disabled value="0" style="text-align: right;">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Date:</label>
                                            <div class="col-md-5">
                                                <div class="input-group input-append date" id="datePickerOBHO" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-addon input-group-text" style="width: 40px; display: table-cell; height: 31px !important;">
                                                            <i class="far fa-calendar-alt"></i>
                                                        </span>
                                                    </div>
                                                    <input type="text" class="form-control float-right obho-info" id="txtDatePickerOBHO" value="1982-06-15" readonly>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6"> 
                                        <div class="form-group row" id="OBHOPhoto">
                                            <label class="col-md-4 col-form-label" style="text-align: right;">Photo:</label>
                                            <div class="col-md-8">
                                                <input style="display:none" name="file-obho" id="input-obho-image-hidden" onchange="document.getElementById('obho-previewing').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
                                                <img id="obho-previewing" name="obho-previewing" src="<?=$app_url;?>img/no_image.jpg" style="height:170px; width:auto;cursor:pointer;border: 2px solid #a2a2a2;" onclick="HandleBrowseClick(this)" title="Click to Change the Photo.">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-md-4"></div>
                                            <div class="col-md-4">
                                                <button type="button" class="btn btn-block btn-success" id="btnOBHOSubmit" style="display:none;">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                            </form>
                        </div>

                    </div>
                </div>

            </div>
    	</div>
    </section> 
</div>
<?php include '../footer.php'; ?>
<script>
    var oc_no = "<?= $oc_no ?>";
    var statusArr = ["Handover", "Owner Book Handover"];
    var arrDCList = ["Sale Invoice", "Sale Contract", "Delivery Note", "Owner Book"];

    var d = new Date();
    var mm = (d.getMonth("MM")+1);
    var dd = d.getDate();
    var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

	$(function(){
        $("body").addClass("sidebar-collapse");  
        checkStatus();

        // Handover
        $('#datePickerHO').attr("data-date", customDate);
        $("#txtDatePickerHO").val(customDate);
        $('#datePickerHO').datepicker();

        // Delivery Note
        $('#datePickerDN').attr("data-date", customDate);
        $("#txtDatePickerDN").val(customDate);
        $('#datePickerDN').datepicker();
        // Delivery Note

        // Handover

        // Owner Book Handover
        $('#datePickerOBHO').attr("data-date", customDate);
        $("#txtDatePickerOBHO").val(customDate);
        $('#datePickerOBHO').datepicker();
        // Owner Book Handover
    });

    $(document).on('click', ".myStepper .clickable", function(){
        $(".myStepper li").removeClass("current");
        $(this).addClass("current");
        $(".branch").css("display", "none");
        $("[data-id='" + $(this).attr("id") + "']").css("display", "");
        if($(this).find("a").text()=="Purchase Permit") checkPurchasePermit();
    });

    function HandleBrowseClick(obj){
        var inputID = $(obj).parent().find("input[type='file']").attr("id");
        var file = document.getElementById(inputID);
        file.click();
    }

    // Check Status
    function checkStatus(){
        $(".myStepper li").removeClass("current");
        $(".myStepper li:not(:first-child)").removeClass("completed");
        $(".myStepper li").removeClass("clickable");
        $(".myStepper li").addClass("clickable");
        $(".myStepper a").removeClass("custom-disabled");
        $(".branch").css("display", "none");

        $.ajax({
            url: APP_URL + "api/sales/sales/check_status.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {  
            var status = data.status.replace(/\s+/g, "");
            var processing = data.processing.replace(/\s+/g, "");
            
            if(processing=="Handover" || processing=="OwnerBookHandover"){
                // Processing
                $("#" + processing).removeClass("completed");
                $("#" + processing).addClass("current");
                $("[data-id='" + processing + "']").css("display", "");
                // Processing

                // Disabled 
                var completedStart = true;
                var disabledStart = false;
                $.each(statusArr, function(i, v){
                    var val = v.replace(/\s+/g, "");
                    if(val == status){
                        $("#" + val).addClass("completed");
                        completedStart = false;
                    }else if(completedStart){
                        $("#" + val).addClass("completed");
                    }

                    if(disabledStart){
                        $("#" + val).removeClass("clickable");
                        $("#" + val + " a").addClass("custom-disabled");
                    }
                    if(val == processing){
                        disabledStart = true;
                    }
                });
                // Disabled
            }else{
                $(".myStepper li:first-child").addClass("current");
                $("[data-id='DocumentCollect']").css("display", "");
            }
            getSalesDetail();
            appendDCList();
        });
    }
    // Check Status

    function getSalesDetail(){
        $.ajax({
            url: APP_URL + "api/sales/sales/get_sales_detail.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {    
            $("#txtPlateNo").val(data.plate_no);
            $("#txtProcessing").text(data.processing);
            $("#txtSalesCenter").val(data.sales_center);

            $("#txtCustomerName").val(data.c_name);
            $("#txtCustomerNRCNo").val(data.c_nrc_no);
            $("#txtCustomerMobileNo").val(data.c_mobile_no);
            $("#txtCustomerTownship").val(data.c_township);

            $("#txtVinNo").val(data.vin_no);
            $("#txtEngineNo").val(data.engine_no);
            $("#txtParticular").val(data.particular);

            $("#txtTotalPayment").val(data.total_payment);
            $("#txtTotalPaymentPercent").val(data.payment_percent);
            $("#txtDeposit").val(data.deposit);
            $("#txtRemainingBalance").val(data.remaining_balance);

            // Handover
            $("#txtHOPaymentPercent").val(data.payment_percent);
            if(data.handover_date){ 
                $("#txtDatePickerHO").val(data.handover_date);
                $("#txtDatePickerHO").attr("disabled", true);
                if(data.handover_vehicle_img){
                    $('#handover-previewing').attr("src", APP_URL + "api/sales/sales/upload/" + oc_no + "/" + data.handover_vehicle_img);
                }else{
                    $('#handover-previewing').attr("src", APP_URL + "img/no_image.jpg");
                }
                $("#input-handover-image-hidden").attr("disabled", true);
            }
            getOneDeliveryNote();
            // Handover

            // Owner Book Handover
            $(".txtOBHOPaymentPercent").val(data.payment_percent);
            if(parseFloat(data.payment_percent)>=100){
                $("#btnOBHOSubmit").css("display", "");
                $("#input-obho-image-hidden").attr("disabled", false); 
            }else{
                $("#btnOBHOSubmit").css("display", "none");
                $("#input-obho-image-hidden").attr("disabled", true); 
            }
            if(data.owner_book_img){
                document.getElementById('obho-previewing').src = APP_URL + "api/sales/sales/upload/" + oc_no + "/" + data.owner_book_img; 
                $("#input-obho-image-hidden").attr("disabled", true); 
            }else{ 
                document.getElementById('obho-previewing').src = APP_URL + "img/no_image.jpg"; 
                $("#input-obho-image-hidden").attr("disabled", false); 
            } 
            // Owner Book Handover
        });
    } 

    function goToDocumentCollect(obj){
        var name = $(obj).text().replace(/\s+/g, "");
        $(".myStepper li").removeClass("current");
        $("#DocumentCollect").addClass("current");
        $(".branch").css("display", "none");
        $("[data-id='DocumentCollect']").css("display", "");

        $(".dcl-filename").removeClass('box-shadow');
        $('#txtDCL' + name).addClass('box-shadow'); 
        setTimeout(function() {
            $('#txtDCL' + name).removeClass('box-shadow');
        }, 1000)
        document.getElementById('txtDCL' + name).scrollIntoView();
    }

    // Document Collect
    function appendDCList(){
        $("#mainDCLPanel").empty();
        $.each(arrDCList, function(i, v){
            var label = v + ": ";
            var filenameID = v.replace(/\s+/g, "");
            if(v=="Delivery Note"){
                $("#mainDCLPanel").append('<div class="form-group row dc-group"><label class="col-md-3 col-form-label" style="text-align: right;">' + label + '</label><div class="col-md-9"><div class="input-group input-group"><div class="form-control dcl-filename" id="txtDCL' + filenameID + '" style="height: 35px; overflow: auto;"></div><span class="input-group-btn beforeUpload"><input type="file" accept="application/pdf" class="dclFile" id="fileDCL' + filenameID + '" name="fileDCL' + filenameID + '" hidden /><label class="btn btn-primary lblDCLButton dcl-btn" for="fileDCL' + filenameID + '" title="Upload" style="margin-bottom: 0px; cursor: pointer;"><i class="fa fa-upload"></i></label></span><input type="hidden"><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-danger dcl-btn" title="Remove"><i class="fa fa-trash"></i></button></span><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-success dcl-btn" title="Download"><i class="fa fa-download"></i></button></span><span class="input-group-btn"><button type="button" class="btn btn-info dcl-btn" title="Preview"><i class="fa fa-file-pdf"></i></button></span></div></div></div>');
            }else{
                $("#mainDCLPanel").append('<div class="form-group row dc-group"><label class="col-md-3 col-form-label" style="text-align: right;">' + label + '</label><div class="col-md-9"><div class="input-group input-group"><div class="form-control dcl-filename" id="txtDCL' + filenameID + '" style="height: 35px; overflow: auto;"></div><span class="input-group-btn beforeUpload"><input type="file" accept="application/pdf" class="dclFile" id="fileDCL' + filenameID + '" name="fileDCL' + filenameID + '" hidden /><label class="btn btn-primary lblDCLButton dcl-btn" for="fileDCL' + filenameID + '" title="Upload" style="margin-bottom: 0px; cursor: pointer;"><i class="fa fa-upload"></i></label></span><input type="hidden"><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-danger dcl-btn" title="Remove"><i class="fa fa-trash"></i></button></span><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-success dcl-btn" title="Download"><i class="fa fa-download"></i></button></span><span class="input-group-btn afterUpload" style="display: none;"><button type="button" class="btn btn-info dcl-btn" title="Preview"><i class="fa fa-file-pdf"></i></button></span></div></div></div>');
            }
        });
        getOneDCL();
    }

    $(document).on('change', ".dclFile", function(){
        uploadDCLFile(this);
    });

    $(document).on('click', ".dcl-btn", function(){
        var btnName = $(this).attr("title");
        var fileURL = $(this).parent().parent().find("input[type='hidden']").val();
        var fileName = $(this).parent().parent().find(".dcl-filename").eq(0).text();

        if(btnName=="Remove"){
            deleteFile(this, fileName);
        }else if(btnName=="Download"){
            download_file(fileURL, fileName); //call function
        }else if(btnName=="Preview"){
            if(fileURL==""){
                if($(this).parent().parent().find(".dcl-filename").eq(0).attr("id")=="txtDCLDeliveryNote"){
                    window.open(APP_URL + "print/delivery_note_print.php?oc_no=" + oc_no);
                }
            }else{
                window.open(fileURL);
            }
        }
    });

    function deleteFile(obj, fileName){
        var column_name = "";
        if($(obj).parent().parent().parent().parent().find("label").eq(0).text()!=""){
            column_name = "dc_" + $(obj).parent().parent().parent().parent().find("label").eq(0).text().replace(":", "").replace(".", "").trim().toLowerCase().replace(/\s+/g, "_");
        }

        $.ajax({
            url: APP_URL + "api/sales/pdf_upload/delete.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no, file_name: fileName, column_name: column_name })
        }).done(function(data) {
            if(data.message=="deleted"){
                $(obj).parent().parent().find(".dcl-filename").eq(0).text("");
                $(obj).parent().parent().find("input[type='hidden']").val("");

                $(obj).parent().parent().find(".beforeUpload").eq(0).css("display", "");
                $(obj).parent().parent().find(".afterUpload").eq(0).css("display", "none");
                $(obj).parent().parent().find(".afterUpload").eq(1).css("display", "none");
                $(obj).parent().parent().find(".afterUpload").eq(2).css("display", "none");
            }
        });
    }

    function download_file(fileURL, fileName) {
        // for non-IE
        if (!window.ActiveXObject) {
            var save = document.createElement('a');
            save.href = fileURL;
            save.target = '_blank';
            var filename = fileURL.substring(fileURL.lastIndexOf('/')+1);
            save.download = fileName || filename;
            if ( navigator.userAgent.toLowerCase().match(/(ipad|iphone|safari)/) && navigator.userAgent.search("Chrome") < 0) {
                document.location = save.href; 
                // window event not working here
            }else{
                var evt = new MouseEvent('click', {
                    'view': window,
                    'bubbles': true,
                    'cancelable': false
                });
                save.dispatchEvent(evt);
                (window.URL || window.webkitURL).revokeObjectURL(save.href);
            }   
        }

        // for IE < 11
        else if ( !! window.ActiveXObject && document.execCommand)     {
            var _window = window.open(fileURL, '_blank');
            _window.document.close();
            _window.document.execCommand('SaveAs', true, fileName || fileURL)
            _window.close();
        }
    }

    function uploadDCLFile(obj){
        var column_name = "";
        if($(obj).parent().parent().parent().parent().find("label").eq(0).text()!=""){
            column_name = "dc_" + $(obj).parent().parent().parent().parent().find("label").eq(0).text().replace(":", "").trim().toLowerCase().replace(/\s+/g, "_");
        }

        var orgName = $(obj).attr("name");
        var ofn = $(obj).parent().parent().find(".dcl-filename").eq(0).text();

        $(obj).attr("name", "file");
        var property = document.getElementById($(obj).attr("id")).files[0];
        var file_name = property.name;
        var file_extension = file_name.split(".").pop().toLowerCase();
        
        if(property.type!="application/pdf"){
            bootbox.alert("Invalid File");
        }else{
            var file_size = parseInt(property.size/1000000);//convert bytes to mb
            if(file_size>25){
                bootbox.alert("Exceed File Size.");
            }else{
                $(".dcl-btn").attr("disabled", true);
                $(".dclFile").attr("disabled", true);
                $(".dcl-btn").css("opacity", 0.4);
                $(obj).parent().find(".dcl-btn").eq(0).css("opacity", 1);

                var form_data = new FormData();
                form_data.append($(obj).attr("name"), property);

                $.ajax({
                    url: APP_URL + "api/sales/pdf_upload/upload.php?oc_no=" + oc_no + "&ofn=" + ofn + "&column_name=" + column_name,
                    type: "POST",
                    data: form_data,
                    contentType: false,
                    cache: false,
                    processData: false,
                    xhr: function() {
                        var xhr = $.ajaxSettings.xhr();
                        $(obj).parent().parent().parent().parent().append('<div class="col-md-3 tempProgress"></div><div class="col-md-9 tempProgress" id="progress"></div>');
                        xhr.upload.onprogress = function(e) {
                            var percent = Math.floor(e.loaded / e.total * 100);
                            $("#progress").html('<div class="progress progress-xs"><div class="progress-bar bg-primary progress-bar-striped" role="progressbar" aria-valuenow="' + percent + '" aria-valuemin="0" aria-valuemax="100" style="width: ' + percent + '%"><span class="sr-only">' + percent + '% Complete (success)</span></div></div>');
                        };
                        return xhr;
                    },
                    success:function(data){
                        if(orgName=="fileDCLDeliveryNote"){
                            $("#DeliveryNotePanel").css("display", "none");
                        }
                        $(obj).parent().parent().parent().parent().find(".tempProgress").remove();
                        $(obj).parent().parent().find(".dcl-filename").eq(0).text(data.file_name);
                        $(obj).attr("name", orgName);
                        $(obj).parent().parent().find("input[type='hidden']").val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.file_name);

                        $(".dcl-btn").attr("disabled", false);
                        $(".dclFile").attr("disabled", false);
                        $(".dcl-btn").css("opacity", 1);

                        $(obj).parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                        $(obj).parent().parent().find(".afterUpload").eq(0).css("display", "");
                        $(obj).parent().parent().find(".afterUpload").eq(1).css("display", "");
                        $(obj).parent().parent().find(".afterUpload").eq(2).css("display", "");
                    }
                });
            }
        }
    }

    function getOneDCL(){
        $.ajax({
            url: APP_URL + "api/sales/pdf_upload/get_one_row.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {
            if(data.dc_sale_invoice!=""){
                $("#txtDCLSaleInvoice").text(data.dc_sale_invoice);
                $("#fileDCLSaleInvoice").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_sale_invoice);

                $("#fileDCLSaleInvoice").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLSaleInvoice").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLSaleInvoice").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLSaleInvoice").parent().parent().find(".afterUpload").eq(2).css("display", "");
            }

            if(data.dc_sale_contract!=""){
                $("#txtDCLSaleContract").text(data.dc_sale_contract);
                $("#fileDCLSaleContract").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_sale_contract);

                $("#fileDCLSaleContract").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLSaleContract").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLSaleContract").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLSaleContract").parent().parent().find(".afterUpload").eq(2).css("display", "");
            }

            if(data.dc_delivery_note!=""){
                $("#txtDCLDeliveryNote").text(data.dc_delivery_note);
                $("#fileDCLDeliveryNote").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_delivery_note);

                $("#fileDCLDeliveryNote").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLDeliveryNote").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLDeliveryNote").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLDeliveryNote").parent().parent().find(".afterUpload").eq(2).css("display", "");

                // Delivery Note
                $("#DeliveryNotePanel").css("display", "none");
                // Delivery Note
            }else{
                // Delivery Note
                $("#DeliveryNotePanel").css("display", "");
                // Delivery Note
            }

            if(data.dc_owner_book!=""){
                $("#txtDCLOwnerBook").text(data.dc_owner_book);
                $("#fileDCLOwnerBook").parent().parent().find("input[type='hidden']").eq(0).val(APP_URL + "api/sales/pdf_upload/upload/" + oc_no + "/" + data.dc_owner_book);

                $("#fileDCLOwnerBook").parent().parent().find(".beforeUpload").eq(0).css("display", "none");
                $("#fileDCLOwnerBook").parent().parent().find(".afterUpload").eq(0).css("display", "");
                $("#fileDCLOwnerBook").parent().parent().find(".afterUpload").eq(1).css("display", "");
                $("#fileDCLOwnerBook").parent().parent().find(".afterUpload").eq(2).css("display", "");
            }
        });
    }
    // Document Collect

    // Handover
    $("#btnHOSubmit").click(function(){
        $("#frmHOEntry").submit();
    });

    $("#frmHOEntry").on('submit',(function(e) {
        e.preventDefault();       

        if($("#handover-previewing").attr("src")== (APP_URL + "img/no_image.jpg")){
            bootbox.alert("Please upload vehicle photo.");
            return false;
        }

        if(!$("#txtDatePickerHO").prop("disabled")){
            var formData = new FormData(this);
            var handover_date = $("#txtDatePickerHO").val();
            
            var objArr = [];
            objArr.push({ "oc_no": oc_no, "handover_date": handover_date });
            formData.append('objArr', JSON.stringify( objArr )); 

            $("#btnHOSubmit").attr("disabled", true);
            $.ajax({
                url: APP_URL + "api/sales/sales/update_handover.php",
                type: "POST",
                processData: false,
                contentType: false,
                data: formData,
                success: function(data){    
                    $("#btnHOSubmit").attr("disabled", false);
                    if(data.message=="created"){
                        $("#txtDatePickerHO").attr("disabled", true);
                    }else if(data.message=="session expire"){
                        bootbox.alert("Session Expire! Please refresh the browser and login again.");
                    }else{
                        bootbox.alert("Error on server side.");
                    }
                }
            });
        }
        generateDeliveryNote();    
    }));

    // Delivery Note
    function getOneDeliveryNote(){
        $.ajax({
            url: APP_URL + "api/sales/sales/get_one_delivery_note.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no })
        }).done(function(data) {    
            $("#txtDNDeliveryTo").val(data.delivery_to);
            $("#txtDNPhoneNo").val(data.phone_no);
            $("#txtDNAddress").val(data.address);
            $("#txtDNModel").val(data.model);
            $("#txtDNGrade").val(data.grade);
            $("#txtDNVinNo").val(data.vin_no);
            $("#txtDNEngine").val(data.engine);
            $("#txtDNColourExtInt").val(data.colour_ext_int);
            $("#txtDNSalesPerson").val(data.sales_person);
        });
    }

    function generateDeliveryNote(){
        var date = $("#txtDatePickerDN").val();
        var delivery_to = $("#txtDNDeliveryTo").val();
        var phone_no = $("#txtDNPhoneNo").val();
        var address = $("#txtDNAddress").val();
        var model = $("#txtDNModel").val();
        var grade = $("#txtDNGrade").val();
        var engine = $("#txtDNEngine").val();
        var colour_ext_int = $("#txtDNColourExtInt").val();
        var vin_no = $("#txtDNVinNo").val();
        var registration_no = $("#txtDNRegistrationNo").val();
        var invoice_no = $("#txtDNInvoiceNo").val();
        var sales_person = $("#txtDNSalesPerson").val();

        $.ajax({
            url: APP_URL + "api/sales/delivery_note/generate.php",
            type: "POST",
            data: JSON.stringify({ oc_no: oc_no, date: date, delivery_to: delivery_to, phone_no: phone_no, address: address, model: model, grade: grade, engine: engine, colour_ext_int: colour_ext_int, vin_no: vin_no, registration_no: registration_no, invoice_no: invoice_no, sales_person: sales_person })
        }).done(function(data) {    
            if(data.message=="created"){
                bootbox.alert("Successfully submitted."); 
                checkStatus();
            }else if(data.message=="session expire"){
                bootbox.alert("Session Expire! Please refresh the browser and login again.");
            }else{
                bootbox.alert("Error on server side.");
            }
        });
    }
    // Delivery Note

    // Handover

    // Owner Book Handover
    $("#btnOBHOSubmit").click(function(){
        $("#frmOBHOEntry").submit();
    });

    $("#frmOBHOEntry").on('submit',(function(e) {
        e.preventDefault();             
        var formData = new FormData(this);        
        var objArr = [];
        objArr.push({ "oc_no": oc_no });
        formData.append('objArr', JSON.stringify( objArr ));

        $("#btnOBHOSubmit").attr("disabled", true);
        $.ajax({
            url: APP_URL + "api/sales/sales/update_owner_book.php",
            type: "POST",
            processData: false,
            contentType: false,
            data: formData,
            success: function(data){   
                $("#btnOBHOSubmit").attr("disabled", false); 
                $("#btnOBHOSubmit").css("display", "none");
                if(data.message=="created"){ 
                    document.location = APP_URL + "sales/sales_list.php";
                }else if(data.message=="session expire"){
                    bootbox.alert("Session Expire! Please refresh the browser and login again.");
                }else{
                    bootbox.alert("Error on server side.");
                }
            }
        });
    }));
    // Owner Book Handover
</script>